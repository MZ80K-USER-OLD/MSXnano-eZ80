# MSXnano T80/eZ80 v4 割込み修正版

FAIL_INVESTIGATION.mdを参照。元v4の実機結果はユーザー報告でFAIL。
プレフィックス境界の割込み不具合をGHDLで再現して修正。
実機の直接原因は診断結果待ち。Gowin合成・修正版の実機動作は未確認。

拡張CPU: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
元T80: fpga/project_T80/MSXNanoTang20K_T80.gprj

診断だけならhardware_test/EZ80DIAG.COMを既存v4で実行。再書込み不要。
CPU修正はfpga/G80A_eZ80/t80_ez80.vhdのみ。
GHDLとPython3でbash run_baseline.sh: 19テストPASS。
