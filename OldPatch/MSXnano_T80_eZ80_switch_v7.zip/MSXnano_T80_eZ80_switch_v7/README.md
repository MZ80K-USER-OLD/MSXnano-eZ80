# MSXnano T80/eZ80 v7

24bit CALL/RETと独立SPLの開発基盤。DOCM/ADL_PROGRESS_v7.mdを参照。

完全なeZ80混在モードCALL/RETではない。モード情報の保存・復帰は次段階。
新機能はFETCH24=trueの単体シミュレーション専用。
MSXプロジェクトはFETCH24=falseを保持、拡張メモリ未接続、ADL切替未実装。
v7のGowin合成・実機動作は未確認。

- eZ80プロジェクト: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
- 元T80プロジェクト: fpga/project_T80/MSXNanoTang20K_T80.gprj
- 検証: GHDLとPython3でbash run_baseline.sh。155実行PASS。
- 新規試験: sim/tb_call24.vhd（試験プログラムも内包）。
- ログ: test_results_v7.log。
- DOCM: v6/v7進捗、メモリ割当、元SDRAM解析資料。
- hardware_testのCOMは旧機能の回帰確認用。今回の新機能用COMは未提供。
