# MSXnano T80/eZ80 v15

IX／IY変位付きLDを24bitアドレスに対応。
符号付き変位、64KB境界、24bit循環、40hの短幅bank 0指定を検証。
全499実行PASS。新規テスト: sim/tb_indexed24.vhd（80ケース）。
実行: bash run_baseline.sh（GHDLとPython3）。ログ: test_results_v15.log。
仕様・未対応範囲: doc/ADL_PROGRESS_v15.md。

v14はユーザー実機でスペースマンボウ動作を確認。v15の合成・実機動作は未確認。
MSX標準FETCH24=false、ENABLE_MIXED=falseを維持。A24メモリ接続は未実装。
追加機能はシミュレーション用。既存COM／ASMはhardware_testに同梱。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
元T80の8ソースは基準SHA256と一致。
