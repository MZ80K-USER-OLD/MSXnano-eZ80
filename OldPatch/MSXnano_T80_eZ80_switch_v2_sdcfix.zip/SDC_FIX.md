# TA2003 修正

対象: fpga/tang20k.sdc 旧67行目。
create_clock -name clock_env_reset ... [get_nets {psg1/env_reset}] -add を削除して説明コメントに置換。
PSG RTLのp_envelope_shapeではenv_resetは初期化条件、rising_edge(CLK)が動作クロック。
p_wdataはclkHighでenv_resetを更新しているため、env_resetを独立した周期クロックとして宣言するのは適切ではない。

v2からの変更はこのSDC制約の削除と説明ファイルのみ。元T80やCPU RTLに変更なし。
T80/eZ80両プロジェクトで共通のSDCを使用。
Gowin合成・タイミング解析はこの環境では実行していない。
エラー解消後もtiming reportの確認が必要。既存のPSGへの広いfalse_path制約の妥当性は今回検証していない。
新しい合成ネットリストで対象ネットが消えた理由（名前変更・最適化等）は未確定。
