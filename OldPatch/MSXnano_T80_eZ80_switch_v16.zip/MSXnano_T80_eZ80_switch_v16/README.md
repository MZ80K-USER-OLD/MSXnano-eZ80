# MSXnano T80/eZ80 v16

Aの絶対LD／STOREのアドレス即値を24bitに追加。40h指定は2バイト・bank 0。
新規テスト: sim/tb_absolute24.vhd。仕様・制限: doc/ADL_PROGRESS_v16.md。
実行: bash run_baseline.sh（GHDLとPython3）。ログ: test_results_v16.log。

v15はユーザー実機でスペースマンボウの動作を確認。
v16の合成・実機動作は未確認。MSX標準設定を維持。
A24メモリ接続前なので追加機能はシミュレーション用。
既存COM／ASMはhardware_testに同梱。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
元T80の8ファイルは基準SHA256と一致。
