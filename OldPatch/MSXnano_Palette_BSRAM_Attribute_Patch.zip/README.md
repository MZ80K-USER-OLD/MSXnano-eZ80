# Palette BSRAM attribute patch

Source: msxnano-vdp-sprite(1).zip

Changes ONLY `fpga/tn_vdp_v3_v9958/src/ram.vhd`:
- `palette_rb`: add `syn_ramstyle` = `block_ram` to `blkram`
- `palette_g`: same

No palette initialization or RAM behavior was changed.

Apply: replace the file at the identical relative path in the original project, then run Gowin Synthesis and PnR. Compare BSRAM count (baseline reported 44/46) and check technology mapping. This attribute requests block RAM; it does not guarantee the resource assignment.

No Gowin EDA/GHDL tools were available in this environment; synthesis and hardware testing were NOT performed.

A preexisting synthesized netlist `fpga/impl/gwsynthesis/project.vg` does not preserve palette entity names in searchable form, so palette-specific BSRAM usage cannot be established from simple instance-name matching.
