# MSXnano T80/eZ80切替版 v4

## プロジェクト
従来T80: fpga/project_T80/MSXNanoTang20K_T80.gprj
拡張版: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
各プロジェクトは別のtopソースを選択し、プリプロセッサでCPUをトップ直下のcpu1に配置。
T80/eZ80プロジェクトを切り替えることで元CPUに戻れる。元G80A/T80ソースは無変更。
original/MSXnanoTANG20K.fsはアップロード時の復帰用成果物。現在の版の生成物ではない。

## 開発状態
ADL_PROGRESS_v4.mdとhardware_test/README.mdを参照。
LD.LIL即値ロードに加え、HL/IX/IYのLD.LIS 3バイト保存を追加。
ADLモード、24bit PC/外部アドレス、SPS/SPL/MBASEは未実装。
v4のGowin合成・実機動作は未確認。

## 検証
GHDLとPython3を用意してbash run_baseline.sh。
通常/WAITを含む11テストPASS。実機用EZ80V4.COMを同じCPUでスタブBDOSにより検証。
全命令の互換性を保証するテストではない。
