# MSXnano T80/eZ80 v6

開発用24bit JPターゲット転送を追加。DOCM/ADL_PROGRESS_v6.mdを参照。

- eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
- 元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj
- GHDL検証: bash run_baseline.sh（GHDL、Python3が必要）。59実行PASS。
- 新規テスト: sim/tb_jump24.vhd。全条件JP・HL/IX/IY・WAIT・バンク境界を検証。
- DOCM: メモリ割当、元SDRAM解析資料、v6進捗。

MSX実機用のFETCH24=false設定を保持。拡張メモリ接続とADLモードは未実装。
v6のGowin合成・実機動作は未確認。実機でFETCH24を有効にしない。
変更前の実機ではユーザーがスペースマンボウの正常動作を確認。
既存の実機COMはv4機能の回帰確認用で、24bit JPの実機試験には使えない。
