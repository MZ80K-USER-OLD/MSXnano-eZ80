# MSXnano T80/eZ80 v18

ED形式のBC／DE／HL／SPの絶対メモリ転送を24bit化。
通常命令はアドレス3バイト・値3バイト。40h指定は2バイト・bank 0。
SPは24bit SPLと従来16bit SPを区別する。
全595実行PASS。新規テスト: sim/tb_ed_absolute24.vhd（48ケース）。
仕様・制限: doc/ADL_PROGRESS_v18.md。ログ: test_results_v18.log。
実行: bash run_baseline.sh（GHDLとPython3）。

v17でもユーザー実機でスペースマンボウの動作を確認。
v18の合成・実機動作は未確認。MSX標準設定を維持。
A24メモリ接続前なので追加機能はシミュレーション用。
既存COM／ASMはhardware_testに同梱。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
元T80の8ファイルは基準SHA256と一致。
