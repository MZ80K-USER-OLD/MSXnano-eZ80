#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/run_mbase29.py
python3 tools/run_mbase_irq29.py
