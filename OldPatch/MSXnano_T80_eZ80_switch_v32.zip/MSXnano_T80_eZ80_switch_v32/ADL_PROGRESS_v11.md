# v11: suffixなしADL CALL／RET

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、通常CALL、CALL cc、RET、RET ccを24bit幅へ追加。
CALLの即値は3バイト、戻りアドレスはSPLに3バイト保存する。
RETは3バイトを読み、ADL状態を維持する。
既存の52/5B付きCALL／RETはFrame_Enabledで区別し、02/03モード情報付きのフレームを継続する。
通常RETはReturn_Modeの過去の値を参照しない。
40hのShort_Pending／Short_Instructionによる短幅選択も維持する。

## 検証

新規 sim/tb_native_call24.vhd：8条件×成立/不成立×WAIT有/無×SPL初期値3種類＝96実行。
テスト用プログラムはベンチ内のROM定義に含む。

- suffixなしのCALL／RETと条件CALL／RETを2回連続で実行。
- 01FFFFをまたいでCALL即値を取得し、異なるバンクへ入れ子のCALL。
- SPL=030001、000001、FF0001でスタックの借り・24bit循環を確認。
- 3バイトフレームの各値とガード、実際の書込み回数を検査。
- WAITによる重複書込みや復帰先のずれを検査。

既存の混在モードテストも更新し、02/03フレームの内部に通常3バイトCALLを入れ子にする。
モード復帰後の2回目では、過去の02マーカーが通常RETに影響しないことも確認する。
元T80の8ソースファイルのSHA256を基準と比較する。
GHDL全379実行PASS（既存283＋新規96）。Pythonによる長いLDの波形検査もPASS。
検証結果はtest_results_v11.log。元T80の8ファイルは基準SHA256とすべて一致。

## 実機と制限

MSX標準のFETCH24=false、ENABLE_MIXED=falseを維持。
A24のMSXメモリ接続が未実装のため、新機能は単体シミュレーションで検証する。
v11はユーザーによる実機確認済み（2026-10-12）。確認内容の詳細は未提示。
A24を使う新機能の実機検証は別途必要。新しい実機COMは追加しない。
旧機能の回帰用としてhardware_test内のEZ80V4.COM／EZ80DIAG.COMとASMを同梱。

全命令ADL対応ではない。長いPUSH／POP、24bit演算とデータアクセス、
49/52や40hの一般的な幅制御、MBASE、高位バンクのIRQ／NMI・RETI／RETNは未完成。
未対応の命令・suffixの組合せを一般的なeZ80プログラムとして実行しない。
特に40h CALL／RETのモード遷移を含む一般仕様は本段階の検証対象外。

## 次の作業

命令幅・スタック処理の残りを仕上げ、その後24bitデータアクセス、
MSXメモリ接続と実機テスト、割込みと総合検証へ進む。
docのVRAM256KB／MEGARAM予約枠、VDP読出し優先・競合時CPU WAIT仕様を継承する。
