# v10: 通常ADL LD/JPと40hの短い幅指定

ENABLE_MIXED=trueかつADL_State=1の場合、suffixなしのLD BC/DE/HL/SP,imm、
DD/FD LD IX/IY,immを即値3バイトにする。SPはSPL。
JP imm / JP cc,immもターゲット3バイト、JP(HL)/(IX)/(IY)も24bit値を使用。

40hを短い幅指定として命令本体まで保持する。DD/FDを挟んでも保持。
対応LDは即値2バイト（SPは従来SPS）、レジスタ上位は既存の短いロードと同じ保持動作。
対応JPは2バイトのbank0ターゲットへ分岐し、成功時に短い実行状態へ戻る。
条件JP不成立ではモードを変更しない。短いLDも実行モードを変更しない。
40hと命令本体の間はShort_PendingによりINT/NMI受付を保留。
40hは通常Z80ではLD B,Bなので、ENABLE_MIXED=trueの場合だけ意味を変更する。
MSX実機標準のFETCH24=false/ENABLE_MIXED=falseは維持。

## 検証

GHDL 283実行PASS（v9回帰251＋新規32）。ログtest_results_v10.log。
新規テストsim/tb_native24.vhdは8条件×成立/不成立×WAIT有/無。
プログラムはテストベンチ内のROM定義に含む。

- suffixなしHL即値が01FFFFをまたぐ。JP(HL)で24bitターゲットへ分岐。
- suffixなしIX/IY即値ロードとJP(IX)/(IY)。
- suffixなし条件JPの成立、不成立時の3バイト消費。
- 40h付きHL/IX/IYロードが2バイトで止まり、次のprefixを消費しない。
- 40h付きJPでbank0に戻り、HALTまで到達。
- 意図しない書込みなし、A24下位=A、refreshはbank0。

クロックenable1/16、入力捕捉を位相分離。元T80/G80Aの8ファイルは基準SHA256と一致。
BC/DE/SPのsuffixなし幅選択は共通即値制御へ追加したが、新規の独立した値検査は今後追加。
40h境界のIRQ/NMI専用投入試験も未実施。

## 実機と制限

v10のGowin合成・実機動作は未確認。A24はMSXメモリ未接続。
新機能は単体シミュレーション用。新しい実機COMはメモリ接続後に作成する。
既存EZ80V4.COM/EZ80DIAG.COMとASMは旧機能の回帰用として同梱。

全命令ADL対応ではない。suffixなしCALL/RETは24bit仕様へまだ切替えていない。
混在CALL/RETにはv9の対応する52/5B経路を使う。
40hの全命令適用、49/52の一般的幅制御、非法suffixの処理、MBASE、長いPUSH/POP、
24bit演算、24bitデータアクセス、高位バンクIRQ/NMI・RETI/RETNが残る。
未対応の命令やsuffixの組合せを一般的なeZ80コードとして実行しない。

## 次の作業

第一段階（命令幅・スタック処理）の仕上げを継続。
通常CALL/RETのADL幅、長いPUSH/POP、未確認の幅選択を実装・検証する。
その後24bitデータアクセス、MSXメモリ接続と実機ASM/COM、割込みと総合検証へ進む。
docのメモリ割当とVDP読出し優先・CPU WAIT仕様を継承。
