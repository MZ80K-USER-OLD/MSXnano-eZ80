# v16: Aの絶対アドレスLD

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、通常の
LD A,(nnn)／LD (nnn),Aのアドレス即値を3バイトにする。
下位・中位・上位の順に読み、24bitアドレスへ1バイトを転送する。
40h短幅指定では即値2バイト、bank 0を使用する。
MSX標準設定FETCH24=false、ENABLE_MIXED=falseを維持する。

## テスト

新規 sim/tb_absolute24.vhd。ROM定義にテストプログラムを含む。
通常の書込み・読戻し、40h付き書込み・読戻しを照合。
3バイトのアドレス即値が20FFFFをまたぐ配置で、取得とPCの連続性を確認。
bank 01／7F／FF、下位9000／FFFF、WAIT有無の12ケース。
2回の実際の書込みについて全24bitアドレス、値、回数を検査する。
CPと条件JPで読戻しの不一致を検出する。
既存499＋新規12、全511実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v16.log。元T80の8ファイルは基準SHA256と一致。

## 実機と制限

ユーザーはv15でもスペースマンボウの実機動作を確認（2026-10-12）。
互換設定での確認であり、24bitアクセスはシミュレーションで検証している。
v16の合成・実機動作は未確認。A24のMSXメモリ接続は未実装。
新しい実機COMは追加しない。既存COM／ASMをhardware_testに同梱。

今回の追加はAの1バイト絶対転送のみ。
HL／IX／IYなどの24bit値の絶対ロード・ストアは今後追加する。
一般suffix制御、MBASE、メモリALU、CB／ブロック命令、24bit ADD／ADC／SBC、
AFスタック、高位バンク割込みは未完成。全命令eZ80互換ではない。
次はレジスタペアの絶対メモリ転送を進める。
VRAM256KB／MEGARAMの予約枠、VDP読み出し優先と競合時CPU WAIT仕様を継承する。
