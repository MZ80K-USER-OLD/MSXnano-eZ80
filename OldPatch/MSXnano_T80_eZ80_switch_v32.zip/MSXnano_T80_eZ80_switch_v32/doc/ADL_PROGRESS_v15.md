# v15: IX／IY変位付きLDの24bitアドレス

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、DD／FD付きの
LD r,(IX/IY+d)、LD (IX/IY+d),r、LD (IX/IY+d),nに24bitアドレスを使用する。
符号付き8bit変位dを24bitへ符号拡張して加算。
既存の下位16bitアドレス計算に合わせて上位バンクを保存し、実データサイクルで使用する。
データ幅は1バイト。40h短幅指定はbank 0、下位16bitの循環アドレスを使用する。
リフレッシュとI/Oのbank 0を維持。MSX標準設定は変更しない。

## テスト

新規 sim/tb_indexed24.vhd。プログラムはベンチ内ROMに含む。
IXへの即値書込み・読戻しと、IYへのA書込み・読戻しを確認。
40hをDD／FDの前に置き、両方の短幅読み書きがbank 0へ戻ることも確認。
書込みの全24bitアドレスと値、4回の書込み回数を検査。
読戻しはCPと条件JPで照合し、不一致時はアサーションで停止する。

bank 00／01／7F／FF、下位0000／FFFF、変位-128／-1／0／1／127、WAIT有無の80ケース。
64KB境界の桁上がり・桁下がりと24bitの両方向循環を検査する。
既存419＋新規80、全499実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v15.log。元T80の8ファイルは基準SHA256と一致。
全汎用レジスタの値、全256変位を個別に網羅したテストは未実施。

## 実機確認と制限

ユーザーはv14を実機に適用してスペースマンボウの動作を確認（2026-10-12）。
提供プロジェクトfpga/project_eZ80/MSXNanoTang20K_eZ80.gprjはtop_ez80.vとG80A_eZ80を使用。
FETCH24=false、ENABLE_MIXED=falseの互換設定なので、ゲームの動作は互換経路の確認となる。
追加した24bitアクセスの実機検証を意味しない。

v15のGowin合成・実機動作は未確認。A24のMSXメモリ接続は未実装。
新規実機COMは追加しない。既存のCOM／ASMをhardware_testに同梱。
今回のindexed対応は上記LDのみ。
ALUのメモリオペランド、メモリINC／DEC、CB／DDCB／FDCB、ブロック命令、
絶対アドレスLD、24bit値のメモリ転送、MBASE、一般suffix制御、高位バンク割込みは未完成。
全命令eZ80互換ではない。
次は絶対アドレスのデータLDを進める。
VRAM256KB／MEGARAM予約枠、VDP読み出し優先・競合時CPU WAIT仕様を継承する。
