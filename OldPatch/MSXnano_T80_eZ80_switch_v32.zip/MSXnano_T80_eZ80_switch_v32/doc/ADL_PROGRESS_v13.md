# v13: 24bit INC／DEC

FETCH24=true、ENABLE_MIXED=true、ADL_State=1の通常INC／DEC
BC・DE・HL・IX・IYを24bit幅に追加。
下位16bitの既存演算に上位8bitの桁上がり・桁下がりを連動させる。
SPの通常INC／DECは24bit SPLを更新する。
40hの短幅指定では従来16bit幅を選び、ペアレジスタの上位8bitを保持する。
MSX標準設定FETCH24=false、ENABLE_MIXED=falseを維持する。

## テスト

新規 sim/tb_incdec24.vhd。プログラムはベンチ内ROM定義に含む。
BC・DE・HL・IX・IYの各レジスタについて以下をPUSHの3バイトで観測する。

- 12FFFFのINCで130000、DECで12FFFFへ復帰。
- 130000のDECで12FFFF、INCで130000へ復帰。
- FFFFFFのINCで000000、DECでFFFFFFへ復帰。
- 000000のDECでFFFFFF、INCで000000へ復帰。
- 12FFFFを40h付きINC／DECし、上位12を保持して12FFFFへ復帰。

短幅INC直後の120000も観測し、上位12の保持を検査する。
各PUSHをPOPで戻し、計150回の書込みについてアドレス順序と値を検査。
SPL初期値030001／000001／FF0001とWAIT有無で6ケース。
開始時にSPLを3回DEC・3回INCし、復帰後のPUSHアドレスも検査する。
別のsim/tb_spl_incdec24.vhdでSPLの中間値を直接スタック書込みアドレスで観測。
初期値00FFFF／010000／FFFFFF／000000、INC／DEC、WAIT有無の16ケース。
専用のフラグ保持検査、短幅SPの独立した値検査、代替レジスタセットの検査は未実施。
既存385＋新規22、全407実行PASS。長いLDのPython波形検査もPASS。
結果はtest_results_v13.log。元T80の8ファイルは基準SHA256と一致。

## 実機確認と制限

v12で実行したEZ80DIAG.COMの結果はdoc/HARDWARE_RESULT_v12.mdを参照。
DI／EI両ブロックの全値が一致。これは旧拡張機能の実機回帰確認。
v13の合成・実機動作と、追加した24bit INC／DECの実機検証は未実施。
A24はMSXメモリ未接続。新規実機COMは追加せず、既存COM／ASMを同梱する。

AFスタック幅、一般的なsuffix幅制御、MBASE、24bit ADD／ADC／SBC、
24bitデータアクセス、高位バンクIRQ／NMI・RETI／RETNは未完成。
全命令eZ80互換ではない。
次はデータアクセスの24bit化を進める。
VRAM256KB／MEGARAM予約枠とVDP読み出し優先・競合時CPU WAIT仕様は継承する。
