# v12: ADL PUSH／POPの追加

FETCH24=true、ENABLE_MIXED=true、ADL_State=1でsuffixなしの
PUSH／POP BC・DE・HL・IX・IYを3バイト幅に追加する。
SPLを使用し、PUSHは上位・中位・下位の順にアドレスを減らして保存、
POPは下位・中位・上位の順に読み出してSPLを増やす。
既存の通常CALL／RET、モード情報付きCALL／RETを継承。

## テスト

新規テスト: sim/tb_pushpop24.vhd。
プログラムはベンチ内ROMに含む。
5レジスタについてロード→PUSH→ゼロロード→POP→再PUSH→POPを実施。
各書込みのアドレス、3バイトの値、書込み回数30回を検査する。
SPL初期値030001／000001／FF0001とWAIT有無の6ケースで、
64KB境界の借りと24bitアドレス循環を確認する。
既存379ケースを含む全385実行PASS。長いLDのPython波形検査もPASS。
結果はtest_results_v12.log。元T80の8ファイルは基準SHA256と一致。

## 実機と未対応範囲

MSX標準設定FETCH24=false、ENABLE_MIXED=falseを維持する。
v11はユーザーによる実機確認済み。v12はユーザーによる実機適用・EZ80DIAG.COM実行を確認済み。
詳細はHARDWARE_RESULT_v12.md。追加したADL PUSH／POPの実機検証は未実施。
A24のMSXメモリ接続は未実装で、新機能は単体シミュレーションで検証する。
新規実機COMは追加しない。既存EZ80V4／EZ80DIAGのCOMとASMを同梱する。

今回の対象はBC・DE・HL・IX・IYの通常ADL PUSH／POP。
AFのADLスタック幅、40/49/52の一般的な幅指定、MBASE、24bit演算とデータアクセス、
高位バンクIRQ／NMI・RETI／RETNは未完成。
全命令eZ80互換を意味しない。

次は残る幅選択とデータアクセスを進め、MSXメモリ接続と実機テストへ進む。
VRAM256KB／MEGARAMの予約枠、VDP読み出し優先と競合時CPU WAIT仕様はdoc内の資料を参照。
