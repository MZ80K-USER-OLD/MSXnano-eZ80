# v21: 回路規模の測定用構成

v21では命令追加を一時停止し、現在のCPUの回路規模を比較する3つのGowinプロジェクトを追加した。
CPU RTLはv20と同一。CBのDDCB／FDCB対応は次段階へ移す。

| 構成 | 開くGowinプロジェクト | 設定 |
|---|---|---|
| 通常T80 | fpga/project_size_T80/CPU_Size_T80.gprj | 元T80、Mode=0、IOWait=1 |
| eZ80互換 | fpga/project_size_eZ80_compat/CPU_Size_eZ80_compat.gprj | FETCH24=false、ENABLE_MIXED=false |
| eZ80 ADL | fpga/project_size_eZ80_ADL/CPU_Size_eZ80_ADL.gprj | FETCH24=true、ENABLE_MIXED=true、RESET_ADL=true |

全構成のトップ名はcpu_size_top。PR0003修正版では27ビットの共通外部インタフェースを持つ。
24bitアドレスA24の全ビットとDO・バス制御出力を観測MUXへ接続し、
DI・割込み・WAIT・クロックenableは外部入力とする。
外部observe_selectに応じて8bitのobserve_dataへ出力する。
全ページが外部から選択できるため、上位アドレスを使用しない回路として削除されるのを防ぐ。
T80ではA24上位8bitは0。ADL版は現在実装済みの24bit経路を有効にする。
デバイスは全てGW2AR-LV18QN88C8/I7、クロック制約は54MHz相当の18.519ns。

## Gowinでの測定手順

1. 3つのプロジェクトを別々に開き、トップをcpu_size_topとして確認する。
2. 同じGowinバージョン・合成オプション・最適化方針を使用する。
3. 各構成のSynthesis、Place & Routeを実行する。
4. 各構成のimpl/pnrにある.rpt.txtと、impl/gwsynthesisの合成レポートを保存する。
5. Logic・Register・CLS・BSRAM・DSPを比較する。CPU階層の内訳は合成レポートを参照する。

プロジェクトにボード用CSTは含めない。I/Oの配置は未拘束で、測定専用構成である。
生成したビットストリームをMSXnanoに書き込む用途ではない。
実機用は従来のfpga/project_eZ80/MSXNanoTang20K_eZ80.gprjを使用する。
入出力遅延やenable周期との関係は制約に含めていない。
この測定のタイミング結果はCPU単体の共通制約による比較で、実機全体のタイミング保証ではない。

CPU単体プロジェクトの値にはラッパー、観測MUXとI/O資源が含まれる。
純粋なCPU規模は合成レポートのcore/cpu階層で確認する。
3構成のMUXは同じ記述だが、T80の上位アドレスは定数なので最適化後のMUX規模には差が出る。
ADL－互換の差は24bit経路有効化の増加量の目安、ADL／T80は現時点の倍率の目安になる。
全MSX構成の配置・最適化とは異なるので、全体のCLSやBSRAMへ単純に加算しない。
現在の部分実装の規模であり、未実装命令・割込み・メモリ接続を含む最終規模ではない。

## レポート比較ツール

tools/compare_cpu_size.pyは3つのPnRテキストレポートを読み、使用量と差分・倍率をMarkdownで出力する。
.rpt.txtが1つ含まれたZIPも入力にできる。

```bash
python3 tools/compare_cpu_size.py T80.rpt.txt compat.rpt.txt ADL.rpt.txt --output cpu_size_comparison.md
```

この環境にはGowin本体がないため、実測値は未取得。
以前の1.5～2倍という見積りは実測値ではなく、今回のレポートで置き換える。
添付された全MSXのpnr.zip（Logic 14866、CLS 9113、BSRAM 45）は互換構成の基準資料であり、
今回のCPU単体3構成の測定値として扱わない。

## 検証と実機記録

- sim/tb_cpu_size.vhdとrun_size_smoke.shで3構成×WAIT有無の6ケースPASS。
- T80とeZ80互換は従来16bitロード・ストアを確認。
- ADL構成は値123456の3バイトストアと12FFFF→130000→130001のA24を確認。
- CPU RTLはv20と全ファイル一致。v20の899実行PASSを継承し、v21ではCPU全回帰を再実行していない。
- 元T80の8ソースは基準SHA256と一致。
- 比較ツールの読み取りは添付pnr.zipの実数値で確認。

ログはtest_results_size_v21.log。実測規模とGowinでの合成成功は未確認。
ユーザーはv20でスペースマンボウの起動・動作を実機確認済み（2026-10-13）。
これは互換設定の確認で、24bit機能の実機検証ではない。
新規実機COMは追加しない。既存COM／ASMを同梱する。
VRAM256KB／MEGARAM予約枠とVDP読み出し優先・競合時CPU WAIT仕様を継承する。

## PR0003の修正

旧構成は58本の外部I/Oを要求し、ユーザーの配置配線で23 IOBUF unPlacedが発生した。
CPUのLogic使用量超過を示すエラーではなく、I/Oバッファ配置の失敗である。
修正版はCPU接続を内部cpu_size_coreに保持し、外部出力を8bitの観測MUXにした。
入力16本＋選択3本＋出力8本＝27本。既存のMSX実機用トップは変更していない。

| observe_select | observe_data |
|---|---|
| 000 | A24[7:0] |
| 001 | A24[15:8] |
| 010 | A24[23:16] |
| 011 | DO[7:0] |
| 100 | M1_n・MREQ_n・IORQ_n・RD_n・WR_n・RFSH_n・HALT_n・BUSAK_n（bit7→0） |
| 101 | 000000・update_addr・Data_Reverse |
| 110／111 | 00 |

3構成×WAIT有無の6ケースを修正版で再実行しPASS。
ベンチは6つの同一CPUインスタンスに同じ入力を与え、各観測ページを同時に照合する。
Gowin測定プロジェクトに入るCPUは1つだけ。
Gowin本体での再合成・配置配線はこの環境では未実施。
ZIPを全展開し、修正版のproject_size_*を使用して.gprjを開き直して再合成する。
I/O配置で再度止まる場合でも、SynthesisのCPU階層使用量は規模比較に利用できる。
