# v18: ED形式の絶対メモリ転送

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、ED形式の
LD (nnn),BC／DE／HL／SP、LD BC／DE／HL／SP,(nnn)を24bit化する。
アドレス即値3バイト、データ3バイト、LOW・MID・HIGH順。
SPは24bit SPLを使用する。転送中のバンク境界を反映し、24bitで循環する。
40h付き命令はアドレス2バイト・データ2バイト・bank 0。
BC／DE／HLの短いロードは上位を保持する。短いSP命令は従来の16bit SPを使用し、SPLとは独立。
短幅指定をEDまで保持するようにShort_Pendingを拡張する。
5B／52のpendingもEDを越えて保持するが、全suffixの一般仕様を実装したものではない。

## 検証

新規 sim/tb_ed_absolute24.vhd。プログラムはベンチ内ROMに含む。
値123456のストア→レジスタをゼロにする→ロード→別アドレスに再ストアして3バイトを検査。
40h付き転送後にBC／DE／HLの上位ABが保持されることを検査。
SPは16bit SP=9000を設定し、短いEDストアが00 90を出力することを確認。
SPL=ABCDEFの状態で短いEDロードを行い、通常EDストアでABCDEFが維持されることを確認。
全11回の書込みについて24bitアドレス、値、回数を検査する。
bank 01／7F／FF、下位FFFE／FFFF、BC／DE／HL／SP、WAIT有無の48ケース。
既存547＋新規48、全595実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v18.log。元T80の8ファイルは基準SHA256と一致。
40h＋ED境界への専用IRQ／NMI投入試験、5B／52＋EDの独立した幅検査は未実施。

## 実機と未対応範囲

ユーザーはv17でもスペースマンボウの実機動作を確認（2026-10-12）。
互換設定の動作確認で、追加24bit機能の実機検証ではない。
v18のGowin合成・実機動作は未確認。MSX標準設定を維持する。
A24メモリ接続は未実装。新規実機COMは追加せず、既存COM／ASMを同梱する。

メモリALU・メモリINC／DEC、CB／ブロック命令、24bit ADD／ADC／SBC、
一般suffix制御、MBASE、AFスタック、高位バンク割込みは未完成。
全命令eZ80互換ではない。
次はメモリオペランドの演算と更新の24bitアドレス対応を進める。
VRAM256KB／MEGARAM予約枠、VDP読み出し優先・競合時CPU WAIT仕様を継承する。
