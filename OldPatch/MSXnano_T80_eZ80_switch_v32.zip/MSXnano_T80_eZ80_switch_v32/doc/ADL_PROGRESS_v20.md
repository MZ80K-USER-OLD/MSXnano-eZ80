# v20: CB形式のHL間接アクセス

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、CB形式の(HL)への
回転・シフト・BIT・RES・SETに24bit HLアドレスを使用する。
40h付きCB命令はbank 0と下位16bitを使用する。
短幅pendingとlong pendingをCBプレフィックスの先まで保持する。
演算は既存の8bit ALUを使用する。MSX標準設定は維持する。

## 検証

新規 sim/tb_cb_hl24.vhd。プログラムはベンチ内ROMに含む。
回転・シフト8種類（元T80のSLL経路を含む）、BIT／RES／SETの各8ビット、計32命令を検査。
BITの入力81はbit0とbit7が1、bit1～6が0なので、成立・不成立とbit7のSフラグを確認できる。
回転は入力81・Carry=1、RESは入力FF、SETは入力00を使用する。
メモリ結果、Aの保持、S・Z・H・P/V・N・CをPUSH AFの実際の書込みで検査。
bit5・bit3はフラグ比較の対象外。RES／SETの主要フラグ保持も確認する。
BITでは初期設定以外にメモリ書込みがないこと、他の命令では1回だけ更新することを確認。
bank 01／FF、32命令、通常／40h短幅、WAIT有無の256ケース。
既存643＋新規256、全899実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v20.log。元T80の8ファイルは基準SHA256と一致。
代表入力の検証であり、全入力値を網羅したALU検査ではない。

## 制限と実機

今回の追加対象はCB (HL)のみ。DDCB／FDCBのIX／IY変位形式は次段階。
長いsuffix＋CBの独立した試験、40h＋CB境界のIRQ／NMI専用投入試験は未実施。
v20のGowin合成・実機動作は未確認。A24のMSXメモリ接続は未実装。
MSX標準FETCH24=false、ENABLE_MIXED=falseを維持する。
新規実機COMは追加しない。既存COM／ASMをhardware_testに同梱。
直近の実機報告はv18でのスペースマンボウのプレイ成功。
これは互換動作の確認で、追加24bit機能の実機検証ではない。

ブロック命令、24bit ADD／ADC／SBC、一般suffix制御、MBASE、AFスタックのADL仕様、
高位バンク割込みとMSXメモリ接続が残る。全命令eZ80互換ではない。
VRAM256KB／MEGARAM予約枠、VDP読み出し優先・競合時CPU WAIT仕様を継承する。
