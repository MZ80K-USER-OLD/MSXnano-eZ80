# v19: メモリ演算・更新の24bitアドレス

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、以下の8bitメモリ演算・更新に
HL／IX／IYの24bitアドレスを使うように追加する。

- ADD・ADC・SUB・SBC・AND・XOR・OR・CPの(HL)／(IX+d)／(IY+d)
- INC／DEC (HL)／(IX+d)／(IY+d)

演算データは8bit。既存ALUとフラグ処理を使用し、アドレスの幅選択を拡張する。
40h指定ではbank 0と下位16bitを使用する。
MSX標準FETCH24=false、ENABLE_MIXED=falseを維持する。

## テスト

新規 sim/tb_memory_alu24.vhd。ROM定義にテストプログラムを含む。
8演算の代表入力で結果AとS・Z・H・P/V・N・CをPUSH AFの書込みで照合する。
今回のフラグ比較ではbit5・bit3を対象外とする。
INC 7F→80、DEC 80→7FでオーバーフローとCarry保持を確認する。
40h付きINC 3F→40、DEC 40→3Fも検査。
計31回の書込みのアドレス・値・順序・回数を検査する。
bank 01／FF、下位0000／FFFF、変位-128／127、HL／IX／IY、WAIT有無の48ケース。
HLには変位がなく、この軸では同じHLケースを繰り返す。
全入力値を網羅したALU試験ではない。
既存595＋新規48、全643実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v19.log。元T80の8ファイルは基準SHA256と一致。

## 実機と規模

ユーザーはv18でスペースマンボウをプレイできたことを報告（2026-10-12）。
互換設定の実機確認で、追加24bit機能の実機確認ではない。
添付Gowin PnRレポートの全体使用量はLogic 14866/20736（72%）、
CLS 9113/10368（88%）、BSRAM 45/46（98%）。
FETCH24=falseの互換構成の値で、24bit機能を有効にした規模は未測定。
CPU単体の階層別使用量はこのPnRレポートにない。

v19のGowin合成・実機動作は未確認。A24メモリ接続は未実装。
新規実機COMは追加しない。既存COM／ASMをhardware_testに同梱する。

CB／DDCB／FDCB、ブロック命令、24bit ADD／ADC／SBC、一般suffix制御、
MBASE、AFスタックのADL仕様、高位バンク割込みは未完成。
全命令eZ80互換ではない。
次はCB系メモリ命令の24bitアドレス対応を進める。
VRAM256KB／MEGARAM予約枠、VDP読み出し優先・競合時CPU WAIT仕様を継承する。
