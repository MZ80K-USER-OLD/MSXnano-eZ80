# v12 実機回帰結果（2026-10-12）

ユーザーが実機に適用してEZ80DIAG.COMを実行。
添付RESULT(1).TXTを照合し、DI／EI両ブロックの全値が期待値と一致した。

| 項目 | DI ACTUAL | EI ACTUAL |
|---|---|---|
| HL | 56 34 12 | 56 34 12 |
| IX | 88 77 66 | 88 77 66 |
| IY | BB AA 99 | BB AA 99 |
| PUSH | 56 34 | 56 34 |
| SHORT | CD AB 00 | CD AB 00 |
| SP0 | FA D7 | FA D7 |
| SP1 | FA D7 | FA D7 |

バイトはLOW→HIGH順。SP0=SP1でスタックのずれなし。
末尾の「DI only passes: suspect IRQ.」は無条件に表示する説明文で、合否判定ではない。
このCOMはv4相当の拡張検査であり、通常ADLの3バイトPUSH／POPを検証していない。
EIブロックは割込み許可状態の検査だが、実際の割込み発生回数を測定していない。
