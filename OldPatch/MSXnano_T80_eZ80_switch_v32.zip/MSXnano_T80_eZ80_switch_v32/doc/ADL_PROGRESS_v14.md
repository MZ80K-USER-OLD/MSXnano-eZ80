# v14: BC／DE／HL間接LDの24bitアドレス

FETCH24=true、ENABLE_MIXED=true、ADL_State=1で、以下の通常命令に
BC・DE・HLの上位バンクを使用する。

- LD A,(BC)／LD (BC),A
- LD A,(DE)／LD (DE),A
- LD r,(HL)／LD (HL),r（HALTを除く）
- LD (HL),n

データ幅は1バイト、アドレス幅は24bit。
40h付きの短幅指定ではbank 0と下位16bitを使用する。
MSX標準FETCH24=false、ENABLE_MIXED=falseは従来動作を維持する。
リフレッシュとI/Oのバンクは0。

## テスト

新規 sim/tb_indirect24.vhd。テストプログラムはベンチ内ROMに含む。
BC・DE・HLを異なるバンクの同一下位アドレスに設定し、書込みと読戻しを検査する。
HLをINCして次アドレスへアクセスし、FFFF越えとFFFFFFから000000への循環も確認。
40h付きBC書込み・DE読み出しとHL読み書きがbank 0へ戻ることを検査する。
入力データはCPと条件JPで照合し、不一致時はアサーションで停止する。
実際の6回の書込みについて全24bitアドレス、値、回数を検査する。
バンク基準01／7F／FD、下位9000／FFFF、WAIT有無の12ケース。
既存407＋新規12、全419実行PASS。長いLDのPython波形検査もPASS。
ログはtest_results_v14.log。元T80の8ソースは基準SHA256と一致。
全汎用レジスタのLD値を個別に検査する網羅テストは未実施。

## 制限と実機

v14はユーザーによる実機適用とスペースマンボウの動作を確認済み。
互換設定での確認であり、24bitアクセスの実機検証は未実施。A24のMSXメモリ接続は未実装。
新規実機COMは追加しない。既存COM／ASMはhardware_testに同梱。
v12での実機診断合格はdoc/HARDWARE_RESULT_v12.mdを参照。

今回のデータアクセス対応は上記LDのみ。
IX／IY変位、絶対アドレスLD、ALUの(HL)、メモリINC／DEC、CB／ブロック命令、
24bitレジスタ値のメモリ転送は今後追加する。
既存49hの3バイトストアは以前の限定仕様を維持する。
一般suffix制御、MBASE、24bit ADD／ADC／SBC、AFスタック、高位バンク割込みは未完成。
全命令eZ80互換ではない。
VRAM256KB／MEGARAM予約枠とVDP読み出し優先・競合時CPU WAIT仕様を継承する。
次はIX／IY変位付きデータアクセスの上位バンクと符号付き変位の処理を進める。
