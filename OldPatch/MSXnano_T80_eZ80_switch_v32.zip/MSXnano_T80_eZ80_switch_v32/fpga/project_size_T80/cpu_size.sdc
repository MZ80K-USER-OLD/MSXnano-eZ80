create_clock -name cpu_clk -period 18.519 -waveform {0 9.2595} [get_ports {CLK_n}] -add
