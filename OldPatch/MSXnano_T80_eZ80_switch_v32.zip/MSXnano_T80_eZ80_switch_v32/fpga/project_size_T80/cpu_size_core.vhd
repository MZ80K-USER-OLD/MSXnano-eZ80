library ieee;
use ieee.std_logic_1164.all;
entity cpu_size_core is
    port(
        RESET_n, CLK_n, clk_enable, clk_falling : in std_logic;
        WAIT_n, INT_n, NMI_n, BUSRQ_n : in std_logic;
        DI : in std_logic_vector(7 downto 0);
        A24 : out std_logic_vector(23 downto 0);
        DO : out std_logic_vector(7 downto 0);
        M1_n, MREQ_n, IORQ_n, RD_n, WR_n, RFSH_n, HALT_n, BUSAK_n : out std_logic;
        update_addr, Data_Reverse : out std_logic
    );
end;
architecture rtl of cpu_size_core is
    signal low_a:std_logic_vector(15 downto 0);
begin
    A24<=x"00" & low_a;
    cpu:entity work.G80a
    generic map( Mode=>0, IOWait=>1)
    port map(RESET_n=>RESET_n, CLK_n=>CLK_n, clk_enable=>clk_enable, clk_falling=>clk_falling,
        WAIT_n=>WAIT_n, INT_n=>INT_n, NMI_n=>NMI_n, BUSRQ_n=>BUSRQ_n, DI=>DI, DO=>DO,
        A=>low_a, M1_n=>M1_n, MREQ_n=>MREQ_n, IORQ_n=>IORQ_n, RD_n=>RD_n, WR_n=>WR_n,
        RFSH_n=>RFSH_n, HALT_n=>HALT_n, BUSAK_n=>BUSAK_n,
        update_addr=>update_addr, Data_Reverse=>Data_Reverse);
end;
