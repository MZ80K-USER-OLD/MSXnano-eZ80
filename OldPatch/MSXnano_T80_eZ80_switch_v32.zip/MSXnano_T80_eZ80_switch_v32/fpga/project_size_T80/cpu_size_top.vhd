library ieee;
use ieee.std_logic_1164.all;
entity cpu_size_top is
    port(
        RESET_n, CLK_n, clk_enable, clk_falling : in std_logic;
        WAIT_n, INT_n, NMI_n, BUSRQ_n : in std_logic;
        DI : in std_logic_vector(7 downto 0);
        observe_select : in std_logic_vector(2 downto 0);
        observe_data : out std_logic_vector(7 downto 0)
    );
end;
architecture rtl of cpu_size_top is
    signal addr:std_logic_vector(23 downto 0);
    signal data_out:std_logic_vector(7 downto 0);
    signal m1,mreq,iorq,rd,wr,rfsh,halt,busak,update,reverse:std_logic;
begin
    core:entity work.cpu_size_core
    port map(RESET_n=>RESET_n,CLK_n=>CLK_n,clk_enable=>clk_enable,clk_falling=>clk_falling,
        WAIT_n=>WAIT_n,INT_n=>INT_n,NMI_n=>NMI_n,BUSRQ_n=>BUSRQ_n,DI=>DI,DO=>data_out,A24=>addr,
        M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,
        update_addr=>update,Data_Reverse=>reverse);
    with observe_select select observe_data <=
        addr(7 downto 0) when "000",
        addr(15 downto 8) when "001",
        addr(23 downto 16) when "010",
        data_out when "011",
        m1 & mreq & iorq & rd & wr & rfsh & halt & busak when "100",
        "000000" & update & reverse when "101",
        x"00" when others;
end;
