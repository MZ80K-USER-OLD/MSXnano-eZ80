#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p verification_suffix
cd verification_suffix
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A_eZ80/${f}_ez80.vhd
done
ghdl -a --std=08 -fsynopsys ../sim/tb_indexed_cb_suffix24.vhd
for r in 0 1; do
 for s in false true; do
  for w in false true; do
   ghdl -r --std=08 -fsynopsys tb_indexed_cb_suffix24 -gREG_SELECT=$r -gTAKEN=$s -gINSERT_WAIT=$w -gBANK=1 -gSTACK_TOP=0 -gDISPLACEMENT=-128 --assert-level=error
  done
 done
done
