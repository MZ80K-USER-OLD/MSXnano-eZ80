# MSXnano T80/eZ80 v32

RLD／RRDの24ビットHLアドレスと、通常ADL RSTの3バイト復帰PC保存・バンク00移動を追加した。
JR／JR cc／DJNZは既存PC経路を継承し、符号付き変位と16／24ビット境界を追加検証した。
詳細と制限：doc/ADL_PROGRESS_v32.md。

新規3840実行は主回帰内、元T80比較8を追加。主回帰25127＋追加234＝25361実行。
ニブル行列の16384演算ベクトルと焦点ログを、GHDL実行数へ重複加算しない。

- bash run_baseline.sh：全回帰（GHDL、Python3が必要）。
- bash run_phase32.sh：新規3840実行（主回帰内）。
- python3 tools/run_phase_compat32.py：新規元T80比較8。

主ケース：tools/regression_cases_v32.json。
主ログ：test_results_v32.log。結果：verification_result_v32.json。
GHDL_WORKERSは主回帰の並列数（既定8）。

実機用Gowin：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
標準CPU設定・GPRJ・Dual Purpose Pin・SystemVerilog・制約をv31から継承。
v31はGOWIN合成・実機スペースマンボウ起動／プレイ成功の報告を受領。
v32のGOWIN合成・配置配線・使用量・実機動作は未確認。

新規COMなし。A24物理接続は次のv33、DI限定ADL実機はv34の暫定目標。
混在RSTとADL割込み／MADL／TRAP、追加95命令、全幅・前置境界は未完了。
