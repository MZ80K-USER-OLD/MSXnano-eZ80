library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_mbase_bus29 is generic(BASE:natural range 0 to 255:=1;INSERT_WAIT:boolean:=false);end;
architecture test of tb_mbase_bus29 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr:std_logic:='1';signal writes:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;

 function code(stage:natural) return bytes_t is variable m:bytes_t(0 to 255):=(others=>x"76");variable n:natural:=0;
 procedure put(x:natural) is begin m(n):=byte(x,0);n:=n+1;end;
 procedure seq(v:bytes_t) is begin for i in v'range loop m(n):=v(i);n:=n+1;end loop;end;
 begin
 if stage=0 then
 -- Reset MB must read as zero. All MB instructions preserve the flags (ORA 1; SCF => 01).
 seq((x"3E",x"01",x"B7",x"37",x"ED",x"6E",x"32",x"00",x"00",x"50"));
 put(16#3E#);put(BASE);seq((x"ED",x"6D",x"3E",x"A5",x"ED",x"6E",x"32",x"01",x"00",x"50"));
 seq((x"40",x"31",x"00",x"80",x"40",x"21",x"FF",x"FF",x"40",x"36",x"A5",x"40",x"23",x"40",x"36",x"5A"));
 seq((x"40",x"DD",x"21",x"FF",x"FF",x"40",x"DD",x"36",x"01",x"A6"));
 seq((x"40",x"FD",x"21",x"00",x"00",x"40",x"FD",x"36",x"FF",x"A7"));
 seq((x"40",x"01",x"FE",x"7F",x"3E",x"B1",x"40",x"02",x"40",x"11",x"FD",x"7F",x"3E",x"D1",x"40",x"12"));
 seq((x"3E",x"69",x"D3",x"C1",x"40",x"C3",x"00",x"10"));
 elsif stage=1 then
 seq((x"3E",x"AA",x"ED",x"6D",x"ED",x"6E",x"21",x"34",x"12",x"77",x"7E",x"32",x"00",x"90",x"5B",x"C3",x"00",x"01",x"20"));
 else
 seq((x"ED",x"6E",x"32",x"02",x"00",x"50",x"3E",x"03",x"ED",x"6D",x"3E",x"A5",x"ED",x"6E",x"32",x"03",x"00",x"50",x"40",x"F5",x"76"));
 end if;return m;end;
 constant boot:bytes_t:=code(0);constant shortcode:bytes_t:=code(1);constant finishcode:bytes_t:=code(2);
 type addr_t is array(natural range <>) of natural;
 constant addresses:addr_t:=(16#500000#,16#500001#,BASE*65536+65535,BASE*65536,BASE*65536,BASE*65536+65535,BASE*65536+16#7FFE#,BASE*65536+16#7FFD#,BASE*65536+16#1234#,BASE*65536+16#9000#,16#500002#,16#500003#,16#037FFF#,16#037FFE#);
 constant values:bytes_t:=(x"00",byte(BASE,0),x"A5",x"5A",x"A6",x"A7",x"B1",x"D1",x"AA",x"AA",byte(BASE,0),x"03",x"03",x"01");
 signal io_seen:boolean:=false;
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);


 process(all) variable n:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));
 if n>=16#200000# and n<16#200100# then di<=boot(n-16#200000#);end if;
 if n>=16#200100# and n<16#200200# then di<=finishcode(n-16#200100#);end if;
 if n>=BASE*65536+16#1000# and n<BASE*65536+16#1100# then di<=shortcode(n-BASE*65536-16#1000#);end if;
 if n=BASE*65536+16#1234# then di<=x"AA";end if;
 end if;end process;
 process(clk) variable n:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 n:=to_integer(unsigned(a24));
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "MBASE applied to refresh" severity failure;end if;
 if iorq='0' and wr='0' then assert n=16#69C1# and dout=x"69" report "MBASE applied to IO got " & integer'image(n) severity failure;io_seen<=true;end if;
 prevwr<=wr;
 if mreq='0' and wr='0' and prevwr='1' then
 assert writes<addresses'length report "extra MBASE write" severity failure;
 assert n=addresses(writes) report "MBASE bus address step " & integer'image(writes) & " got " & integer'image(n) & " expected " & integer'image(addresses(writes)) severity failure;
 assert dout=values(writes) report "MBASE bus value/flags step " & integer'image(writes) & " got " & integer'image(to_integer(unsigned(dout))) severity failure;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=14 and io_seen report "slot count/retirement" severity failure;report "PASS MBASE reset/write/read, ADL0 NOP, indirect/indexed, wrap, IO/refresh, flags";stop;end process;
 process begin wait for 2 ms;assert false report "ISA slot timeout" severity failure;end process;
end;
