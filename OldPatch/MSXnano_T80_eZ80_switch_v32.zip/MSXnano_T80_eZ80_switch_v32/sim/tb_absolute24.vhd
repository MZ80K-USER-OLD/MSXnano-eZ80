library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_absolute24 is
 generic(INSERT_WAIT:boolean:=false; CONDITION:natural:=1; TAKEN:boolean:=true; STACK_TOP:natural:=36864);
end;
architecture test of tb_absolute24 is
 signal clk:std_logic:='0';
 signal reset_n:std_logic:='0';
 signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;
 signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);
 signal a24:std_logic_vector(23 downto 0);
 signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 type ram_t is array(0 to 5) of std_logic_vector(7 downto 0);
 signal ram:ram_t:=(others=>x"A5");
 signal prev_wr:std_logic:='1';signal writes:natural:=0;
 type addr_t is array(0 to 5) of natural;
 constant addresses:addr_t:=(CONDITION*65536+STACK_TOP,STACK_TOP,0,0,0,0);
 type expected_t is array(0 to 5) of std_logic_vector(7 downto 0);
 constant expected:expected_t:=(x"11",x"22",x"00",x"00",x"00",x"00");
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:code_t:=(x"3E",x"11",x"32",x"00",x"00",x"01",x"3A",x"00",x"00",x"01",x"FE",x"11",x"C2",x"FF",x"0F",x"20",x"3E",x"22",x"40",x"32",x"00",x"00",x"40",x"3A",x"00",x"00",x"FE",x"22",x"C2",x"FF",x"0F",x"20",x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"20FFFC")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n,offset:natural;begin
 di<=x"00";
 if not is_x(a24) then
 n:=to_integer(unsigned(a24));
 for i in addresses'range loop if i<writes and n=addresses(i) then di<=ram(i);end if;end loop;
 if n>=16#20FFFC# and n<16#20FFFC#+code'length then
 offset:=n-16#20FFFC#;di<=code(offset);
 if offset=3 or offset=7 or offset=20 or offset=24 then di<=std_logic_vector(to_unsigned(STACK_TOP mod 256,8));
 elsif offset=4 or offset=8 or offset=21 or offset=25 then di<=std_logic_vector(to_unsigned(STACK_TOP/256,8));
 elsif offset=5 or offset=9 then di<=std_logic_vector(to_unsigned(CONDITION,8));
 end if;
 end if;
 if n=16#200FFF# then di<=x"76";end if;
 end if;end process;
 process(clk) variable n:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a24(15 downto 0)=a report "low address mismatch" severity failure;
 if rfsh='0' or iorq='0' then assert a24(23 downto 16)=x"00" report "refresh/IO bank" severity failure;end if;
 if mreq='0' and rd='0' then assert a24/=x"200FFF" report "indirect read value mismatch" severity failure;end if;
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 n:=to_integer(unsigned(a24));assert writes<2 report "extra memory write" severity failure;
 assert n=addresses(writes) report "wrong indirect bank/address " & integer'image(n) severity failure;
 assert dout=expected(writes) report "wrong indirect write value" severity failure;
 ram(writes)<=dout;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=2 report "missing writes" severity failure;report "PASS absolute A LD 24bit operand, fetch boundary, short width, WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "indirect timeout" severity failure;end process;
 end;
