library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_relative32 is generic(NATIVE_ADL:boolean:=true;KIND:natural range 0 to 5:=0;TAKEN:boolean:=true;INITIAL_B:natural range 0 to 255:=2;DISPLACEMENT:integer range -128 to 127:=127;POSITION:natural range 0 to 3:=0;BASE:natural range 0 to 255:=0;INSERT_WAIT:boolean:=false);end;
architecture test of tb_relative32 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr,prevrd:std_logic:='1';signal writes:natural:=0;signal started,operand_seen,completed:boolean:=false;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function location return natural is begin if NATIVE_ADL then case POSITION is when 0=>return 16#201000#;when 1=>return 16#20FFFF#;when 2=>return 16#FFFFFF#;when others=>return 0;end case;
 else case POSITION is when 0=>return BASE*65536+16#1000#;when 1=>return BASE*65536+16#FFFF#;when 2=>return BASE*65536+16#FFFE#;when others=>return BASE*65536;end case;end if;end;
 function address_step(p:natural;delta:integer) return natural is begin if NATIVE_ADL then return (integer(p)+delta) mod 16777216;else return BASE*65536+(integer(p mod 65536)+delta) mod 65536;end if;end;
 constant setup_pc:natural:=address_step(location,-32);
 function jumps return boolean is begin if KIND=0 then return true;elsif KIND=5 then return INITIAL_B/=1;else return TAKEN;end if;end;
 function expected_target return natural is begin if jumps then return address_step(location,2+DISPLACEMENT);else return address_step(location,2);end if;end;
 function flags return natural is variable x:natural:=16#95#;begin
 if KIND=1 then if not TAKEN then x:=x+64;end if;
 elsif KIND=2 then if TAKEN then x:=x+64;end if;
 elsif KIND=3 then if TAKEN then x:=x-1;end if;
 elsif KIND=4 then if not TAKEN then x:=x-1;end if;end if;return x;end;
 function setup return bytes_t is variable m:bytes_t(0 to 33):=(others=>x"00");variable n:natural:=0;
 procedure put(x:natural) is begin m(n):=byte(x,0);n:=n+1;end;
 begin
 put(16#5B#);put(1);put(16#5A#);put(INITIAL_B);put(16#A5#);
 put(16#5B#);put(16#21#);put(16#56#);put(16#34#);put(16#12#);
 put(16#5B#);put(16#31#);put(0);put(1);put(3);
 put(16#40#);put(16#31#);put(0);put(16#70#);put(16#40#);put(16#F1#);
 put(16#40#);put(16#31#);put(0);put(16#80#);
 n:=32;if KIND=0 then put(16#18#);elsif KIND=5 then put(16#10#);else put(16#20#+(KIND-1)*8);end if;
 m(33):=std_logic_vector(to_signed(DISPLACEMENT,8));return m;end;
 constant code:bytes_t:=setup;
 function finish return bytes_t is variable m:bytes_t(0 to 127):=(others=>x"76");variable n:natural:=0;
 procedure put(x:natural) is begin m(n):=byte(x,0);n:=n+1;end;
 begin
 put(16#21#);put(16#CD#);put(16#AB#);if NATIVE_ADL then put(16#67#);end if;
 put(16#5B#);put(16#ED#);put(16#43#);put(0);put(0);put(16#50#);
 put(16#5B#);put(16#32#);put(3);put(0);put(16#50#);
 put(16#5B#);put(16#22#);put(4);put(0);put(16#50#);
 put(16#5B#);put(16#ED#);put(16#73#);put(7);put(0);put(16#50#);
 put(16#40#);put(16#ED#);put(16#73#);put(0);put(16#90#);
 put(16#40#);put(16#F5#);put(16#76#);return m;end;
 constant endcode:bytes_t:=finish;
 function boot return bytes_t is variable m:bytes_t(0 to 8):=(others=>x"76");begin m(0):=x"3E";m(1):=byte(BASE,0);m(2):=x"ED";m(3):=x"6D";if NATIVE_ADL then m(4):=x"5B";else m(4):=x"40";end if;m(5):=x"C3";m(6):=byte(setup_pc,0);m(7):=byte(setup_pc,1);if NATIVE_ADL then m(8):=byte(setup_pc,2);end if;return m;end;
 constant bootcode:bytes_t:=boot;
 function offset_from(n,p:natural) return natural is begin if NATIVE_ADL then return (n+16777216-p) mod 16777216;else return (n+65536-p mod 65536) mod 65536;end if;end;
 begin clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"600000") port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 -- The completion ROM is selected after one branch. This permits -1/0 targets
 -- inside the tested instruction without turning the fixture into a loop.
 process(a24,completed,operand_seen,m1) variable n,off:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));
 off:=offset_from(n,setup_pc);if off<code'length and (NATIVE_ADL or n/65536=BASE) then di<=code(off);end if;
 if completed or (operand_seen and m1='0' and n=expected_target) then off:=offset_from(n,expected_target);if off<endcode'length and (NATIVE_ADL or n/65536=BASE) then di<=endcode(off);end if;end if;
 if n>=16#600000# and n<16#600009# then di<=bootcode(n-16#600000#);end if;
 if n=BASE*65536+16#7000# then di<=byte(flags,0);elsif n=BASE*65536+16#7001# then di<=x"A5";end if;
 end if;end process;
 process(clk) variable n,x,b:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then n:=to_integer(unsigned(a24));prevrd<=mreq or rd;
 if mreq='0' and rd='0' and prevrd='1' and rfsh='1' then
 if not completed then
  if not started and m1='0' and n=location then started<=true;
  elsif started and not operand_seen and m1='1' and n=address_step(location,1) then operand_seen<=true;
  elsif operand_seen and m1='0' then assert n=expected_target report "relative next PC got " & integer'image(n) & " expected " & integer'image(expected_target) severity failure;completed<=true;end if;
 end if;end if;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then
 assert completed report "relative wrote before branch completed" severity failure;
 b:=INITIAL_B;if KIND=5 then b:=(b+255) mod 256;end if;
 if writes<10 then assert n=16#500000#+writes report "relative snapshot address" severity failure;
 if writes<3 then x:=16#A5005A#+b*256;assert dout=byte(x,writes) report "DJNZ B8/C/BCU" severity failure;
 elsif writes=3 then assert dout=x"A5" report "relative A" severity failure;
 elsif writes<7 then if NATIVE_ADL then x:=16#67ABCD#;else x:=16#12ABCD#;end if;assert dout=byte(x,writes-4) report "relative ADL/HL" severity failure;
 else assert dout=byte(16#030100#,writes-7) report "relative SPL" severity failure;end if;
 elsif writes<12 then assert n=BASE*65536+16#9000#+writes-10 and dout=byte(16#8000#,writes-10) report "relative SPS" severity failure;
 elsif writes=12 then assert n=BASE*65536+16#7FFF# and dout=x"A5" report "relative A stack" severity failure;
 else assert writes=13 and n=BASE*65536+16#7FFE# and dout=byte(flags,0) report "relative F" severity failure;end if;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert completed and writes=14 report "relative counts" severity failure;report "PASS v32 JR/DJNZ signed displacement/PC wrap/B8/flags/mode/SP/WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "relative timeout" severity failure;end process;
end;
