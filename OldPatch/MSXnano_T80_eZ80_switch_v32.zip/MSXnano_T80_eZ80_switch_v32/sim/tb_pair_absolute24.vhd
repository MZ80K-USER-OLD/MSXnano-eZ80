library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_pair_absolute24 is
 generic(INSERT_WAIT:boolean:=false; CONDITION:natural:=1; TAKEN:boolean:=true; STACK_TOP:natural:=65535; REG_SELECT:natural range 0 to 2:=0);
end;
architecture test of tb_pair_absolute24 is
 signal clk:std_logic:='0';
 signal reset_n:std_logic:='0';
 signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;
 signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);
 signal a24:std_logic_vector(23 downto 0);
 signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 type ram_t is array(0 to 10) of std_logic_vector(7 downto 0);
 signal ram:ram_t:=(others=>x"A5");
 signal prev_wr:std_logic:='1';signal writes:natural:=0;
 type addr_t is array(0 to 10) of natural;
 constant target:natural:=CONDITION*65536+STACK_TOP;
 constant target8:natural:=(target+8) mod 16777216;
 constant target16:natural:=(target+16) mod 16777216;
 constant addresses:addr_t:=(target,(target+1) mod 16777216,(target+2) mod 16777216,target8,(target8+1) mod 16777216,(target8+2) mod 16777216,16#9000#,16#9001#,target16,(target16+1) mod 16777216,(target16+2) mod 16777216);
 type expected_t is array(0 to 10) of std_logic_vector(7 downto 0);
 constant expected:expected_t:=(x"56",x"34",x"12",x"56",x"34",x"12",x"56",x"34",x"56",x"34",x"AB");
 function select_prefix return std_logic_vector is
 begin if REG_SELECT=1 then return x"DD";elsif REG_SELECT=2 then return x"FD";else return x"00";end if;end;
 function first_short return std_logic_vector is begin if REG_SELECT=0 then return x"00";else return x"40";end if;end;
 function second_short return std_logic_vector is begin if REG_SELECT=0 then return x"40";else return select_prefix;end if;end;
 constant short1:std_logic_vector(7 downto 0):=first_short;
 constant short2:std_logic_vector(7 downto 0):=second_short;
 constant prefix:std_logic_vector(7 downto 0):=select_prefix;
 function byte0(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned(n mod 256,8));end;
 function byte1(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/256) mod 256,8));end;
 function byte2(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned(n/65536,8));end;
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:code_t:=(prefix,x"21",x"56",x"34",x"12",prefix,x"22",byte0(target),byte1(target),byte2(target),prefix,x"21",x"00",x"00",x"00",prefix,x"2A",byte0(target),byte1(target),byte2(target),prefix,x"22",byte0(target8),byte1(target8),byte2(target8),short1,short2,x"22",x"00",x"90",prefix,x"21",x"EF",x"CD",x"AB",short1,short2,x"2A",x"00",x"90",prefix,x"22",byte0(target16),byte1(target16),byte2(target16),x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n,offset:natural;begin
 di<=x"00";
 if not is_x(a24) then
 n:=to_integer(unsigned(a24));
 for i in addresses'range loop if i<writes and n=addresses(i) then di<=ram(i);end if;end loop;
 if n>=16#200000# and n<16#200000#+code'length then
 offset:=n-16#200000#;di<=code(offset);

 end if;
 if n=16#200FFF# then di<=x"76";end if;
 end if;end process;
 process(clk) variable n:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a24(15 downto 0)=a report "low address mismatch" severity failure;
 if rfsh='0' or iorq='0' then assert a24(23 downto 16)=x"00" report "refresh/IO bank" severity failure;end if;
 if mreq='0' and rd='0' then assert a24/=x"200FFF" report "indirect read value mismatch" severity failure;end if;
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 n:=to_integer(unsigned(a24));assert writes<11 report "extra memory write" severity failure;
 assert n=addresses(writes) report "wrong indirect bank/address " & integer'image(n) severity failure;
 assert dout=expected(writes) report "wrong indirect write value" severity failure;
 ram(writes)<=dout;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=11 report "missing writes" severity failure;report "PASS HL IX IY absolute 3-byte transfer, address wrap, short width and upper retention, WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "indirect timeout" severity failure;end process;
 end;
