library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_isa_slots29 is generic(SLOT:natural range 0 to 96:=0;NATIVE_ADL:boolean:=true;INSERT_WAIT:boolean:=false);end;
architecture test of tb_isa_slots29 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr:std_logic:='1';signal writes:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function startpc return natural is begin if NATIVE_ADL then return 16#200000#;else return 16#1000#;end if;end;
 constant prefixes:bytes_t:=(x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"ED",x"DD",x"DD",x"DD",x"DD",x"DD",x"DD",x"DD",x"DD",x"DD",x"DD",x"FD",x"FD",x"FD",x"FD",x"FD",x"FD",x"FD",x"FD",x"FD",x"FD");
 constant opcodes:bytes_t:=(x"00",x"01",x"02",x"03",x"04",x"07",x"08",x"09",x"0C",x"0F",x"10",x"11",x"12",x"13",x"14",x"17",x"18",x"19",x"1C",x"1F",x"20",x"21",x"22",x"23",x"24",x"27",x"28",x"29",x"2C",x"2F",x"31",x"32",x"33",x"34",x"37",x"38",x"39",x"3C",x"3E",x"3F",x"4C",x"54",x"55",x"5C",x"64",x"65",x"66",x"6C",x"6D",x"6E",x"74",x"76",x"7C",x"7D",x"7E",x"82",x"83",x"84",x"8A",x"8B",x"8C",x"92",x"93",x"94",x"9A",x"9B",x"9C",x"A4",x"AC",x"B4",x"BC",x"C2",x"C3",x"C7",x"CA",x"CB",x"D7",x"07",x"17",x"27",x"37",x"31",x"0F",x"1F",x"2F",x"3F",x"3E",x"07",x"17",x"27",x"37",x"31",x"0F",x"1F",x"2F",x"3F",x"3E");
 function expected_a return natural is begin if NATIVE_ADL and prefixes(SLOT)=x"ED" and opcodes(SLOT)=x"6E" then return 0;else return 16#5A#;end if;end;
 function base return natural is begin if NATIVE_ADL and prefixes(SLOT)=x"ED" and opcodes(SLOT)=x"6D" then return 16#5A#*65536;else return 0;end if;end;
 function seed(t:natural) return natural is begin return 16#123456#+t*16#010101#;end;
 function makecode return bytes_t is variable m:bytes_t(0 to 255):=(others=>x"76");variable n:natural:=0;
 procedure put(x:natural) is begin m(n):=byte(x,0);n:=n+1;end;
 procedure ix(t:natural) is begin if t=3 then put(16#DD#);elsif t=4 then put(16#FD#);end if;end;
 begin
 for t in 0 to 5 loop put(16#5B#);ix(t);if t=0 then put(1);elsif t=1 then put(16#11#);elsif t=5 then put(16#31#);else put(16#21#);end if;
 for i in 0 to 2 loop put(to_integer(unsigned(byte(seed(t),i))));end loop;end loop;
 put(16#40#);put(16#31#);put(0);put(16#80#);
 put(16#3E#);put(16#5A#);put(16#B7#);put(16#37#);
 put(to_integer(unsigned(prefixes(SLOT))));put(to_integer(unsigned(opcodes(SLOT))));
 for t in 0 to 5 loop put(16#5B#);ix(t);
 if t=3 or t=4 then put(16#22#);else put(16#ED#);if t=0 then put(16#43#);elsif t=1 then put(16#53#);elsif t=2 then put(16#63#);else put(16#73#);end if;end if;
 put(t*3);put(0);put(16#50#);end loop;
 put(16#40#);put(16#F5#);put(16#76#);return m;end;
 constant code:bytes_t:=makecode;
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>NATIVE_ADL,RESET_PC=>std_logic_vector(to_unsigned(startpc,24)))
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);

 process(all) variable n:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));if n>=startpc and n<startpc+code'length then di<=code(n-startpc);end if;end if;end process;
 process(clk) variable n,x:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert iorq='1' report "reserved slot issued IO" severity failure;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then n:=to_integer(unsigned(a24));
 if writes<18 then assert n=16#500000#+writes report "reserved slot changed address/SP" severity failure;
 assert dout=byte(seed(writes/3),writes mod 3) report "reserved slot changed register" severity failure;
 elsif writes=18 then assert n=base+16#7FFF# and dout=byte(expected_a,0) report "reserved slot changed A/stack" severity failure;
 elsif writes=19 then assert n=base+16#7FFE# and dout=x"0D" report "reserved slot changed flags/stack" severity failure;
 else assert false report "extra write" severity failure;end if;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=20 report "slot count/retirement" severity failure;report "PASS ISA slots preserve registers/flags/stack; MB instructions obey ADL";stop;end process;
 process begin wait for 2 ms;assert false report "ISA slot timeout" severity failure;end process;
end;
