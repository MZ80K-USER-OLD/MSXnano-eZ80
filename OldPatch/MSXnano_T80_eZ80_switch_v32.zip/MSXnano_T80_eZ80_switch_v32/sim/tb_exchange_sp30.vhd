library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_exchange_sp30 is
 generic(NATIVE_ADL:boolean:=true;KIND:natural range 0 to 2:=0;TARGET:natural range 0 to 2:=0;WIDTH:natural range 0 to 4:=0;ALT_BANK:boolean:=false;VALUE:natural range 0 to 3:=3;BASE:natural range 0 to 255:=0;CHAIN:boolean:=false;INSERT_WAIT:boolean:=false);
end;
architecture test of tb_exchange_sp30 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr:std_logic:='1';signal writes:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 type numbers_t is array(natural range <>) of natural;
 type program_t is record code:bytes_t(0 to 1023);addresses:numbers_t(0 to 127);values:bytes_t(0 to 127);count:natural;length:natural;end record;
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function startpc return natural is begin if NATIVE_ADL then return 16#200000#;else return BASE*65536+16#1000#;end if;end;
 function wide return boolean is begin if WIDTH=0 then return NATIVE_ADL;else return WIDTH=2 or WIDTH=4;end if;end;
 function prefix return natural is begin case WIDTH is when 1=>return 16#40#;when 2=>return 16#49#;when 3=>return 16#52#;when others=>return 16#5B#;end case;end;
 function seed return natural is begin case VALUE is when 0=>return 0;when 1=>return 16#00FFFF#;when 2=>return 16#FFFFFF#;when others=>return 16#123456#;end case;end;
 function build return program_t is
 variable p:program_t;variable n,c,stage,bank,src,tmp:natural:=0;variable alt:boolean:=false;
 variable regs:numbers_t(0 to 7):=(16#A1B2C3#,16#234567#,seed,16#D4E5F6#,16#89ABCD#,(seed+16#654321#) mod 16777216,seed,seed);
 variable sps:natural:=16#1357#;variable spl:natural:=16#B23456#;
 procedure put(x:natural) is begin p.code(n):=byte(x,0);n:=n+1;end;
 procedure ix(t:natural) is begin if t=3 then put(16#DD#);elsif t=4 then put(16#FD#);end if;end;
 procedure load(t,v:natural) is begin put(16#5B#);ix(t);if t=0 then put(1);elsif t=1 then put(16#11#);elsif t=5 then put(16#31#);else put(16#21#);end if;for i in 0 to 2 loop put(to_integer(unsigned(byte(v,i))));end loop;end;
 procedure expect(addr,v,size:natural) is begin for i in 0 to size-1 loop p.addresses(c):=addr+i;p.values(c):=byte(v,i);c:=c+1;end loop;end;
 procedure store(t,addr,v:natural) is begin put(16#5B#);ix(t);
 if t=3 or t=4 then put(16#22#);else put(16#ED#);if t=0 then put(16#43#);elsif t=1 then put(16#53#);elsif t=2 then put(16#63#);else put(16#73#);end if;end if;
 for i in 0 to 2 loop put(to_integer(unsigned(byte(addr,i))));end loop;expect(addr,v,3);end;
 procedure snapshot is variable address:natural;begin
 address:=16#500000#+stage*32;
 if alt then put(16#D9#);end if;
 for b in 0 to 1 loop
  for t in 0 to 2 loop store(t,address,regs(b*3+t));address:=address+3;end loop;put(16#D9#);
 end loop;
 if alt then put(16#D9#);end if;
 store(3,address,regs(6));store(4,address+3,regs(7));store(5,address+6,spl);
 put(16#40#);put(16#ED#);put(16#73#);put(stage*2);put(16#90#);expect(BASE*65536+16#9000#+stage*2,sps,2);
 end;
 begin
 p.code:=(others=>x"76");p.addresses:=(others=>0);p.values:=(others=>x"00");
 for b in 0 to 1 loop for t in 0 to 2 loop load(t,regs(b*3+t));end loop;put(16#D9#);end loop;
 load(3,regs(6));load(4,regs(7));load(5,spl);
 put(16#40#);put(16#31#);put(sps mod 256);put(sps/256);
 if ALT_BANK then put(16#D9#);alt:=true;end if;
 put(16#3E#);put(16#5A#);put(16#B7#);put(16#37#);
 snapshot;
 for step in 1 to 2 loop
  if CHAIN then if wide then put(16#40#);else put(16#5B#);end if;end if;
  if WIDTH/=0 then put(prefix);end if;
  bank:=0;if alt then bank:=3;end if;
  if KIND=0 then
   put(16#EB#);tmp:=regs(bank+1);
   if wide then regs(bank+1):=regs(bank+2);regs(bank+2):=tmp;
   else regs(bank+1):=(tmp/65536)*65536+regs(bank+2) mod 65536;regs(bank+2):=(regs(bank+2)/65536)*65536+tmp mod 65536;end if;
  elsif KIND=1 then put(16#D9#);alt:=not alt;
  else if TARGET=1 then put(16#DD#);elsif TARGET=2 then put(16#FD#);end if;put(16#F9#);
   src:=regs(bank+2);if TARGET>0 then src:=regs(5+TARGET);end if;
   if wide then spl:=src;else sps:=src mod 65536;end if;
  end if;
  -- Native immediate LD after each operation checks suffix retirement and unchanged ADL.
  bank:=0;if alt then bank:=3;end if;put(1);put(16#CD#);put(16#AB#);
  if NATIVE_ADL then put(16#67#);regs(bank):=16#67ABCD#;
  else regs(bank):=(regs(bank)/65536)*65536+16#ABCD#;end if;
  stage:=step;snapshot;
 end loop;
 -- Capture A/F using a safe short stack after all SPS/SPL observations.
 put(16#40#);put(16#31#);put(0);put(16#80#);put(16#40#);put(16#F5#);
 expect(BASE*65536+16#7FFF#,16#5A#,1);expect(BASE*65536+16#7FFE#,16#0D#,1);
 put(16#76#);p.count:=c;p.length:=n;return p;
 end;
 constant program:program_t:=build;
 function boot return bytes_t is variable m:bytes_t(0 to 8):=(others=>x"76");begin
 m(0):=x"3E";m(1):=byte(BASE,0);m(2):=x"ED";m(3):=x"6D";
 if NATIVE_ADL then m(4):=x"5B";else m(4):=x"40";end if;
 m(5):=x"C3";m(6):=byte(startpc,0);m(7):=byte(startpc,1);if NATIVE_ADL then m(8):=byte(startpc,2);end if;return m;end;
 constant bootcode:bytes_t:=boot;
 begin
 assert not CHAIN or WIDTH/=0 report "chain requires final explicit suffix" severity failure;
 assert KIND/=1 or (WIDTH=0 and not CHAIN) report "EXX test uses native instruction" severity failure;
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"600000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));
 if n>=startpc and n<startpc+program.length then di<=program.code(n-startpc);end if;
 if n>=16#600000# and n<16#600009# then di<=bootcode(n-16#600000#);end if;end if;end process;
 process(clk) variable n:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert iorq='1' report "unexpected IO" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then n:=to_integer(unsigned(a24));
 assert writes<program.count report "extra write" severity failure;
 assert n=program.addresses(writes) report "snapshot address " & integer'image(writes) & " got " & integer'image(n) severity failure;
 assert dout=program.values(writes) report "snapshot value " & integer'image(writes) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(program.values(writes)))) severity failure;
 writes<=writes+1;end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=program.count report "missing writes" severity failure;report "PASS v30 EX/EXX/LD SP registers, alternate banks, SPS/SPL, suffix retirement, A/F, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "v30 timeout" severity failure;end process;
end;
