library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_pushpop24 is
 generic(INSERT_WAIT:boolean:=false; CONDITION:natural:=0; TAKEN:boolean:=true; STACK_TOP:natural:=196609);
end;
architecture test of tb_pushpop24 is
 signal clk:std_logic:='0';
 signal reset_n:std_logic:='0';
 signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;
 signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);
 signal a24:std_logic_vector(23 downto 0);
 signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 type ram_t is array(0 to 2) of std_logic_vector(7 downto 0);
 signal ram:ram_t:=(others=>x"A5");
 signal prev_wr:std_logic:='1';signal writes:natural:=0;
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:code_t:=(x"31",x"01",x"00",x"03",x"01",x"56",x"34",x"12",x"C5",x"01",x"00",x"00",x"00",x"C1",x"C5",x"C1",x"11",x"56",x"34",x"12",x"D5",x"11",x"00",x"00",x"00",x"D1",x"D5",x"D1",x"21",x"56",x"34",x"12",x"E5",x"21",x"00",x"00",x"00",x"E1",x"E5",x"E1",x"DD",x"21",x"56",x"34",x"12",x"DD",x"E5",x"DD",x"21",x"00",x"00",x"00",x"DD",x"E1",x"DD",x"E5",x"DD",x"E1",x"FD",x"21",x"56",x"34",x"12",x"FD",x"E5",x"FD",x"21",x"00",x"00",x"00",x"FD",x"E1",x"FD",x"E5",x"FD",x"E1",x"76");
 function slot(addr:natural) return integer is
 begin
 for k in 1 to 3 loop
 if addr=(STACK_TOP+16777216-k) mod 16777216 then return k-1;end if;
 end loop;return -1;end;
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"010000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:integer;variable idx:integer;begin
 di<=x"00";
 if not is_x(a24) then
 n:=to_integer(unsigned(a24));idx:=slot(n);
 if idx>=0 then di<=ram(idx);end if;
 if n>=16#010000# and n<16#010000#+code'length then di<=code(n-16#010000#);end if;
 -- SPL immediate bank varies by test.
 if n=16#010003# then di<=std_logic_vector(to_unsigned(STACK_TOP/65536,8));end if;
 end if;end process;
 process(clk) variable idx:integer;begin
 if rising_edge(clk) and reset_n='1' then
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 idx:=slot(to_integer(unsigned(a24)));assert idx>=0 report "stack write outside three-byte frame" severity failure;
 assert idx=writes mod 3 report "stack byte address order" severity failure;
 case idx is
 when 0 => assert dout=x"12" report "upper byte mismatch after PUSH/POP" severity failure;
 when 1 => assert dout=x"34" report "middle byte mismatch" severity failure;
 when 2 => assert dout=x"56" report "low byte mismatch" severity failure;
 when others => null;end case;
 ram(idx)<=dout;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=30 report "PUSH write count" severity failure;report "PASS ADL PUSH/POP BC DE HL IX IY, upper restore, SPL boundary, WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "PUSH/POP timeout" severity failure;end process;
 end;
