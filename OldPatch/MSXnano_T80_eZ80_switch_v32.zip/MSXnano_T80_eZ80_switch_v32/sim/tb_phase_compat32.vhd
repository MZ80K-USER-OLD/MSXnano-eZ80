library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_phase_compat32 is
 generic(INSERT_WAIT:boolean:=false; SEED:boolean:=false;CARRY_IN:boolean:=false);
end;
architecture test of tb_phase_compat32 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';
 signal phase:natural range 0 to 15:=0;signal ce,cf:std_logic;
 signal a,b:std_logic_vector(15 downto 0);signal di,doa,dob:std_logic_vector(7 downto 0);
 signal ca,cb:std_logic_vector(7 downto 0);
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function makecode return bytes_t is variable m:bytes_t(0 to 255):=(others=>x"76");variable n:natural:=0;
 procedure seq(v:bytes_t) is begin for i in v'range loop m(n):=v(i);n:=n+1;end loop;end;
 procedure put(x:natural) is begin m(n):=std_logic_vector(to_unsigned(x,8));n:=n+1;end;
 begin
 seq((x"31",x"00",x"F0",x"3E",x"C9",x"32",x"00",x"00",x"21",x"00",x"90"));
 if SEED then seq((x"3E",x"81"));else seq((x"3E",x"00"));end if;seq((x"77",x"3E",x"A5",x"B7"));
 if CARRY_IN then put(16#37#);end if;
 seq((x"ED",x"6F",x"F5",x"C1",x"ED",x"43",x"00",x"91",x"ED",x"67",x"F5",x"C1",x"ED",x"43",x"02",x"91"));
 for v in 0 to 7 loop put(16#C7#+v*8);end loop;
 seq((x"06",x"03",x"10",x"FE",x"18",x"00",x"20",x"00",x"28",x"00",x"30",x"00",x"38",x"00",x"F5",x"C1",x"ED",x"43",x"04",x"91",x"76"));return m;end;
 constant code:bytes_t:=makecode;
 type memory_t is array(0 to 65535) of std_logic_vector(7 downto 0);
 function initial_memory return memory_t is variable m:memory_t:=(others=>x"00");begin m(0):=x"C3";m(1):=x"00";m(2):=x"01";for i in 1 to 7 loop m(i*8):=x"C9";end loop;for i in code'range loop m(256+i):=code(i);end loop;return m;end;
 signal mem:memory_t:=initial_memory;
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 original:entity work.G80a port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>ca(0),MREQ_n=>ca(1),IORQ_n=>ca(2),RD_n=>ca(3),WR_n=>ca(4),RFSH_n=>ca(5),HALT_n=>ca(6),BUSAK_n=>ca(7),A=>a,update_addr=>open,DI=>di,DO=>doa,Data_Reverse=>open);
 extended:entity work.G80A_eZ80 generic map(FETCH24=>false,ENABLE_MIXED=>false) port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>cb(0),MREQ_n=>cb(1),IORQ_n=>cb(2),RD_n=>cb(3),WR_n=>cb(4),RFSH_n=>cb(5),HALT_n=>cb(6),BUSAK_n=>cb(7),A=>b,A24=>open,update_addr=>open,DI=>di,DO=>dob,Data_Reverse=>open);
 process(all) begin di<=x"00";if not is_x(a) then di<=mem(to_integer(unsigned(a)));end if;end process;
 process(clk) begin if rising_edge(clk) and reset_n='1' and ca(1)='0' and ca(4)='0' and not is_x(a) then mem(to_integer(unsigned(a)))<=doa;end if;end process;
 process(clk) begin if falling_edge(clk) and reset_n='1' then
 assert ca=cb report "compat bus control differs from original T80" severity failure;
 assert a=b report "compat address differs from original T80" severity failure;
 if ca(4)='0' then assert doa=dob report "compat write data/registers/flags differ from original T80" severity failure;end if;
 end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until ca(6)='0';wait for 100 ns;assert cb(6)='0' report "compat HALT" severity failure;report "PASS default RLD/RRD/RST/JR/DJNZ bus cycles/registers/flags match original T80";stop;end process;
 process begin wait for 10 ms;assert false report "compat timeout" severity failure;end process;
 end;
