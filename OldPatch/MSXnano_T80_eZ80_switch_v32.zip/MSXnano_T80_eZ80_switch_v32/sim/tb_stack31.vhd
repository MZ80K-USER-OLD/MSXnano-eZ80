library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_stack31 is generic(NATIVE_ADL:boolean:=true;KIND:natural range 0 to 2:=0;TARGET:natural range 0 to 2:=0;WIDTH:natural range 0 to 4:=0;BOUNDARY:natural range 0 to 3:=0;VALUE:natural range 0 to 3:=0;FLAG_SEED:natural range 0 to 255:=0;BASE:natural range 0 to 255:=0;ALT_BANK:boolean:=false;CHAIN:boolean:=false;INSERT_WAIT:boolean:=false);end;
architecture test of tb_stack31 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr,prevrd:std_logic:='1';signal writes,reads:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);type nums_t is array(natural range <>) of natural;
 type plan_t is record code:bytes_t(0 to 1023);wa:nums_t(0 to 191);wv:bytes_t(0 to 191);ra:nums_t(0 to 15);rv:bytes_t(0 to 15);nw,nr,length:natural;end record;
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function wide return boolean is begin if WIDTH=0 then return NATIVE_ADL;else return WIDTH=2 or WIDTH=4;end if;end;
 function count return natural is begin if wide then return 3;else return 2;end if;end;
 function prefix return natural is begin case WIDTH is when 1=>return 16#40#;when 2=>return 16#49#;when 3=>return 16#52#;when others=>return 16#5B#;end case;end;
 function spl_initial return natural is begin case BOUNDARY is when 0=>return 16#020100#;when 1=>return 16#010000#;when 2=>return 0;when others=>return 16#FFFFFF#;end case;end;
 function sps_initial return natural is begin case BOUNDARY is when 0=>return 16#8100#;when 1=>return 0;when 2=>return 16#FFFF#;when others=>return 1;end case;end;
 function source_value return natural is begin case VALUE is when 0=>return 0;when 1=>return 16#FFFFFF#;when 2=>return 16#123456#;when others=>return 16#80AA55#;end case;end;
 function a_value return natural is begin case VALUE is when 0=>return 0;when 1=>return 255;when 2=>return 129;when others=>return 90;end case;end;
 function stack_address(i:natural) return natural is variable x,limit:natural;variable delta:integer:=i;begin
 if KIND=0 then delta:=integer(i)-count;end if;
 if wide then x:=spl_initial;limit:=16777216;else x:=sps_initial;limit:=65536;end if;
 x:=(integer(x)+delta) mod limit;if not wide then x:=x+BASE*65536;end if;return x;end;
 function memory_value return natural is begin if KIND=2 then return 16#D73412#;else return 16#7C0000#+a_value*256+FLAG_SEED;end if;end;
 -- Third byte is deliberately nonzero for standalone POP; it must be read then discarded.
 function initial_byte(i:natural) return std_logic_vector is begin if KIND=0 then return x"CC";else return byte(memory_value,i);end if;end;
 signal ram:bytes_t(0 to 2):=(initial_byte(0),initial_byte(1),initial_byte(2));
 function startpc return natural is begin if NATIVE_ADL then return 16#200000#;else return BASE*65536+16#1000#;end if;end;
 function build return plan_t is variable p:plan_t;variable n,w,r,stage,bank,targ:natural:=0;variable sp:natural:=sps_initial;variable sl:natural:=spl_initial;variable regs:nums_t(0 to 7):=(16#A15678#,16#B23456#,16#C3789A#,16#D489AB#,16#E59ABC#,16#F6ABCD#,16#176543#,16#287654#);variable old,mem,v:natural;
 procedure put(x:natural) is begin p.code(n):=byte(x,0);n:=n+1;end;
 procedure ix(t:natural) is begin if t=3 then put(16#DD#);elsif t=4 then put(16#FD#);end if;end;
 procedure load(t,v:natural) is begin put(16#5B#);ix(t);if t=0 then put(1);elsif t=1 then put(16#11#);elsif t=5 then put(16#31#);else put(16#21#);end if;for i in 0 to 2 loop put(to_integer(unsigned(byte(v,i))));end loop;end;
 procedure ew(addr,v,size:natural) is begin for i in 0 to size-1 loop p.wa(w):=addr+i;p.wv(w):=byte(v,i);w:=w+1;end loop;end;
 procedure er(addr:natural;v:std_logic_vector) is begin p.ra(r):=addr;p.rv(r):=v;r:=r+1;end;
 procedure store(t,addr,v:natural) is begin put(16#5B#);ix(t);if t=3 or t=4 then put(16#22#);else put(16#ED#);if t=0 then put(16#43#);elsif t=1 then put(16#53#);elsif t=2 then put(16#63#);else put(16#73#);end if;end if;for i in 0 to 2 loop put(to_integer(unsigned(byte(addr,i))));end loop;ew(addr,v,3);end;
 procedure snapshot is variable address:natural;begin address:=16#500000#+stage*32;if ALT_BANK then put(16#D9#);end if;
 for b in 0 to 1 loop for t in 0 to 2 loop store(t,address,regs(b*3+t));address:=address+3;end loop;put(16#D9#);end loop;
 if ALT_BANK then put(16#D9#);end if;store(3,address,regs(6));store(4,address+3,regs(7));store(5,address+6,sl);
 put(16#40#);put(16#ED#);put(16#73#);put(stage*2);put(16#90#);ew(BASE*65536+16#9000#+stage*2,sp,2);end;
 procedure operation(op:natural) is begin if CHAIN then if wide then put(16#40#);else put(16#5B#);end if;end if;if WIDTH/=0 then put(prefix);end if;if op=16#E3# then ix(2+TARGET);end if;put(op);end;
 procedure sentinel is begin put(1);put(16#CD#);put(16#AB#);bank:=0;if ALT_BANK then bank:=3;end if;if NATIVE_ADL then put(16#67#);regs(bank):=16#67ABCD#;else regs(bank):=(regs(bank)/65536)*65536+16#ABCD#;end if;end;
 begin p.code:=(others=>x"76");p.wa:=(others=>0);p.wv:=(others=>x"00");p.ra:=(others=>0);p.rv:=(others=>x"00");
 bank:=0;if ALT_BANK then bank:=3;end if;targ:=bank+2;if TARGET>0 then targ:=5+TARGET;end if;regs(targ):=source_value;
 for b in 0 to 1 loop for t in 0 to 2 loop load(t,regs(b*3+t));end loop;put(16#D9#);end loop;load(3,regs(6));load(4,regs(7));load(5,sl);
 if ALT_BANK then put(16#D9#);end if;
 put(16#40#);put(16#31#);put(0);put(16#70#);put(16#40#);put(16#F1#);
 er(BASE*65536+16#7000#,byte(FLAG_SEED,0));er(BASE*65536+16#7001#,byte(a_value,0));
 put(16#40#);put(16#31#);put(sp mod 256);put(sp/256);
 if KIND=0 then operation(16#F5#);
  for j in count-1 downto 0 loop v:=FLAG_SEED;if j=1 then v:=a_value;elsif j=2 then v:=0;end if;ew(stack_address(j),v,1);end loop;
  if wide then sl:=(sl+16777216-count) mod 16777216;else sp:=(sp+65536-count) mod 65536;end if;
  snapshot;put(16#AF#);operation(16#F1#);
  for i in 0 to count-1 loop v:=FLAG_SEED;if i=1 then v:=a_value;elsif i=2 then v:=0;end if;er(stack_address(i),byte(v,0));end loop;
  if wide then sl:=spl_initial;else sp:=sps_initial;end if;
 elsif KIND=1 then operation(16#F1#);
  for i in 0 to count-1 loop er(stack_address(i),initial_byte(i));end loop;
  if wide then sl:=(sl+count) mod 16777216;else sp:=(sp+count) mod 65536;end if;
 else
  mem:=memory_value;
  for step in 0 to 1 loop operation(16#E3#);old:=regs(targ);
   for i in 0 to count-1 loop er(stack_address(i),byte(mem,i));end loop;
   for i in 0 to count-1 loop ew(stack_address(i),to_integer(unsigned(byte(old,i))),1);end loop;
   if wide then regs(targ):=mem;else regs(targ):=(old/65536)*65536+mem mod 65536;end if;
   mem:=old;sentinel;stage:=step;snapshot;
  end loop;
 end if;
 if KIND/=2 then sentinel;stage:=1;snapshot;end if;
 -- A and all flag bits must survive EX or be restored by POP. Observe through short PUSH AF.
 put(16#40#);put(16#31#);put(0);put(16#80#);put(16#40#);put(16#F5#);ew(BASE*65536+16#7FFF#,a_value,1);ew(BASE*65536+16#7FFE#,FLAG_SEED,1);
 put(16#76#);p.nw:=w;p.nr:=r;p.length:=n;return p;end;
 constant program:plan_t:=build;
 function boot return bytes_t is variable b:bytes_t(0 to 8):=(others=>x"76");begin b(0):=x"3E";b(1):=byte(BASE,0);b(2):=x"ED";b(3):=x"6D";if NATIVE_ADL then b(4):=x"5B";else b(4):=x"40";end if;b(5):=x"C3";b(6):=byte(startpc,0);b(7):=byte(startpc,1);if NATIVE_ADL then b(8):=byte(startpc,2);end if;return b;end;
 constant bootcode:bytes_t:=boot;
 begin
 assert WIDTH/=0 or not CHAIN report "chain requires explicit final prefix" severity failure;
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"600000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));if n>=startpc and n<startpc+program.length then di<=program.code(n-startpc);end if;if n>=16#600000# and n<16#600009# then di<=bootcode(n-16#600000#);end if;
 if n=BASE*65536+16#7000# then di<=byte(FLAG_SEED,0);elsif n=BASE*65536+16#7001# then di<=byte(a_value,0);end if;
 for i in 0 to count-1 loop if n=stack_address(i) then di<=ram(i);end if;end loop;end if;end process;
 process(clk) variable n:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then n:=to_integer(unsigned(a24));
 assert iorq='1' report "unexpected IO" severity failure;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then
 assert writes<program.nw report "extra write" severity failure;assert n=program.wa(writes) report "write address " & integer'image(writes) & " got " & integer'image(n) & " expected " & integer'image(program.wa(writes)) severity failure;
 assert dout=program.wv(writes) report "write byte " & integer'image(writes) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(program.wv(writes)))) severity failure;
 for i in 0 to count-1 loop if n=stack_address(i) then ram(i)<=dout;end if;end loop;writes<=writes+1;end if;
 prevrd<=mreq or rd;if mreq='0' and rd='0' and prevrd='1' and m1='1' and rfsh='1' then
 if (n=BASE*65536+16#7000# or n=BASE*65536+16#7001#) then assert reads<program.nr and n=program.ra(reads) and di=program.rv(reads) report "seed read" severity failure;reads<=reads+1;
 else for i in 0 to count-1 loop if n=stack_address(i) then assert reads<program.nr and n=program.ra(reads) and di=program.rv(reads) report "stack read address/data/order " & integer'image(reads) severity failure;reads<=reads+1;end if;end loop;end if;end if;
 end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=program.nw and reads=program.nr report "stack counts writes=" & integer'image(writes) & " reads=" & integer'image(reads) severity failure;report "PASS v31 AF/EX SP byte order, pad, wrap, registers, SP, A/F, suffix, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "v31 timeout" severity failure;end process;
end;
