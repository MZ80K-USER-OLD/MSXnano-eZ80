-- v31: flag observations explicitly use SPS (40 F5/40 F1); native AF now uses SPL.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_add24 is
 generic(INSERT_WAIT:boolean:=false; SHORT_MODE:boolean:=false; DESTINATION:natural range 0 to 2:=0; SOURCE:natural range 0 to 3:=0; VECTOR:natural range 0 to 7:=0);
end;
architecture test of tb_add24 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;signal prev_wr:std_logic:='1';signal snapshots,stack_writes:natural:=0;
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 type numbers_t is array(0 to 7) of natural;
 constant left_values:numbers_t:=(16#00FFFF#,16#FFFFFF#,16#0F0000#,16#000FFF#,16#800000#,16#800001#,16#1200FF#,16#345678#);
 constant right_values:numbers_t:=(1,1,16#010000#,1,16#7FFFFF#,16#800001#,1,16#123456#);
 constant lhs:natural:=left_values(VECTOR);constant rhs:natural:=right_values(VECTOR);
 function right_operand return natural is begin
 if SOURCE=2 then return lhs;elsif SOURCE=3 and SHORT_MODE then return 16#1357#;else return rhs;end if;end;
 constant operand:natural:=right_operand;
 function result_value return natural is begin
 if SHORT_MODE then return (lhs/65536)*65536+(lhs mod 65536+operand mod 65536) mod 65536;
 else return (lhs+operand) mod 16777216;end if;end;
 function seed return natural is begin case VECTOR mod 3 is when 0=>return 0;when 1=>return 16#80#;when others=>return 3;end case;end;
 function flag_value return std_logic_vector is variable f,limit:natural;begin
 case VECTOR mod 3 is when 0=>f:=16#44#;when 1=>f:=16#80#;when others=>f:=4;end case;
 if (lhs mod 4096)+(operand mod 4096)>=4096 then f:=f+16;end if;
 if SHORT_MODE then limit:=65536;else limit:=16777216;end if;
 if (lhs mod limit)+(operand mod limit)>=limit then f:=f+1;end if;
 return byte(f,0);end;
 function mode_prefix return std_logic_vector is begin if SHORT_MODE then return x"40";else return x"00";end if;end;
 function index_prefix return std_logic_vector is begin if DESTINATION=1 then return x"DD";elsif DESTINATION=2 then return x"FD";else return mode_prefix;end if;end;
 function first_prefix return std_logic_vector is begin if DESTINATION=0 then return x"00";else return mode_prefix;end if;end;
 function carry_seed return std_logic_vector is begin if VECTOR mod 2=1 then return x"37";else return x"00";end if;end;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:bytes_t:=(x"01",byte(rhs,0),byte(rhs,1),byte(rhs,2),x"11",byte(rhs,0),byte(rhs,1),byte(rhs,2),
 x"21",byte(lhs,0),byte(lhs,1),byte(lhs,2),x"DD",x"21",byte(lhs,0),byte(lhs,1),byte(lhs,2),x"FD",x"21",byte(lhs,0),byte(lhs,1),byte(lhs,2),
 x"40",x"31",x"57",x"13",x"31",byte(rhs,0),byte(rhs,1),byte(rhs,2),
 x"3E",byte(seed,0),x"B7",carry_seed,x"2F",first_prefix,index_prefix,byte(9+16*SOURCE,0),
 x"40",x"31",x"FF",x"FF",x"40",x"F5",
 x"ED",x"43",x"00",x"90",x"30",x"ED",x"53",x"03",x"90",x"30",
 x"22",x"06",x"90",x"30",x"DD",x"22",x"09",x"90",x"30",x"FD",x"22",x"0C",x"90",x"30",
 x"ED",x"73",x"0F",x"90",x"30",x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin di<=x"00";if not is_x(a24) then n:=to_integer(unsigned(a24));if n>=16#200000# and n<16#200000#+code'length then di<=code(n-16#200000#);end if;end if;end process;
 process(clk) variable n,j,expected:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a=a24(15 downto 0) report "low address mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 prev_wr<=wr;if wr='0' and prev_wr='1' then n:=to_integer(unsigned(a24));
 if n=16#FFFE# then assert dout=byte(255-seed,0) report "ADD changed A" severity failure;stack_writes<=stack_writes+1;
 elsif n=16#FFFD# then assert (dout and x"D7")=flag_value report "ADD flags got " & integer'image(to_integer(unsigned(dout and x"D7"))) & " expected " & integer'image(to_integer(unsigned(flag_value))) severity failure;stack_writes<=stack_writes+1;
 else
  assert n=16#309000#+snapshots and snapshots<18 report "snapshot address" severity failure;j:=snapshots/3;
  if j<2 or j=5 then expected:=rhs;elsif j=DESTINATION+2 then expected:=result_value;else expected:=lhs;end if;
  assert dout=byte(expected,snapshots mod 3) report "ADD register byte " & integer'image(snapshots) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(byte(expected,snapshots mod 3)))) severity failure;
  snapshots<=snapshots+1;
 end if;end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;
 assert snapshots=18 and stack_writes=2 report "ADD write counts" severity failure;
 report "PASS ADD24 HL IX IY, pair/self/SPL, bit11 H, carry, SZPV, short, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "ADD timeout" severity failure;end process;
 end;
