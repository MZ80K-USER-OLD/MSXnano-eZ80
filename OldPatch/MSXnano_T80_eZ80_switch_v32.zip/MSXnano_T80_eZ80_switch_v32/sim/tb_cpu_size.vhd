library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_cpu_size is
 generic(WIDE:boolean:=false; INSERT_WAIT:boolean:=false);
end;
architecture test of tb_cpu_size is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';
 signal phase:natural range 0 to 15:=0;
 signal ce,cf,wait_n:std_logic:='1';
 signal addr:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak,update,reverse:std_logic;
 type observations_t is array(0 to 5) of std_logic_vector(7 downto 0);
 signal observations:observations_t;
 signal prev_wr:std_logic:='1';signal writes:natural:=0;
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant short_rom:code_t:=(x"21",x"34",x"12",x"22",x"00",x"F0",x"76");
 constant wide_rom:code_t:=(x"21",x"56",x"34",x"12",x"22",x"FF",x"FF",x"12",x"76");
 type bytes_t is array(0 to 2) of std_logic_vector(7 downto 0);
 constant wide_expected:bytes_t:=(x"56",x"34",x"12");
begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 -- Six identical simulated cores observe all mux pages simultaneously.
 -- The Gowin project contains only one CPU and an externally selected page.
 pages:for i in 0 to 5 generate
 dut:entity work.cpu_size_top port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,
 WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',DI=>di,
 observe_select=>std_logic_vector(to_unsigned(i,3)),observe_data=>observations(i));
 end generate;
 addr<=observations(2) & observations(1) & observations(0);
 dout<=observations(3);
 m1<=observations(4)(7);mreq<=observations(4)(6);iorq<=observations(4)(5);rd<=observations(4)(4);
 wr<=observations(4)(3);rfsh<=observations(4)(2);halt<=observations(4)(1);busak<=observations(4)(0);
 update<=observations(5)(1);reverse<=observations(5)(0);
 process(all) variable n:natural;begin
 di<=x"00";
 if not is_x(addr) then
 n:=to_integer(unsigned(addr));
 if WIDE then if n<wide_rom'length then di<=wide_rom(n);end if;
 else if n<short_rom'length then di<=short_rom(n);end if;end if;
 end if;end process;
 process(clk) variable n:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(addr) then
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 n:=to_integer(unsigned(addr));
 if WIDE then
 assert writes<3 report "extra wide write" severity failure;
 assert n=16#12FFFF#+writes report "wide A24 observation/bank crossing" severity failure;
 assert dout=wide_expected(writes) report "wide data byte" severity failure;
 else
 assert writes<2 and n=16#F000#+writes report "short address/count" severity failure;
 if writes=0 then assert dout=x"34" severity failure;else assert dout=x"12" severity failure;end if;
 end if;writes<=writes+1;
 end if;
 if rfsh='0' then assert addr(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;
 if WIDE then assert writes=3 severity failure;else assert writes=2 severity failure;end if;
 report "PASS CPU size wrapper: memory writes, observable A24 and WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "size wrapper timeout" severity failure;end process;
end;
