library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use std.env.all;
entity tb_mbase_irq29 is generic(BASE:natural range 0 to 255:=1;KIND:natural range 0 to 3:=1;INSERT_WAIT:boolean:=false);end;
architecture test of tb_mbase_irq29 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr:std_logic:='1';signal writes:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;


 signal irq,nmi:std_logic:='1';signal vector_seen,ack_seen:boolean:=false;
 type stack_t is array(0 to 1) of std_logic_vector(7 downto 0);signal stack:stack_t:=(others=>x"00");signal prevrd:std_logic:='1';signal stack_reads:natural:=0;
 function code(booting:boolean) return bytes_t is variable m:bytes_t(0 to 127):=(others=>x"00");variable n:natural:=0;
 procedure put(x:natural) is begin m(n):=byte(x,0);n:=n+1;end;
 begin
 if booting then put(16#3E#);put(BASE);put(16#ED#);put(16#6D#);put(16#40#);put(16#C3#);put(0);put(16#10#);
 else
 put(16#31#);put(0);put(16#80#);put(16#3E#);put(16#40#);put(16#ED#);put(16#47#);
 put(16#ED#);if KIND=0 then put(16#46#);elsif KIND=2 then put(16#5E#);else put(16#56#);end if;
 put(16#3E#);put(16#5A#);put(16#FB#);
 while n<40 loop put(0);end loop;
 put(16#5B#);put(16#32#);put(0);put(0);put(16#50#);
 put(16#ED#);put(16#73#);put(0);put(16#91#);put(16#76#);
 end if;return m;end;
 constant boot:bytes_t:=code(true);constant maincode:bytes_t:=code(false);
 function vector return natural is begin if KIND=0 then return 8;elsif KIND=1 then return 56;elsif KIND=2 then return 16#9000#;else return 102;end if;end;
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>irq,NMI_n=>nmi,BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);



 process begin wait until a24=std_logic_vector(to_unsigned(BASE*65536+16#1010#,24)) and mreq='0' and rd='0';
 if KIND=3 then nmi<='0';else irq<='0';end if;wait until vector_seen;nmi<='1';irq<='1';wait;end process;
 process(all) variable n,lo:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));lo:=n mod 65536;
 if n>=16#200000# and n<16#200080# then di<=boot(n-16#200000#);end if;
 if n/65536=BASE then
 if lo>=16#1000# and lo<16#1080# then di<=maincode(lo-16#1000#);end if;
 if lo=vector then di<=x"3C";elsif lo=vector+1 then di<=x"ED";elsif lo=vector+2 then if KIND=3 then di<=x"45";else di<=x"4D";end if;end if;
 if lo=16#40AA# then di<=x"00";elsif lo=16#40AB# then di<=x"90";end if;
 if lo=16#7FFF# then di<=stack(0);elsif lo=16#7FFE# then di<=stack(1);end if;
 end if;
 if iorq='0' then if KIND=0 then di<=x"CF";else di<=x"AA";end if;end if;
 end if;end process;
 process(clk) variable n,lo:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then n:=to_integer(unsigned(a24));lo:=n mod 65536;
 if iorq='0' and m1='0' then ack_seen<=true;end if;
 if mreq='0' and rd='0' and m1='0' and lo=vector then assert n/65536=BASE report "interrupt vector bank" severity failure;vector_seen<=true;end if;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then
 case writes is
 when 0 => assert n=BASE*65536+16#7FFF# and dout=x"10" report "IRQ stack high" severity failure;stack(0)<=dout;
 when 1 => assert n=BASE*65536+16#7FFE# and dout=x"11" report "IRQ stack low got " & integer'image(to_integer(unsigned(dout))) severity failure;stack(1)<=dout;
 when 2 => assert n=16#500000# and dout=x"5B" report "IRQ handler/return" severity failure;
 when 3 => assert n=BASE*65536+16#9100# and dout=x"00" report "IRQ SPS low" severity failure;
 when 4 => assert n=BASE*65536+16#9101# and dout=x"80" report "IRQ SPS high" severity failure;
 when others => assert false report "IRQ extra write" severity failure;
 end case;writes<=writes+1;end if;
 prevrd<=mreq or rd;if mreq='0' and rd='0' and prevrd='1' and (lo=16#7FFF# or lo=16#7FFE#) then assert n/65536=BASE report "IRQ return stack bank" severity failure;stack_reads<=stack_reads+1;end if;
 end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=5 and vector_seen and stack_reads=2 and (KIND=3 or ack_seen) report "IRQ counts writes=" & integer'image(writes) & " reads=" & integer'image(stack_reads) & " vector=" & boolean'image(vector_seen) severity failure;report "PASS MBASE Z80-mode IM0/IM1/IM2/NMI vector, SPS, RETI/RETN return";stop;end process;
 process begin wait for 2 ms;assert false report "ISA slot timeout" severity failure;end process;
end;
