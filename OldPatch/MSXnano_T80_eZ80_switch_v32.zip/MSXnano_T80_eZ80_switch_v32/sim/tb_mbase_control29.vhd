library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_mbase_control29 is
 generic(BASE:natural range 0 to 255:=1; NATIVE_ADL:boolean:=true; LONG_TARGET:boolean:=false; EXPLICIT_SUFFIX:boolean:=true; KIND:natural range 0 to 2:=1; CONDITION:natural range 0 to 8:=8; TAKEN:boolean:=true; RET_TAKEN:boolean:=true; BOUNDARY:natural range 0 to 2:=0; REG_SELECT:natural range 0 to 2:=0; INSERT_WAIT:boolean:=false);
end;
architecture test of tb_mbase_control29 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr,prevread:std_logic:='1';signal stack_writes,stack_reads,snapshots:natural:=0;
 signal callee_seen,ret_fall_seen:boolean:=false;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 type addresses_t is array(0 to 3) of natural;
 signal ram:bytes_t(0 to 3):=(others=>x"00");
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function origin return natural is begin if NATIVE_ADL then if BOUNDARY=2 then return 16#FFFFE0#;elsif BOUNDARY=1 then return 16#20FFE0#;else return 16#201000#;end if;else if BOUNDARY=0 then return 16#1000#;else return 16#FFE0#;end if;end if;end;
 function sps return natural is begin if BOUNDARY=0 then return 16#8000#;elsif BOUNDARY=1 then return 0;else return 1;end if;end;
 function spl return natural is begin if BOUNDARY=0 then return 16#030101#;elsif BOUNDARY=1 then return 16#040000#;else return 0;end if;end;
 function target return natural is begin if LONG_TARGET then return 16#309000#;else return BASE*65536+16#9000#;end if;end;
 function pc_address(i:natural) return natural is begin if NATIVE_ADL then return (origin+i) mod 16777216;else return BASE*65536+(origin+i) mod 65536;end if;end;
 function call_end return natural is variable n:natural:=31;begin if EXPLICIT_SUFFIX then n:=n+1;end if;if KIND=2 then if REG_SELECT/=0 then n:=n+1;end if;return n+1;end if;n:=n+3;if LONG_TARGET then n:=n+1;end if;return n;end;
 constant retpc:natural:=pc_address(call_end);
 function actual_taken return boolean is begin return TAKEN or CONDITION=8 or KIND=2;end;
 constant does_transfer:boolean:=actual_taken;
 function seed_a(t:boolean) return natural is begin
  if CONDITION=0 or CONDITION=4 then if t then return 1;else return 0;end if;
  elsif CONDITION=1 or CONDITION=5 then if t then return 0;else return 1;end if;
  elsif CONDITION=6 then if t then return 1;else return 128;end if;
  elsif CONDITION=7 then if t then return 128;else return 1;end if;else return 0;end if;end;
 function carry(t:boolean) return boolean is begin return (CONDITION=2 and not t) or (CONDITION=3 and t);end;
 function prefix return natural is begin
  if KIND=0 then if LONG_TARGET then return 16#5B#;else return 16#40#;end if;
  elsif KIND=2 then if LONG_TARGET then return 16#49#;else return 16#52#;end if;
  elsif LONG_TARGET then if NATIVE_ADL then return 16#5B#;else return 16#52#;end if;
  else if NATIVE_ADL then return 16#49#;else return 16#40#;end if;end if;end;
 function return_prefix return natural is begin if LONG_TARGET then return 16#5B#;else return 16#49#;end if;end;
 function makecode(is_callee:boolean) return bytes_t is variable mem:bytes_t(0 to 159):=(others=>x"76");variable n:natural:=0;variable mode:boolean;
  procedure put(x:natural) is begin mem(n):=byte(x,0);n:=n+1;end;
  procedure flags(t:boolean) is begin put(16#3E#);put(seed_a(t));put(16#B7#);if carry(t) then put(16#37#);else put(0);end if;end;
  procedure snapshot is begin
   put(16#5B#);put(16#ED#);put(16#43#);put(0);put(16#90#);put(16#40#);
   put(16#5B#);put(16#ED#);put(16#73#);put(3);put(16#90#);put(16#40#);
   put(16#40#);put(16#ED#);put(16#73#);put(6);put(16#90#);put(16#76#);
  end;
  procedure finish(m:boolean) is begin put(1);put(16#CD#);put(16#AB#);if m then put(16#67#);end if;snapshot;end;
 begin
  if is_callee then
   if KIND=1 then
    flags(RET_TAKEN);
    if EXPLICIT_SUFFIX then put(return_prefix);end if;
    if CONDITION=8 then put(16#C9#);else put(16#C0#+8*CONDITION);end if;
    if EXPLICIT_SUFFIX then put(return_prefix);end if;put(16#C9#);
   else finish(LONG_TARGET);end if;
  else
   put(16#5B#);put(16#31#);put(spl mod 256);put((spl/256) mod 256);put(spl/65536);
   put(16#40#);put(16#31#);put(sps mod 256);put(sps/256);
   if KIND=2 then put(16#5B#);if REG_SELECT=1 then put(16#DD#);elsif REG_SELECT=2 then put(16#FD#);end if;put(16#21#);put(target mod 256);put((target/256) mod 256);put(target/65536);end if;
   flags(TAKEN);while n<31 loop put(0);end loop;
   if EXPLICIT_SUFFIX then put(prefix);end if;
   if KIND=2 then if REG_SELECT=1 then put(16#DD#);elsif REG_SELECT=2 then put(16#FD#);end if;put(16#E9#);
   else
    if CONDITION=8 then if KIND=1 then put(16#CD#);else put(16#C3#);end if;
    elsif KIND=1 then put(16#C4#+8*CONDITION);else put(16#C2#+8*CONDITION);end if;
    put(target mod 256);put((target/256) mod 256);if LONG_TARGET then put(target/65536);end if;
   end if;
   assert n=call_end report "test call offset" severity failure;
   finish(NATIVE_ADL);
  end if;return mem;end;
 constant code:bytes_t:=makecode(false);constant subcode:bytes_t:=makecode(true);
 function frame_count return natural is variable n:natural:=2;begin if KIND/=1 or not does_transfer then return 0;end if;if NATIVE_ADL then n:=n+1;end if;if EXPLICIT_SUFFIX then n:=n+1;end if;return n;end;
 constant nf:natural:=frame_count;
 function frame_addresses return addresses_t is variable x:addresses_t:=(others=>0);begin
  if EXPLICIT_SUFFIX and not LONG_TARGET then
   x(0):=BASE*65536+(sps+65535) mod 65536;x(1):=BASE*65536+(sps+65534) mod 65536;
   x(2):=(spl+16777215) mod 16777216;x(3):=(spl+16777214) mod 16777216;
  elsif LONG_TARGET then for i in 0 to 3 loop x(i):=(spl+16777215-i) mod 16777216;end loop;
  else x(0):=BASE*65536+(sps+65535) mod 65536;x(1):=BASE*65536+(sps+65534) mod 65536;end if;return x;end;
 constant fa:addresses_t:=frame_addresses;
 function frame_data(i:natural) return std_logic_vector is begin
  if EXPLICIT_SUFFIX and i=nf-1 then if NATIVE_ADL then return x"03";else return x"02";end if;
  elsif EXPLICIT_SUFFIX and not LONG_TARGET then if i=0 then return byte(retpc,1);elsif i=1 then return byte(retpc,0);else return byte(retpc,2);end if;
  elsif NATIVE_ADL then return byte(retpc,2-i);else return byte(retpc,1-i);end if;end;
 function final_mode return boolean is begin if KIND=1 or not does_transfer then return NATIVE_ADL;else return LONG_TARGET;end if;end;

 function boot return bytes_t is variable m:bytes_t(0 to 8):=(others=>x"76");variable p:natural;
 begin
 m(0):=x"3E";m(1):=byte(BASE,0);m(2):=x"ED";m(3):=x"6D";
 p:=origin;
 if NATIVE_ADL then m(4):=x"5B";else m(4):=x"40";end if;
 m(5):=x"C3";m(6):=byte(p,0);m(7):=byte(p,1);if NATIVE_ADL then m(8):=byte(p,2);end if;return m;
 end;
 constant bootcode:bytes_t:=boot;
 begin
 process begin for i in 0 to 3 loop for j in 0 to 3 loop if i<nf and j<nf and i/=j then assert fa(i)/=fa(j) report "test stacks overlap" severity failure;end if;end loop;end loop;wait;end process;
 assert EXPLICIT_SUFFIX or LONG_TARGET=NATIVE_ADL report "native width mismatch" severity failure;
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,ENABLE_EZ80_ISA=>true,RESET_ADL=>true,RESET_PC=>x"600000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n,off:natural;begin di<=x"76";if not is_x(a24) then
 n:=to_integer(unsigned(a24));if NATIVE_ADL then off:=(n+16777216-origin) mod 16777216;else off:=(n+65536-origin) mod 65536;end if;
 if off<code'length and (NATIVE_ADL or n/65536=BASE) then di<=code(off);end if;
 if n>=target and n<target+subcode'length then di<=subcode(n-target);end if;
 for i in 0 to 3 loop if i<stack_writes and n=fa(i) then di<=ram(i);end if;end loop;
 if n>=16#600000# and n<16#600009# then di<=bootcode(n-16#600000#);end if;end if;end process;
 process(clk) variable n,x:natural;variable ram_read:boolean;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 n:=to_integer(unsigned(a24));assert a=a24(15 downto 0) report "low address mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 if mreq='0' and rd='0' and m1='0' then
  if n=target then callee_seen<=true;end if;
  if KIND=1 and ((EXPLICIT_SUFFIX and n=target+6) or (not EXPLICIT_SUFFIX and n=target+5)) then ret_fall_seen<=true;end if;
 end if;
 prevread<=mreq or rd;
 if mreq='0' and rd='0' and prevread='1' and m1='1' and rfsh='1' then
  ram_read:=false;for i in 0 to 3 loop if i<stack_writes and n=fa(i) then ram_read:=true;end if;end loop;
  if ram_read then stack_reads<=stack_reads+1;end if;
 end if;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then
  if n>=16#409000# and n<16#409006# then
   assert n=16#409000#+snapshots report "snapshot address" severity failure;
   if snapshots<3 then x:=16#ABCD#;if final_mode then x:=16#67ABCD#;end if;else x:=spl;end if;
   assert dout=byte(x,snapshots mod 3) report "result/mode/SPL snapshot " & integer'image(snapshots) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(byte(x,snapshots mod 3)))) severity failure;snapshots<=snapshots+1;
  elsif n=BASE*65536+16#9006# or n=BASE*65536+16#9007# then
   assert snapshots>=6 and snapshots<8 report "SPS snapshot order" severity failure;assert dout=byte(sps,snapshots-6) report "SPS restored" severity failure;snapshots<=snapshots+1;
  else
   assert stack_writes<nf report "extra stack write at " & integer'image(n) severity failure;
   assert n=fa(stack_writes) report "stack write address " & integer'image(stack_writes) & " got " & integer'image(n) & " expected " & integer'image(fa(stack_writes)) severity failure;
   assert dout=frame_data(stack_writes) report "return frame byte " & integer'image(stack_writes) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(frame_data(stack_writes)))) severity failure;
   ram(stack_writes)<=dout;stack_writes<=stack_writes+1;
  end if;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;
 assert ret_fall_seen=(KIND=1 and does_transfer and CONDITION/=8 and not RET_TAKEN) report "conditional RET fall-through" severity failure;
 assert callee_seen=does_transfer and stack_writes=nf and stack_reads=nf and snapshots=8 report "control transfer/counts callee=" & boolean'image(callee_seen) & " writes=" & integer'image(stack_writes) & " reads=" & integer'image(stack_reads) & " snapshots=" & integer'image(snapshots) severity failure;
 report "PASS V2 JP/CALL/RET conditions, mode, mixed SPS/SPL frame, boundaries, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "V2 control timeout" severity failure;end process;
end;
