library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_suffix_absolute281 is
 generic(NATIVE_ADL:boolean:=true; SUFFIX:natural range 0 to 3:=0; TARGET:natural range 0 to 6:=0; BOUNDARY:natural range 0 to 2:=0; LOADING:boolean:=false; EXPLICIT_SUFFIX:boolean:=true; INSERT_WAIT:boolean:=false);
end;
architecture test of tb_suffix_absolute281 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prevwr:std_logic:='1';signal writes:natural:=0;signal data_writes:natural:=0;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function startpc return natural is begin if NATIVE_ADL then return 16#200000#;else return 16#1000#;end if;end;
 function raw_address return natural is begin case BOUNDARY is when 0=>return 16#017FFE#;when 1=>return 16#01FFFF#;when others=>return 16#FFFFFF#;end case;end;
 function prefix return natural is begin case SUFFIX is when 0=>return 16#40#;when 1=>return 16#49#;when 2=>return 16#52#;when others=>return 16#5B#;end case;end;
 constant data_long:boolean:=(SUFFIX mod 2)=1;constant immediate_long:boolean:=SUFFIX>=2;
 constant initial:natural:=16#A15678#;constant v:natural:=16#B23412#;
 constant raw:natural:=raw_address;
 function address_at(i:natural) return natural is begin if data_long then if immediate_long then return (raw+i) mod 16777216;else return (raw mod 65536+i) mod 16777216;end if;else return (raw+i) mod 65536;end if;end;
 function amount return natural is begin if TARGET=6 then return 1;elsif data_long then return 3;else return 2;end if;end;
 constant size:natural:=amount;
 function opcode(t:natural) return natural is begin case t is when 0=>return 1;when 1=>return 16#11#;when 5=>return 16#31#;when others=>return 16#21#;end case;end;
 function makecode return bytes_t is variable mem:bytes_t(0 to 255):=(others=>x"76");variable n:natural:=0;
  procedure put(x:natural) is begin mem(n):=byte(x,0);n:=n+1;end;
  procedure ix(t:natural) is begin if t=3 then put(16#DD#);elsif t=4 then put(16#FD#);end if;end;
  procedure load(t,x:natural) is begin put(16#5B#);ix(t);put(opcode(t));put(x mod 256);put((x/256) mod 256);put(x/65536);end;
  procedure snapshot(t,offset:natural) is begin
   put(16#5B#);
   if t=3 or t=4 then ix(t);put(16#22#);else put(16#ED#);if t=0 then put(16#43#);elsif t=1 then put(16#53#);elsif t=2 then put(16#63#);else put(16#73#);end if;end if;
   put(offset);put(16#90#);put(16#30#);
  end;
 begin
  for t in 0 to 5 loop load(t,initial);end loop;
  put(16#40#);put(16#31#);put(16#57#);put(16#13#); -- independent SPS
  put(16#3E#);put(16#A5#);
  if EXPLICIT_SUFFIX then put(prefix);end if;
  if TARGET=3 or TARGET=4 then ix(TARGET);if LOADING then put(16#2A#);else put(16#22#);end if;
  elsif TARGET=6 then if LOADING then put(16#3A#);else put(16#32#);end if;
  elsif TARGET=2 then if LOADING then put(16#2A#);else put(16#22#);end if;
  else put(16#ED#);if TARGET=0 then if LOADING then put(16#4B#);else put(16#43#);end if;
  elsif TARGET=1 then if LOADING then put(16#5B#);else put(16#53#);end if;
  else if LOADING then put(16#7B#);else put(16#73#);end if;end if;end if;
  put(raw mod 256);put((raw/256) mod 256);if immediate_long then put(raw/65536);end if;
  -- Native LD immediately after tested LD checks instruction length, mode and suffix retirement.
  if TARGET=0 then put(16#11#);else put(1);end if;put(16#CD#);put(16#AB#);if NATIVE_ADL then put(16#67#);end if;
  for t in 0 to 5 loop snapshot(t,t*3);end loop;
  put(16#40#);put(16#ED#);put(16#73#);put(16#12#);put(16#90#);
  put(16#5B#);put(16#32#);put(16#20#);put(16#90#);put(16#30#);put(16#76#);
  return mem;
 end;
 constant code:bytes_t:=makecode;
 function expected(t:natural) return natural is variable x:natural:=initial;begin
  if t=TARGET and LOADING then
   if t=5 and not data_long then x:=initial;
   elsif data_long then x:=v;
   else x:=(initial/65536)*65536+v mod 65536;end if;
  end if;
  if (TARGET=0 and t=1) or (TARGET/=0 and t=0) then
   if NATIVE_ADL then x:=16#67ABCD#;else x:=(x/65536)*65536+16#ABCD#;end if;
  end if;return x;end;
 begin
 assert EXPLICIT_SUFFIX or (NATIVE_ADL and SUFFIX=3) or (not NATIVE_ADL and SUFFIX=0) report "native absolute width mismatch" severity failure;
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,ENABLE_SUFFIX_V2=>true,RESET_ADL=>NATIVE_ADL,RESET_PC=>std_logic_vector(to_unsigned(startpc,24)))
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin di<=x"76";if not is_x(a24) then n:=to_integer(unsigned(a24));if n>=startpc and n<startpc+code'length then di<=code(n-startpc);end if;
 if LOADING then for i in 0 to size-1 loop if n=address_at(i) then di<=byte(v,i);end if;end loop;end if;end if;end process;
 process(clk) variable n,x:natural;begin if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a=a24(15 downto 0) report "address low mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 prevwr<=wr;if mreq='0' and wr='0' and prevwr='1' then n:=to_integer(unsigned(a24));
 if n>=16#309000# and n<16#309012# then
  assert n=16#309000#+writes report "native/long snapshot address " & integer'image(n) severity failure;
  x:=expected(writes/3);
  assert dout=byte(x,writes mod 3) report "snapshot " & integer'image(writes) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(byte(x,writes mod 3)))) severity failure;
 elsif n=16#9012# or n=16#9013# then
  assert writes<20 and n=16#9012#+writes-18 report "SPS snapshot address" severity failure;
  x:=16#1357#;if TARGET=5 and LOADING and not data_long then x:=v mod 65536;end if;
  assert dout=byte(x,writes-18) report "SPS snapshot value" severity failure;
 elsif n=16#309020# then
  assert writes=20 report "A snapshot order" severity failure;
  x:=16#A5#;if TARGET=6 and LOADING then x:=v mod 256;end if;
  assert dout=byte(x,0) report "A snapshot value" severity failure;
 else
  assert not LOADING and data_writes<size and n=address_at(data_writes) report "absolute write address " & integer'image(n) severity failure;
  x:=initial;if TARGET=5 and not data_long then x:=16#1357#;elsif TARGET=6 then x:=16#A5#;end if;
  assert dout=byte(x,data_writes) report "absolute write byte " & integer'image(data_writes) severity failure;
  data_writes<=data_writes+1;
 end if;
 if (n>=16#309000# and n<16#309012#) or n=16#309020# or n=16#9012# or n=16#9013# then writes<=writes+1;end if;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=21 and ((LOADING and data_writes=0) or (not LOADING and data_writes=size)) report "snapshot/data count" severity failure;report "PASS absolute V2 address/data widths, bank wrap, registers, SPS/SPL, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "suffix LD timeout" severity failure;end process;
end;
