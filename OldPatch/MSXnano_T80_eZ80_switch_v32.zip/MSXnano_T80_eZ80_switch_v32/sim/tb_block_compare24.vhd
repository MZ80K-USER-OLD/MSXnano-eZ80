-- v31: flag observations explicitly use SPS (40 F5/40 F1); native AF now uses SPL.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_block_compare24 is
 generic(INSERT_WAIT:boolean:=false; HIGH_REPEAT:boolean:=false; REPEATING:boolean:=false; DECREMENTING:boolean:=false; SHORT_MODE:boolean:=false; ADDRESS_CASE:natural range 0 to 2:=0; VALUE_CASE:natural range 0 to 4:=0; STOP_CASE:natural range 0 to 3:=0; CARRY_IN:boolean:=true);
end;
architecture test of tb_block_compare24 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prev_wr,prev_read:std_logic:='1';signal reads,snapshots,stack_writes:natural:=0;
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function direction return integer is begin if DECREMENTING then return -1;else return 1;end if;end;
 constant step:integer:=direction;
 function source_base return natural is begin
  if ADDRESS_CASE=0 then if DECREMENTING then return 16#010000#;else return 16#01FFFF#;end if;
  elsif ADDRESS_CASE=1 then if DECREMENTING then return 0;else return 16#FFFFFF#;end if;
  else return 16#7F8000#;end if;end;
 function count_initial return natural is begin
  if HIGH_REPEAT then return 16#010001#;elsif REPEATING then return 3;
  elsif VALUE_CASE=1 then return 16#010000#;elsif VALUE_CASE=2 then return 16#010001#;
  elsif VALUE_CASE=3 then return 0;else return 1;end if;end;
 constant src:natural:=source_base;constant dst:natural:=16#7E1234#;constant count:natural:=count_initial;
 function amount return natural is begin if HIGH_REPEAT then return 2;elsif REPEATING then if STOP_CASE=0 then return 1;elsif STOP_CASE=1 then return 2;else return 3;end if;else return 1;end if;end;
 constant nbytes:natural:=amount;
 function final_pointer(base:natural) return natural is begin
  if SHORT_MODE then return (base/65536)*65536+(base mod 65536+step*nbytes) mod 65536;
  else return (base+step*nbytes) mod 16777216;end if;end;
 function final_count return natural is begin
  if SHORT_MODE then return (count/65536)*65536+(count mod 65536-nbytes) mod 65536;
  else return (count-nbytes) mod 16777216;end if;end;
 function pointer_address(base:natural;i:natural) return natural is begin
  if SHORT_MODE then return (base mod 65536+step*i) mod 65536;
  else return (base+step*i) mod 16777216;end if;end;
 function operand(i:natural) return natural is begin
  if REPEATING then
   if not HIGH_REPEAT and STOP_CASE/=3 and i=STOP_CASE then return 16#40#;
   elsif i=0 then return 16#41#;elsif i=1 then return 16#3F#;else return 16#C0#;end if;
  else
   case VALUE_CASE is
    when 0=>return 16#40#;when 1=>return 16#41#;when 2=>return 16#3F#;when 3=>return 16#30#;when others=>return 16#C0#;
   end case;
  end if;end;
 function expected_flags return std_logic_vector is variable c,r,f:natural;begin
  c:=final_count;if SHORT_MODE then c:=c mod 65536;end if;
  r:=(16#40#-operand(nbytes-1)) mod 256;f:=2;
  if CARRY_IN then f:=f+1;end if;
  if r>=128 then f:=f+128;end if;if r=0 then f:=f+64;end if;
  if (operand(nbytes-1) mod 16)>0 then f:=f+16;end if;
  if c/=0 then f:=f+4;end if;return byte(f,0);end;
 function carry_seed return std_logic_vector is begin if CARRY_IN then return x"37";else return x"00";end if;end;
 function opcode return std_logic_vector is variable n:natural:=16#A1#;begin
  if DECREMENTING then n:=n+8;end if;if REPEATING then n:=n+16;end if;return byte(n,0);end;
 function prefix return std_logic_vector is begin if SHORT_MODE then return x"40";else return x"00";end if;end;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:bytes_t:=(x"01",byte(count,0),byte(count,1),byte(count,2),
 x"11",byte(dst,0),byte(dst,1),byte(dst,2),x"21",byte(src,0),byte(src,1),byte(src,2),
 x"3E",x"40",x"B7",carry_seed,prefix,x"ED",opcode,x"40",x"F5",
 x"ED",x"43",x"00",x"90",x"30",x"ED",x"53",x"03",x"90",x"30",x"ED",x"63",x"06",x"90",x"30",x"76");
 begin
 assert not(HIGH_REPEAT and (not REPEATING or SHORT_MODE)) report "invalid high repeat test" severity failure;
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin
 di<=x"00";if not is_x(a24) then n:=to_integer(unsigned(a24));
 for i in 0 to nbytes-1 loop if n=pointer_address(src,i) then di<=byte(operand(i),0);end if;end loop;
 if n>=16#200000# and n<16#200000#+code'length then di<=code(n-16#200000#);end if;
 end if;end process;
 process(clk) variable n,j,expected:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a=a24(15 downto 0) report "low address mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 prev_read<=mreq or rd;
 if mreq='0' and rd='0' and prev_read='1' and rfsh='1' and m1='1' then
  n:=to_integer(unsigned(a24));
  if n<16#200000# or n>=16#200000#+code'length then
   assert reads<nbytes report "too many compare reads" severity failure;
   assert n=pointer_address(src,reads) report "compare source address " & integer'image(n) severity failure;
   reads<=reads+1;
  end if;
 end if;
 prev_wr<=wr;if wr='0' and prev_wr='1' then n:=to_integer(unsigned(a24));
 if n=16#FFFE# then assert dout=x"40" report "compare changed A" severity failure;stack_writes<=stack_writes+1;
 elsif n=16#FFFD# then assert (dout and x"D7")=expected_flags report "block flags" severity failure;stack_writes<=stack_writes+1;
 else
  assert n=16#309000#+snapshots and snapshots<9 report "snapshot address" severity failure;j:=snapshots/3;
  if j=0 then expected:=final_count;elsif j=1 then expected:=dst;else expected:=final_pointer(src);end if;
  assert dout=byte(expected,snapshots mod 3) report "block register snapshot byte " & integer'image(snapshots) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(byte(expected,snapshots mod 3)))) severity failure;
  snapshots<=snapshots+1;
 end if;end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin
 if HIGH_REPEAT then wait until reads=2;wait for 100 ns;
 report "PASS compare repeat continues beyond 16bit count boundary";stop;end if;wait;
 end process;
 process begin wait until halt='0';wait for 100 ns;
 assert reads=nbytes and snapshots=9 and stack_writes=2 report "compare read/write counts" severity failure;
 report "PASS compare24 result, registers, flags, early match, count termination, short, WAIT";stop;end process;
 process begin wait for 2 ms;assert false report "compare timeout" severity failure;end process;
 end;
