# MSXnano T80/eZ80 v27

ブロックI/O 8命令のHLメモリアクセスとポインタ更新を24bit化。
Bは8bitの反復カウンタを維持し、ADL用のフラグと40短幅指定に対応する。
詳細: doc/ADL_PROGRESS_v27.md。

実機用Gowinプロジェクト: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
v26はユーザーが合成・スペースマンボウ起動／プレイを確認済み。
記録: doc/HARDWARE_RESULT_v26.md。v27のGowin合成・実機動作は未確認。
互換設定とプロジェクト設定を継承。24bit物理メモリ接続は未実装で、ADL追加機能はシミュレーション確認。
新規実機COMは追加せず、既存hardware_testのCOM／ASMを同梱する。

検証の再実行（GHDL、Python3が必要）:
- bash run_baseline.sh: 4271ケースと元T80とのブロックI/O互換32ケース。
- bash run_block_io24.sh: ADLブロックI/O 576ケース（全回帰に含む）。
- python3 tools/run_block_io_compat.py: 元T80との互換32ケース。
- bash run_indexed_cb_suffix.sh: 幅指定解除8ケース。
- bash run_size_smoke.sh: 規模測定用3構成×WAIT有無6ケース。

ログ: test_results_v27.log、test_results_block_io_v27.log、test_results_compat_v27.log、
test_results_suffix_v27.log、test_results_size_v27.log。
ADC／SBCの内訳: test_results_adc_sbc_v27.log、test_results_adc_sbc_sign_v27.log。
全回帰計画: tools/regression_cases_v27.json。GHDL_WORKERSで並列数を指定（標準8）。
結果一覧: verification_result_v27.json。
規模測定用3プロジェクト（27 I/O）の手順: doc/ADL_PROGRESS_v21.md。
測定用ビットストリームを実機へ書き込まないこと。

検証結果: 全回帰4271＋元T80比較32＋幅指定解除8＋規模測定6＝4317実行PASS。
