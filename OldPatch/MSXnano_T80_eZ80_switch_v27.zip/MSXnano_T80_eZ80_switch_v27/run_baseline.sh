#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/run_regression_parallel.py
python3 tools/run_block_io_compat.py
