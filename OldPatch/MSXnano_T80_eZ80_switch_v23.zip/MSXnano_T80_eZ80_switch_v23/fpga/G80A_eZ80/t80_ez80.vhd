-- Extension fork: Z80 baseline only; ADL not implemented yet.
--
-- Z80 compatible microprocessor core
--
-- Version : 0250_T80 (+k04)
--
-- Copyright (c) 2001-2002 Daniel Wallner (jesus@opencores.org)
--
-- All rights reserved
--
-- Redistribution and use in source and synthezised forms, with or without
-- modification, are permitted provided that the following conditions are met:
--
-- Redistributions of source code must retain the above copyright notice,
-- this list of conditions and the following disclaimer.
--
-- Redistributions in synthesized form must reproduce the above copyright
-- notice, this list of conditions and the following disclaimer in the
-- documentation and/or other materials provided with the distribution.
--
-- Neither the name of the author nor the names of other contributors may
-- be used to endorse or promote products derived from this software without
-- specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
-- AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
-- PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE
-- LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
-- CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
-- SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
-- INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
-- CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
-- ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.
--
-- Please report bugs to the author, but before you do so, please
-- make sure that this is not a derivative work and that
-- you have the latest version of this file.
--
-- The latest version of this file can be found at:
--  http://www.opencores.org/cvsweb.shtml/T80_eZ80/
--
-- Limitations :
--
-- File history :
--
--  0208 : First complete release
--  0210 : Fixed wait and halt
--  0211 : Fixed Refresh addition and IM 1
--  0214 : Fixed mostly flags, only the block instructions now fail the zex regression test
--  0232 : Removed refresh address output for Mode > 1 and added DJNZ M1_n fix by Mike Johnson
--  0235 : Added clock enable and IM 2 fix by Mike Johnson
--  0237 : Changed 8080 I/O address output, added IntE output
--  0238 : Fixed (IX/IY+d) timing and 16 bit ADC and SBC zero flag
--  0240 : Added interrupt ack fix by Mike Johnson, changed (IX/IY+d) timing and changed flags in GB mode
--  0242 : Added I/O wait, fixed refresh address, moved some registers to RAM
--  0247 : Fixed bus req/ack cycle
--  0248 : Added undocumented DDCB and FDCB opcodes by TobiFlex 2010.04.20
--  0249 : Added undocumented XY-Flags for CPI/CPD by TobiFlex 2012.07.22
--  0250 : Added R800 Multiplier by TobiFlex 2017.10.15
--
--  +k01 : Version alignment by KdL 2010.10.25
--  +k02 : Added R800_mode signal by KdL 2018.05.14
--  +k03 : Version alignment by KdL 2019.05.20
--  +k04 : Separation of T800 from T80_eZ80 by KdL 2021.02.01
--

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;
use work.T80_eZ80_Pack.all;

entity T80_eZ80 is
    generic(
        Mode        : integer := 0;  -- 0 => Z80, 1 => Fast Z80, 2 => 8080, 3 => GB
        IOWait      : integer := 0;
        FETCH24     : boolean := false;
        ENABLE_MIXED : boolean := false;
        RESET_ADL : boolean := false;
        RESET_PC    : std_logic_vector(23 downto 0) := x"000000";  -- 0 => Single I/O cycle, 1 => Std I/O cycle
        Flag_C      : integer := 0;
        Flag_N      : integer := 1;
        Flag_P      : integer := 2;
        Flag_X      : integer := 3;
        Flag_H      : integer := 4;
        Flag_Y      : integer := 5;
        Flag_Z      : integer := 6;
        Flag_S      : integer := 7
    );
    port(
        RESET_n     : in std_logic;
        CLK_n       : in std_logic;
        CEN         : in std_logic;
        WAIT_n      : in std_logic;
        INT_n       : in std_logic;
        NMI_n       : in std_logic;
        BUSRQ_n     : in std_logic;
        M1_n        : out std_logic;
        IORQ        : out std_logic;
        NoRead      : out std_logic;
        Write       : out std_logic;
        RFSH_n      : out std_logic;
        HALT_n      : out std_logic;
        BUSAK_n     : out std_logic;
        A           : out std_logic_vector(15 downto 0);
        A_BANK      : out std_logic_vector(7 downto 0) := x"00";
		update_addr	: out std_logic;
        DInst       : in std_logic_vector(7 downto 0);
        DI          : in std_logic_vector(7 downto 0);
        DO          : out std_logic_vector(7 downto 0);
        MC          : out std_logic_vector(2 downto 0);
        TS          : out std_logic_vector(2 downto 0);
        IntCycle_n  : out std_logic;
        IntE        : out std_logic;
        Stop        : out std_logic
    );
end T80_eZ80;

architecture rtl of T80_eZ80 is

    constant aNone  : std_logic_vector(2 downto 0) := "111";
    constant aBC    : std_logic_vector(2 downto 0) := "000";
    constant aDE    : std_logic_vector(2 downto 0) := "001";
    constant aXY    : std_logic_vector(2 downto 0) := "010";
    constant aIOA   : std_logic_vector(2 downto 0) := "100";
    constant aSP    : std_logic_vector(2 downto 0) := "101";
    constant aZI    : std_logic_vector(2 downto 0) := "110";

    -- FETCH24 is a development-time fetch-width setting, not an ADL mode bit.
    function step_pc(p : unsigned(23 downto 0); delta : integer; wide : boolean) return unsigned is
        variable q : unsigned(23 downto 0);
    begin
        if wide then
            q := unsigned(signed(p) + to_signed(delta,24));
        else
            q := x"00" & unsigned(signed(p(15 downto 0)) + to_signed(delta,16));
        end if;
        return q;
    end function;

    -- Registers
    signal ACC, F           : std_logic_vector(7 downto 0);
    signal Ap, Fp           : std_logic_vector(7 downto 0);
    signal I                : std_logic_vector(7 downto 0);
    signal R                : unsigned(7 downto 0);
    signal SPL : unsigned(23 downto 0);
    signal ADL_State : std_logic;
    signal Fetch_Long : boolean;
    signal Frame_Last : std_logic;
    signal Frame_Enabled : std_logic;
    signal Return_Mode : std_logic_vector(7 downto 0);
    signal Stack_Long : std_logic;
    signal Pair_Stack_Long : std_logic;
    signal Wide_IncDec : std_logic;
    signal Data_Indirect : std_logic;
    signal Indexed_Data : std_logic;
    signal Block_Instruction, Block_Long, Block_Upper_WE : std_logic;
    signal Absolute_Data : std_logic;
    signal Pair_Absolute : std_logic;
    signal Pair_Read : std_logic;
    signal Indexed_Addr : signed(23 downto 0);
    signal Indexed_Bank : std_logic_vector(7 downto 0);
    signal Upper_DI : std_logic_vector(7 downto 0);
    signal TargetBank : std_logic_vector(7 downto 0);
    signal SP               : unsigned(15 downto 0);
    signal PC               : unsigned(23 downto 0);
    signal Control_Long : std_logic;
    signal Short_Pending, Short_Instruction : std_logic;
    signal Long_Pending, Data_Long, Upper_LD_WE : std_logic;
    signal Store_Pending, Store_Long, Long_Store_Active : std_logic;
    -- Upper-byte path. Writes remain disabled until ADL decode is implemented.
    signal RegBusAU, RegBusBU, RegBusCU : std_logic_vector(7 downto 0);
    signal RegBusA24, RegBusB24, RegBusC24 : std_logic_vector(23 downto 0);
    signal RegDIH           : std_logic_vector(7 downto 0);
    signal RegDIL           : std_logic_vector(7 downto 0);
    signal RegBusA          : std_logic_vector(15 downto 0);
    signal RegBusB          : std_logic_vector(15 downto 0);
    signal RegBusC          : std_logic_vector(15 downto 0);
    signal RegAddrA_r       : std_logic_vector(2 downto 0);
    signal RegAddrA         : std_logic_vector(2 downto 0);
    signal RegAddrB_r       : std_logic_vector(2 downto 0);
    signal RegAddrB         : std_logic_vector(2 downto 0);
    signal RegAddrC         : std_logic_vector(2 downto 0);
    signal RegWEH           : std_logic;
    signal RegWEL           : std_logic;
    signal Alternate        : std_logic;

    -- Help Registers
    signal TmpAddr          : std_logic_vector(15 downto 0);    -- Temporary address register
    signal IR               : std_logic_vector(7 downto 0);     -- Instruction register
    signal ISet             : std_logic_vector(1 downto 0);     -- Instruction set selector
    signal RegBusA_r        : std_logic_vector(15 downto 0);

    signal ID16             : signed(15 downto 0);
    signal Save_Mux         : std_logic_vector(7 downto 0);

    signal TState           : unsigned(2 downto 0);
    signal MCycle           : std_logic_vector(2 downto 0);
    signal IntE_FF1         : std_logic;
    signal IntE_FF2         : std_logic;
    signal Halt_FF          : std_logic;
    signal BusReq_s         : std_logic;
    signal BusAck           : std_logic;
    signal ClkEn            : std_logic;
    signal NMI_s            : std_logic;
    signal INT_s            : std_logic;
    signal IStatus          : std_logic_vector(1 downto 0);

    signal DI_Reg           : std_logic_vector(7 downto 0);
    signal T_Res            : std_logic;
    signal XY_State         : std_logic_vector(1 downto 0);
    signal Pre_XY_F_M       : std_logic_vector(2 downto 0);
    signal NextIs_XY_Fetch  : std_logic;
    signal XY_Ind           : std_logic;
    signal No_BTR           : std_logic;
    signal BTR_r            : std_logic;
    signal Auto_Wait        : std_logic;
    signal Auto_Wait_t1     : std_logic;
    signal Auto_Wait_t2     : std_logic;
    signal IncDecZ          : std_logic;

    -- ALU signals
    signal BusB             : std_logic_vector(7 downto 0);
    signal BusA             : std_logic_vector(7 downto 0);
    signal ALU_Q            : std_logic_vector(7 downto 0);
    signal F_Out            : std_logic_vector(7 downto 0);

    -- Registered micro code outputs
    signal Read_To_Reg_r    : std_logic_vector(4 downto 0);
    signal Arith16_r        : std_logic;
    signal Z16_r            : std_logic;
    signal ALU_Op_r         : std_logic_vector(3 downto 0);
    signal ALU_cpi_r        : std_logic;
    signal Save_ALU_r       : std_logic;
    signal PreserveC_r      : std_logic;
    signal MCycles          : std_logic_vector(2 downto 0);

    -- Micro code outputs
    signal MCycles_d        : std_logic_vector(2 downto 0);
    signal TStates          : std_logic_vector(2 downto 0);
    signal IntCycle         : std_logic;
    signal NMICycle         : std_logic;
    signal Inc_PC           : std_logic;
    signal Inc_WZ           : std_logic;
    signal IncDec_16        : std_logic_vector(3 downto 0);
    signal Prefix           : std_logic_vector(1 downto 0);
    signal Read_To_Acc      : std_logic;
    signal Read_To_Reg      : std_logic;
    signal Set_BusB_To      : std_logic_vector(3 downto 0);
    signal Set_BusA_To      : std_logic_vector(3 downto 0);
    signal ALU_Op           : std_logic_vector(3 downto 0);
    signal ALU_cpi          : std_logic;
    signal Save_ALU         : std_logic;
    signal PreserveC        : std_logic;
    signal Arith16          : std_logic;
    signal Set_Addr_To      : std_logic_vector(2 downto 0);
    signal Jump             : std_logic;
    signal JumpE            : std_logic;
    signal JumpXY           : std_logic;
    signal Call             : std_logic;
    signal RstP             : std_logic;
    signal LDZ              : std_logic;
    signal LDW              : std_logic;
    signal LDSPHL           : std_logic;
    signal IORQ_i           : std_logic;
    signal Special_LD       : std_logic_vector(2 downto 0);
    signal ExchangeDH       : std_logic;
    signal ExchangeRp       : std_logic;
    signal ExchangeAF       : std_logic;
    signal ExchangeRS       : std_logic;
    signal I_DJNZ           : std_logic;
    signal I_CPL            : std_logic;
    signal I_CCF            : std_logic;
    signal I_SCF            : std_logic;
    signal I_RETN           : std_logic;
    signal I_BT             : std_logic;
    signal I_BC             : std_logic;
    signal I_BTR            : std_logic;
    signal I_RLD            : std_logic;
    signal I_RRD            : std_logic;
    signal I_INRC           : std_logic;
    signal SetDI            : std_logic;
    signal SetEI            : std_logic;
    signal IMode            : std_logic_vector(1 downto 0);
    signal Halt             : std_logic;
    signal XYbit_undoc      : std_logic;

begin

    mcode : T80_eZ80_MCode
        generic map(
            Mode => Mode,
            Flag_C => Flag_C,
            Flag_N => Flag_N,
            Flag_P => Flag_P,
            Flag_X => Flag_X,
            Flag_H => Flag_H,
            Flag_Y => Flag_Y,
            Flag_Z => Flag_Z,
            Flag_S => Flag_S)
        port map(
            Data_Long => Data_Long,
            Control_Long => Control_Long,
            Frame_Enabled=>Frame_Enabled, Frame_Last => Frame_Last, ADL_State=>ADL_State, Return_Mode=>Return_Mode,
            Store_Long => Store_Long,
            IR => IR,
            ISet => ISet,
            MCycle => MCycle,
            F => F,
            NMICycle => NMICycle,
            IntCycle => IntCycle,
            XY_State => XY_State,
            MCycles => MCycles_d,
            TStates => TStates,
            Prefix => Prefix,
            Inc_PC => Inc_PC,
            Inc_WZ => Inc_WZ,
            IncDec_16 => IncDec_16,
            Read_To_Acc => Read_To_Acc,
            Read_To_Reg => Read_To_Reg,
            Set_BusB_To => Set_BusB_To,
            Set_BusA_To => Set_BusA_To,
            ALU_Op => ALU_Op,
            ALU_cpi => ALU_cpi,
            Save_ALU => Save_ALU,
            PreserveC => PreserveC,
            Arith16 => Arith16,
            Set_Addr_To => Set_Addr_To,
            IORQ => IORQ_i,
            Jump => Jump,
            JumpE => JumpE,
            JumpXY => JumpXY,
            Call => Call,
            RstP => RstP,
            LDZ => LDZ,
            LDW => LDW,
            LDSPHL => LDSPHL,
            Special_LD => Special_LD,
            ExchangeDH => ExchangeDH,
            ExchangeRp => ExchangeRp,
            ExchangeAF => ExchangeAF,
            ExchangeRS => ExchangeRS,
            I_DJNZ => I_DJNZ,
            I_CPL => I_CPL,
            I_CCF => I_CCF,
            I_SCF => I_SCF,
            I_RETN => I_RETN,
            I_BT => I_BT,
            I_BC => I_BC,
            I_BTR => I_BTR,
            I_RLD => I_RLD,
            I_RRD => I_RRD,
            I_INRC => I_INRC,
            SetDI => SetDI,
            SetEI => SetEI,
            IMode => IMode,
            Halt => Halt,
            NoRead => NoRead,
            Write => Write,
            XYbit_undoc => XYbit_undoc);

    alu : T80_eZ80_ALU
        generic map(
            Mode => Mode,
            Flag_C => Flag_C,
            Flag_N => Flag_N,
            Flag_P => Flag_P,
            Flag_X => Flag_X,
            Flag_H => Flag_H,
            Flag_Y => Flag_Y,
            Flag_Z => Flag_Z,
            Flag_S => Flag_S)
        port map(
            Arith16 => Arith16_r,
            Z16 => Z16_r,
            ALU_cpi => ALU_cpi_r,
            ALU_Op => ALU_Op_r,
            IR => IR(5 downto 0),
            ISet => ISet,
            BusA => BusA,
            BusB => BusB,
            F_In => F,
            Q => ALU_Q,
            F_Out => F_Out);

    -- Match the bank latch to the existing low-address update points.
    -- Supported direct register-indirect LD cycles select the register bank; refresh/I/O stay zero.
    process (RESET_n, CLK_n)
    begin
        if RESET_n='0' then
            if FETCH24 and (not ENABLE_MIXED or RESET_ADL) then A_BANK<=RESET_PC(23 downto 16);
            else A_BANK<=x"00"; end if;
        elsif rising_edge(CLK_n) then
            if ClkEn='1' then
                if MCycle="001" and TState(2)='0' then
                    if TState=2 and Wait_n='1' then A_BANK<=x"00"; end if;
                elsif T_Res='1' then
                    A_BANK<=x"00";
                    if FETCH24 then
                        if NMICycle='1' or IntCycle='1' then
                            A_BANK<=x"00";
                        elsif Jump='1' and Stack_Long='1' then
                            A_BANK<=DI_Reg;
                            if Frame_Enabled='1' and Return_Mode=x"02" then A_BANK<=x"00";end if;
                        elsif Call='1' and Stack_Long='1' then
                            A_BANK<=TargetBank;
                        elsif Set_Addr_To=aSP and Stack_Long='1' then
                            A_BANK<=std_logic_vector(SPL(23 downto 16));
                        elsif Jump='1' and Control_Long='1' and ISet="00" and (IR=x"C3" or IR(2 downto 0)="010") then
                            A_BANK<=DI_Reg;
                        elsif JumpXY='1' and Control_Long='1' then
                            A_BANK<=RegBusCU;
                        elsif (Jump='1' or JumpXY='1') and Short_Instruction='1' then
                            A_BANK<=x"00";
                        elsif Pair_Absolute='1' and Set_Addr_To=aZI then
                            if Inc_WZ='1' then
                                A_BANK<=A_BANK;if A=x"FFFF" then A_BANK<=std_logic_vector(unsigned(A_BANK)+1);end if;
                            else A_BANK<=DI_Reg;end if;
                        elsif Absolute_Data='1' and Set_Addr_To=aZI then A_BANK<=DI_Reg;
                        elsif Data_Indirect='1' and IORQ_i='0' and (Set_Addr_To=aBC or Set_Addr_To=aDE or Set_Addr_To=aXY) then
                            A_BANK<=RegBusCU;
                        elsif Indexed_Data='1' and Set_Addr_To=aXY and NextIs_XY_Fetch='0' then
                            A_BANK<=Indexed_Bank;
                        elsif Jump='1' or JumpXY='1' or Call='1' or RstP='1'
                           or Set_Addr_To=aNone
                           or (Set_Addr_To=aXY and NextIs_XY_Fetch='1') then
                            A_BANK<=std_logic_vector(PC(23 downto 16));
                            if not Fetch_Long then A_BANK<=x"00";end if;
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end process;

    Pair_Absolute <= '1' when Control_Long='1' and ((ISet="00" and (IR=x"22" or IR=x"2A")) or (ISet="10" and IR(7 downto 6)="01" and IR(2 downto 0)="011")) else '0';
    Pair_Read <= '1' when Pair_Absolute='1' and ((ISet="00" and IR=x"2A") or (ISet="10" and IR(3)='1')) else '0';
    Absolute_Data <= '1' when Control_Long='1' and ISet="00" and (IR=x"32" or IR=x"3A") else '0';
    Block_Instruction <= '1' when ISet="10" and (IR=x"A0" or IR=x"A8" or IR=x"B0" or IR=x"B8") else '0';
    Block_Long <= Block_Instruction and Control_Long;
    Block_Upper_WE <= '1' when Block_Long='1' and IncDec_16(2)='1' and
        ((TState=3 and MCycle="001") or (TState=2 and MCycle/="001" and Wait_n='1')) else '0';
    Indexed_Data <= '1' when Control_Long='1' and XY_State/="00" and ISet="01" else
        '1' when Control_Long='1' and ISet="00" and XY_State/="00" and
        (IR=x"CB" or IR=x"34" or IR=x"35" or (IR(7 downto 6)="10" and IR(2 downto 0)="110") or IR=x"36" or (IR(7 downto 6)="01" and IR/=x"76" and (IR(5 downto 3)="110" or IR(2 downto 0)="110"))) else '0';
    Indexed_Addr <= signed(RegBusC24)+resize(signed(DI_Reg),24);
    Data_Indirect <= '1' when Block_Long='1' else '1' when Control_Long='1' and ISet="01" and XY_State="00" and IR(2 downto 0)="110" else '1' when Control_Long='1' and ISet="00" and XY_State="00" and
        (IR=x"02" or IR=x"0A" or IR=x"12" or IR=x"1A" or IR=x"34" or IR=x"35" or (IR(7 downto 6)="10" and IR(2 downto 0)="110") or IR=x"36" or
        (IR(7 downto 6)="01" and IR/=x"76" and (IR(5 downto 3)="110" or IR(2 downto 0)="110"))) else '0';
    Wide_IncDec <= '1' when Control_Long='1' and ISet="00" and IR(7 downto 6)="00" and (IR(3 downto 0)="0011" or IR(3 downto 0)="1011") else '0';
    Pair_Stack_Long <= '1' when Control_Long='1' and ISet="00" and IR(7 downto 6)="11" and IR(5 downto 4)/="11" and (IR(3 downto 0)="0101" or IR(3 downto 0)="0001") else '0';
    Stack_Long <= '1' when Control_Long='1' and ISet="00" and
        (Pair_Stack_Long='1' or IR=x"CD" or (IR(7 downto 6)="11" and IR(2 downto 0)="100") or
         IR=x"C9" or (IR(7 downto 6)="11" and IR(2 downto 0)="000")) else '0';
    Fetch_Long <= FETCH24 and (not ENABLE_MIXED or ADL_State='1');
    Control_Long <= '1' when FETCH24 and Data_Long='1' else '0';

    ClkEn <= CEN and not BusAck;

    T_Res <= '1' when TState = unsigned(TStates) else '0';

    NextIs_XY_Fetch <= '1' when XY_State /= "00" and XY_Ind = '0' and
                            ((Set_Addr_To = aXY) or
                            (MCycle = "001" and IR = "11001011") or
                            (MCycle = "001" and IR = "00110110")) else '0';

    Save_Mux <= BusB when ExchangeRp = '1' else
        DI_Reg when Save_ALU_r = '0' else
        ALU_Q;

    process (RESET_n, CLK_n)
    begin
        if RESET_n = '0' then
            Long_Pending <= '0';
            Short_Pending<='0';Short_Instruction<='0';
            Store_Pending <= '0';
            Store_Long <= '0';
            Data_Long <= '0';
            if FETCH24 and (not ENABLE_MIXED or RESET_ADL) then PC <= unsigned(RESET_PC);
            else PC <= x"00" & unsigned(RESET_PC(15 downto 0)); end if;
            A <= RESET_PC(15 downto 0);
			update_addr <= '0';
            TmpAddr <= (others => '0');Indexed_Bank<=x"00";
            IR <= "00000000";
            ISet <= "00";
            XY_State <= "00";
            IStatus <= "00";
            MCycles <= "000";
            DO <= "00000000";

            ACC <= (others => '1');
            F <= (others => '1');
            Ap <= (others => '1');
            Fp <= (others => '1');
            I <= (others => '0');
            R <= (others => '0');
            SP <= (others => '1');
            SPL <= (others => '1');TargetBank<=x"00";
            Frame_Enabled<='0';Frame_Last<='0';Return_Mode<=x"03";
            if FETCH24 and (not ENABLE_MIXED or RESET_ADL) then ADL_State<='1';else ADL_State<='0';end if;
            Alternate <= '0';

            Read_To_Reg_r <= "00000";
            F <= (others => '1');
            Arith16_r <= '0';
            BTR_r <= '0';
            Z16_r <= '0';
            ALU_Op_r <= "0000";
            ALU_cpi_r <= '0';
            Save_ALU_r <= '0';
            PreserveC_r <= '0';
            XY_Ind <= '0';

        elsif CLK_n'event and CLK_n = '1' then

            if ClkEn = '1' then

			update_addr <= '0';
            ALU_Op_r <= "0000";
            ALU_cpi_r <= '0';
            Save_ALU_r <= '0';
            Read_To_Reg_r <= "00000";

            MCycles <= MCycles_d;

            if IMode /= "11" then
                IStatus <= IMode;
            end if;

            Arith16_r <= Arith16;
            PreserveC_r <= PreserveC;
            if ISet = "10" and ALU_OP(2) = '0' and ALU_OP(0) = '1' and MCycle = "011" then
                Z16_r <= '1';
            else
                Z16_r <= '0';
            end if;

            if MCycle  = "001" and TState(2) = '0' then
            -- MCycle = 1 and TState = 1, 2, or 3

                if TState = 2 and Wait_n = '1' then
                    if Mode < 2 then
						update_addr <= '1';
                        A(7 downto 0) <= std_logic_vector(R);
                        A(15 downto 8) <= I;
                        R(6 downto 0) <= R(6 downto 0) + 1;
                    end if;

                    if Jump = '0' and Call = '0' and NMICycle = '0' and IntCycle = '0' and not (Halt_FF = '1' or Halt = '1') then
                        PC <= step_pc(PC,1,Fetch_Long);
                    end if;

                    Frame_Last<='0';Frame_Enabled<='0';
                    -- 5B memory-mode suffix for initial LD.LIL immediate subset.
                    -- DD/FD preserve the pending suffix until the actual opcode.
                    if IntCycle = '0' and NMICycle = '0' and Halt_FF = '0' then
                        Store_Long <= '0';
                        if DInst = x"49" and Prefix = "00" then
                            Store_Pending <= '1';
                        elsif Store_Pending = '1' then
                            Store_Long <= '1';
                            if DInst /= x"DD" and DInst /= x"FD" then
                                Store_Pending <= '0';
                            end if;
                        end if;
                        Short_Instruction<='0';
                        if ENABLE_MIXED and DInst=x"40" and Prefix="00" then
                            Short_Pending<='1';Data_Long<='0';
                        elsif Short_Pending='1' then
                            Short_Instruction<='1';Data_Long<='0';
                            if DInst/=x"DD" and DInst/=x"FD" and DInst/=x"ED" and DInst/=x"CB" then Short_Pending<='0';end if;
                        elsif (DInst = x"5B" or (ENABLE_MIXED and DInst=x"52")) and Prefix = "00" then
                            Long_Pending <= '1';Data_Long <= '0';
                        elsif Long_Pending = '1' then
                            Data_Long <= '1';Frame_Enabled<='1';
                            if DInst /= x"DD" and DInst /= x"FD" and DInst/=x"ED" and DInst/=x"CB" then Long_Pending <= '0';end if;
                        elsif ENABLE_MIXED and ADL_State='1' and
                             ((Prefix="10" and (DInst=x"A0" or DInst=x"A8" or DInst=x"B0" or DInst=x"B8")) or (DInst=x"CB" and Prefix="11") or (Prefix="01" and DInst(2 downto 0)="110") or (Prefix="10" and DInst(7 downto 6)="01" and DInst(2 downto 0)="011") or DInst=x"01" or DInst=x"11" or DInst=x"21" or DInst=x"31" or
                              (DInst=x"22" or DInst=x"2A" or DInst=x"32" or DInst=x"3A" or DInst=x"02" or DInst=x"0A" or DInst=x"12" or DInst=x"1A" or DInst=x"34" or DInst=x"35" or (DInst(7 downto 6)="10" and DInst(2 downto 0)="110") or DInst=x"36" or (DInst(7 downto 6)="01" and DInst/=x"76" and (DInst(5 downto 3)="110" or DInst(2 downto 0)="110"))) or (DInst(7 downto 6)="00" and (DInst(3 downto 0)="0011" or DInst(3 downto 0)="1011")) or DInst=x"C3" or DInst=x"E9" or DInst=x"CD" or DInst=x"C9" or (DInst(7 downto 6)="11" and DInst(5 downto 4)/="11" and (DInst(3 downto 0)="0101" or DInst(3 downto 0)="0001")) or
                              (DInst(7 downto 6)="11" and (DInst(2 downto 0)="010" or DInst(2 downto 0)="100" or DInst(2 downto 0)="000"))) then
                            Data_Long<='1';
                        else Data_Long<='0';
                        end if;
                    end if;

                    if IntCycle = '1' and IStatus = "01" then
                        IR <= "11111111";
                    elsif Halt_FF = '1' or (IntCycle = '1' and IStatus = "10") or NMICycle = '1' then
                        IR <= "00000000";
                    else
                        IR <= DInst;
                    end if;

                    ISet <= "00";
                    if Prefix /= "00" then
                        if Prefix = "11" then
                            if IR(5) = '1' then
                                XY_State <= "10";
                            else
                                XY_State <= "01";
                            end if;
                        else
                            if Prefix = "10" then
                                XY_State <= "00";
                                XY_Ind <= '0';
                            end if;
                            ISet <= Prefix;
                        end if;
                    else
                        XY_State <= "00";
                        XY_Ind <= '0';
                    end if;
                end if;

            else
            -- either (MCycle > 1) OR (MCycle = 1 AND TState > 3)

                if MCycle = "110" and Long_Store_Active = '0' then
                    XY_Ind <= '1';
                    if Prefix = "01" then
                        ISet <= "01";
                    end if;
                end if;

                if T_Res = '1' then
                    if Stack_Long='1' and (IR=x"CD" or IR(2 downto 0)="100") and MCycle="111" then Frame_Last<='1';end if;
					update_addr <= '1';
                    BTR_r <= (I_BT or I_BC or I_BTR) and not No_BTR;
                    if Jump='1' and Stack_Long='1' then
                        -- synthesis translate_off
                        assert Frame_Enabled='0' or Return_Mode=x"03" or (ENABLE_MIXED and Return_Mode=x"02") report "unsupported return mode marker" severity failure;
                        -- synthesis translate_on
                        A<=TmpAddr;PC<=unsigned(DI_Reg & TmpAddr);
                        if ENABLE_MIXED then
                            if Frame_Enabled='1' and Return_Mode=x"02" then
                                ADL_State<='0';A<=DI_Reg & TmpAddr(7 downto 0);
                                PC<=unsigned(x"00" & DI_Reg & TmpAddr(7 downto 0));
                            else ADL_State<='1';end if;
                        end if;
                    elsif Call='1' and Stack_Long='1' then
                        A<=TmpAddr;PC<=unsigned(TargetBank & TmpAddr);
                        if ENABLE_MIXED then ADL_State<='1';end if;
                    elsif Jump='1' and Control_Long='1' and ISet="00" and (IR=x"C3" or IR(2 downto 0)="010") then
                        A <= TmpAddr;
                        PC <= unsigned(DI_Reg & TmpAddr);
                        if ENABLE_MIXED then ADL_State<='1';end if;
                    elsif Jump = '1' then
                        if ENABLE_MIXED and Short_Instruction='1' and ISet="00" and (IR=x"C3" or IR(2 downto 0)="010") then ADL_State<='0';PC(23 downto 16)<=(others=>'0');end if;
                        A(15 downto 8) <= DI_Reg;
                        A(7 downto 0) <= TmpAddr(7 downto 0);
                        PC(15 downto 8) <= unsigned(DI_Reg);
                        PC(7 downto 0) <= unsigned(TmpAddr(7 downto 0));
                    elsif JumpXY = '1' then
                        A <= RegBusC;
                        PC(15 downto 0) <= unsigned(RegBusC);
                        if ENABLE_MIXED and Short_Instruction='1' then ADL_State<='0';PC(23 downto 16)<=(others=>'0');end if;
                        if Control_Long='1' then PC(23 downto 16)<=unsigned(RegBusCU);if ENABLE_MIXED then ADL_State<='1';end if;end if;
                    elsif Call = '1' or RstP = '1' then
                        A <= TmpAddr;
                        PC(15 downto 0) <= unsigned(TmpAddr);
                    elsif MCycle = MCycles and NMICycle = '1' then
                        A <= "0000000001100110";
                        PC <= x"000066";
                    elsif MCycle = "011" and IntCycle = '1' and IStatus = "10" then
                        A(15 downto 8) <= I;
                        A(7 downto 0) <= TmpAddr(7 downto 0);
                        PC(15 downto 8) <= unsigned(I);
                        PC(7 downto 0) <= unsigned(TmpAddr(7 downto 0));
                    else
                        case Set_Addr_To is
                        when aXY =>
                            if XY_State = "00" then
                                A <= RegBusC;
                            else
                                if NextIs_XY_Fetch = '1' then
                                    A <= std_logic_vector(PC(15 downto 0));
                                else
                                    A <= TmpAddr;
                                end if;
                            end if;
                        when aIOA =>
                            if Mode = 3 then
                                -- Memory map I/O on GBZ80
                                A(15 downto 8) <= (others => '1');
                            elsif Mode = 2 then
                                -- Duplicate I/O address on 8080
                                A(15 downto 8) <= DI_Reg;
                            else
                                A(15 downto 8) <= ACC;
                            end if;
                            A(7 downto 0) <= DI_Reg;
                        when aSP =>
                            A <= std_logic_vector(SP);
                            if Stack_Long='1' then A<=std_logic_vector(SPL(15 downto 0));end if;
                        when aBC =>
                            if Mode = 3 and IORQ_i = '1' then
                                -- Memory map I/O on GBZ80
                                A(15 downto 8) <= (others => '1');
                                A(7 downto 0) <= RegBusC(7 downto 0);
                            else
                                A <= RegBusC;
                            end if;
                        when aDE =>
                            A <= RegBusC;
                        when aZI =>
                            if Pair_Absolute='1' then
                                if Inc_WZ='1' then A<=std_logic_vector(unsigned(A)+1);else A<=TmpAddr;end if;
                            elsif Absolute_Data='1' then A<=TmpAddr;
                            elsif Inc_WZ = '1' then
                                if Store_Long = '1' and ISet = "00" and IR = x"22" and MCycle = "101" then
                                    A <= std_logic_vector(unsigned(A) + 1);
                                else
                                    A <= std_logic_vector(unsigned(TmpAddr) + 1);
                                end if;
                            else
                                A(15 downto 8) <= DI_Reg;
                                A(7 downto 0) <= TmpAddr(7 downto 0);
                            end if;
                        when others =>
                            A <= std_logic_vector(PC(15 downto 0));
                        end case;
                    end if;

                    Save_ALU_r <= Save_ALU;
                    ALU_cpi_r <= ALU_cpi;
                    ALU_Op_r <= ALU_Op;

                    if I_CPL = '1' then
                        -- CPL
                        ACC <= not ACC;
                        F(Flag_Y) <= not ACC(5);
                        F(Flag_H) <= '1';
                        F(Flag_X) <= not ACC(3);
                        F(Flag_N) <= '1';
                    end if;
                    if I_CCF = '1' then
                        -- CCF
                        F(Flag_C) <= not F(Flag_C);
                        F(Flag_Y) <= ACC(5);
                        F(Flag_H) <= F(Flag_C);
                        F(Flag_X) <= ACC(3);
                        F(Flag_N) <= '0';
                    end if;
                    if I_SCF = '1' then
                        -- SCF
                        F(Flag_C) <= '1';
                        F(Flag_Y) <= ACC(5);
                        F(Flag_H) <= '0';
                        F(Flag_X) <= ACC(3);
                        F(Flag_N) <= '0';
                    end if;
                end if;

                if TState = 2 and Wait_n = '1' then
                    if ISet = "01" and MCycle = "111" then
                        IR <= DInst;
                        Short_Pending<='0';Long_Pending<='0';
                    end if;
                    if JumpE = '1' then
                        PC <= step_pc(PC,to_integer(signed(DI_Reg)),Fetch_Long);
                    elsif Inc_PC = '1' then
                        PC <= step_pc(PC,1,Fetch_Long);
                    end if;
                    if BTR_r = '1' then
                        if Block_Instruction='1' and Short_Instruction='1' then
                            PC <= step_pc(PC,-3,Fetch_Long); -- refetch 40 ED opcode on every iteration
                        else PC <= step_pc(PC,-2,Fetch_Long);end if;
                    end if;
                    if RstP = '1' then
                        TmpAddr <= (others =>'0');
                        TmpAddr(5 downto 3) <= IR(5 downto 3);
                    end if;
                end if;
                if TState = 3 and MCycle = "110" and Long_Store_Active = '0' then
                    TmpAddr <= std_logic_vector(signed(RegBusC) + signed(DI_Reg));
                    if Indexed_Data='1' then Indexed_Bank<=std_logic_vector(Indexed_Addr(23 downto 16));end if;
                end if;

                if (TState = 2 and Wait_n = '1') or (TState = 4 and MCycle = "001") then
                    if IncDec_16(2 downto 0) = "111" then
                        if Stack_Long='1' or Wide_IncDec='1' then
                            if IncDec_16(3)='1' then SPL<=SPL-1;else SPL<=SPL+1;end if;
                        elsif IncDec_16(3) = '1' then
                            SP <= SP - 1;
                        else
                            SP <= SP + 1;
                        end if;
                    end if;
                end if;

                if LDSPHL = '1' then
                    SP <= unsigned(RegBusC);
                end if;
                if ExchangeAF = '1' then
                    Ap <= ACC;
                    ACC <= Ap;
                    Fp <= F;
                    F <= Fp;
                end if;
                if ExchangeRS = '1' then
                    Alternate <= not Alternate;
                end if;
            end if;

            if TState = 3 then
                if Pair_Read='1' and ISet="10" and IR(5 downto 4)="11" and MCycle="111" then SPL(23 downto 16)<=unsigned(DI_Reg);end if;
                if Frame_Enabled='1' and Stack_Long='1' and (IR=x"C9" or IR(2 downto 0)="000") and MCycle="010" then Return_Mode<=DI_Reg;end if;
                if Control_Long='1' and ISet="00" and IR=x"31" and MCycle="100" then SPL(23 downto 16)<=unsigned(DI_Reg);end if;
                if Stack_Long='1' and (IR=x"CD" or IR(2 downto 0)="100") and MCycle="100" then TargetBank<=DI_Reg;end if;
                if LDZ = '1' then
                    TmpAddr(7 downto 0) <= DI_Reg;
                end if;
                if LDW = '1' then
                    TmpAddr(15 downto 8) <= DI_Reg;
                end if;

                if Special_LD(2) = '1' then
                    case Special_LD(1 downto 0) is
                    when "00" =>
                        ACC <= I;
                        F(Flag_P) <= IntE_FF2;
                    when "01" =>
                        ACC <= std_logic_vector(R);
                        F(Flag_P) <= IntE_FF2;
                    when "10" =>
                        I <= ACC;
                    when others =>
                        R <= unsigned(ACC);
                    end case;
                end if;
            end if;

            if (I_DJNZ = '0' and Save_ALU_r = '1') or ALU_Op_r = "1001" then
                if Mode = 3 then
                    F(6) <= F_Out(6);
                    F(5) <= F_Out(5);
                    F(7) <= F_Out(7);
                    if PreserveC_r = '0' then
                        F(4) <= F_Out(4);
                    end if;
                else
                    F(7 downto 1) <= F_Out(7 downto 1);
                    if PreserveC_r = '0' then
                        F(Flag_C) <= F_Out(0);
                    end if;
                end if;
            end if;
            if T_Res = '1' and I_INRC = '1' then
                F(Flag_H) <= '0';
                F(Flag_N) <= '0';
                if DI_Reg(7 downto 0) = "00000000" then
                    F(Flag_Z) <= '1';
                else
                    F(Flag_Z) <= '0';
                end if;
                F(Flag_S) <= DI_Reg(7);
                F(Flag_P) <= not (DI_Reg(0) xor DI_Reg(1) xor DI_Reg(2) xor DI_Reg(3) xor
                    DI_Reg(4) xor DI_Reg(5) xor DI_Reg(6) xor DI_Reg(7));
            end if;

            if TState = 1 and Auto_Wait_t1 = '0' then
                DO <= BusB;
                if Pair_Absolute='1' and Pair_Read='0' and MCycle="111" then
                    if ISet="10" and IR(5 downto 4)="11" then DO<=std_logic_vector(SPL(23 downto 16));else DO<=RegBusBU;end if;end if;
                if Pair_Stack_Long='1' and IR(3 downto 0)="0101" and MCycle="010" then DO<=RegBusBU;end if;
                if Store_Long = '1' and ISet = "00" and IR = x"22" and MCycle = "110" then
                    DO <= RegBusBU;
                end if;
                if I_RLD = '1' then
                    DO(3 downto 0) <= BusA(3 downto 0);
                    DO(7 downto 4) <= BusB(3 downto 0);
                end if;
                if I_RRD = '1' then
                    DO(3 downto 0) <= BusB(7 downto 4);
                    DO(7 downto 4) <= BusA(3 downto 0);
                end if;
            end if;

            if T_Res = '1' then
                Read_To_Reg_r(3 downto 0) <= Set_BusA_To;
                Read_To_Reg_r(4) <= Read_To_Reg;
                if Read_To_Acc = '1' then
                    Read_To_Reg_r(3 downto 0) <= "0111";
                    Read_To_Reg_r(4) <= '1';
                end if;
            end if;

            if TState = 1 and I_BT = '1' then
                F(Flag_X) <= ALU_Q(3);
                F(Flag_Y) <= ALU_Q(1);
                F(Flag_H) <= '0';
                F(Flag_N) <= '0';
            end if;
            if I_BC = '1' or I_BT = '1' then
                F(Flag_P) <= IncDecZ;
            end if;

            if (TState = 1 and Save_ALU_r = '0' and Auto_Wait_t1 = '0') or
                (Save_ALU_r = '1' and ALU_OP_r /= "0111") then
                case Read_To_Reg_r is
                when "10111" =>
                    ACC <= Save_Mux;
                when "10110" =>
                    DO <= Save_Mux;
                when "11000" =>
                    if (Control_Long='1' and ISet="00" and IR=x"31") or (Pair_Read='1' and ISet="10" and IR(5 downto 4)="11") then SPL(7 downto 0)<=unsigned(Save_Mux);
                    else SP(7 downto 0) <= unsigned(Save_Mux);end if;
                when "11001" =>
                    if (Control_Long='1' and ISet="00" and IR=x"31") or (Pair_Read='1' and ISet="10" and IR(5 downto 4)="11") then SPL(15 downto 8)<=unsigned(Save_Mux);
                    else SP(15 downto 8) <= unsigned(Save_Mux);end if;
                when "11011" =>
                    F <= Save_Mux;
                when others =>
                end case;
                if XYbit_undoc='1' then
                    DO <= ALU_Q;
                end if;
            end if;

        end if;

        end if;

    end process;

---------------------------------------------------------------------------
--
-- BC('), DE('), HL('), IX and IY
--
---------------------------------------------------------------------------
    process (CLK_n)
    begin
        if CLK_n'event and CLK_n = '1' then
            if ClkEn = '1' then
                -- Bus A / Write
                RegAddrA_r <= Alternate & Set_BusA_To(2 downto 1);
                if XY_Ind = '0' and XY_State /= "00" and Set_BusA_To(2 downto 1) = "10" then
                    RegAddrA_r <= XY_State(1) & "11";
                end if;

                -- Bus B
                RegAddrB_r <= Alternate & Set_BusB_To(2 downto 1);
                if XY_Ind = '0' and XY_State /= "00" and Set_BusB_To(2 downto 1) = "10" then
                    RegAddrB_r <= XY_State(1) & "11";
                end if;

                -- Address from register
                RegAddrC <= Alternate & Set_Addr_To(1 downto 0);
                -- Jump (HL), LD SP,HL
                if (JumpXY = '1' or LDSPHL = '1') then
                    RegAddrC <= Alternate & "10";
                end if;
                if ((JumpXY = '1' or LDSPHL = '1') and XY_State /= "00") or (MCycle = "110" and Long_Store_Active = '0') then
                    RegAddrC <= XY_State(1) & "11";
                end if;

                if I_DJNZ = '1' and Save_ALU_r = '1' and Mode < 2 then
                    IncDecZ <= F_Out(Flag_Z);
                end if;
                if (TState = 2 or (TState = 3 and MCycle = "001")) and IncDec_16(2 downto 0) = "100" then
                    if (Block_Long='1' and unsigned(RegBusA24)=1) or (Block_Long='0' and ID16=0) then
                        IncDecZ <= '0';
                    else
                        IncDecZ <= '1';
                    end if;
                end if;

                RegBusA_r <= RegBusA;
            end if;
        end if;
    end process;

    -- Suppress legacy indexed M6/M7 bookkeeping during extended stack cycles.
    Long_Store_Active <= '1' when Pair_Absolute='1' or Stack_Long='1' else '1' when Store_Long = '1' and ISet = "00" and IR = x"22" else '0';
    Upper_LD_WE <= '1' when Block_Upper_WE='1' else '1' when Pair_Read='1' and IR(5 downto 4)/="11" and MCycle="111" and TState=3 else '1' when Wide_IncDec='1' and IR(5 downto 4)/="11" and MCycle="001" and TState=3 else '1' when Pair_Stack_Long='1' and IR(3 downto 0)="0001" and MCycle="100" and TState=3 else '1' when Data_Long = '1' and ISet = "00"
        and IR(7 downto 6) = "00" and IR(3 downto 0) = "0001"
        and IR(5 downto 4) /= "11" and MCycle = "100" and TState = 3 else '0';

    RegAddrA <=
            Alternate & IncDec_16(1 downto 0) when Block_Upper_WE='1' else
            XY_State(1) & "11" when Upper_LD_WE = '1' and IR(5 downto 4) = "10" and XY_State /= "00" else
            Alternate & IR(5 downto 4) when Upper_LD_WE = '1' else
            -- 16 bit increment/decrement
            Alternate & IncDec_16(1 downto 0) when (TState = 2 or
                (TState = 3 and MCycle = "001" and IncDec_16(2) = '1')) and XY_State = "00" else
            XY_State(1) & "11" when (TState = 2 or
                (TState = 3 and MCycle = "001" and IncDec_16(2) = '1')) and IncDec_16(1 downto 0) = "10" else
            -- EX HL,DL
            Alternate & "10" when ExchangeDH = '1' and TState = 3 else
            Alternate & "01" when ExchangeDH = '1' and TState = 4 else
            -- Bus A / Write
            RegAddrA_r;

    RegAddrB <=
            -- EX HL,DL
            Alternate & "01" when ExchangeDH = '1' and TState = 3 else
            -- Bus B
            RegAddrB_r;

    ID16 <= signed(RegBusA) - 1 when IncDec_16(3) = '1' else
            signed(RegBusA) + 1;

    process (Save_ALU_r, Auto_Wait_t1, ALU_OP_r, Read_To_Reg_r,
            ExchangeDH, IncDec_16, MCycle, TState, Wait_n)
    begin
        RegWEH <= '0';
        RegWEL <= '0';
        if (TState = 1 and Save_ALU_r = '0' and Auto_Wait_t1 = '0') or
            (Save_ALU_r = '1' and ALU_OP_r /= "0111") then
            case Read_To_Reg_r is
            when "10000" | "10001" | "10010" | "10011" | "10100" | "10101" =>
                RegWEH <= not Read_To_Reg_r(0);
                RegWEL <= Read_To_Reg_r(0);
            when others =>
            end case;
        end if;

        if ExchangeDH = '1' and (TState = 3 or TState = 4) then
            RegWEH <= '1';
            RegWEL <= '1';
        end if;

        if IncDec_16(2) = '1' and ((TState = 2 and Wait_n = '1' and MCycle /= "001") or (TState = 3 and MCycle = "001")) then
            case IncDec_16(1 downto 0) is
            when "00" | "01" | "10" =>
                RegWEH <= '1';
                RegWEL <= '1';
            when others =>
            end case;
        end if;
    end process;

    process (Save_Mux, RegBusB, RegBusA_r, ID16,
            ExchangeDH, IncDec_16, MCycle, TState, Wait_n)
    begin
        RegDIH <= Save_Mux;
        RegDIL <= Save_Mux;

        if ExchangeDH = '1' and TState = 3 then
            RegDIH <= RegBusB(15 downto 8);
            RegDIL <= RegBusB(7 downto 0);
        end if;
        if ExchangeDH = '1' and TState = 4 then
            RegDIH <= RegBusA_r(15 downto 8);
            RegDIL <= RegBusA_r(7 downto 0);
        end if;

        if IncDec_16(2) = '1' and ((TState = 2 and MCycle /= "001") or (TState = 3 and MCycle = "001")) then
            RegDIH <= std_logic_vector(ID16(15 downto 8));
            RegDIL <= std_logic_vector(ID16(7 downto 0));
        end if;
    end process;

    Upper_DI <= std_logic_vector(unsigned(RegBusAU)+1) when (Wide_IncDec='1' or Block_Long='1') and IncDec_16(3)='0' and RegBusA=x"FFFF" else
                std_logic_vector(unsigned(RegBusAU)-1) when (Wide_IncDec='1' or Block_Long='1') and IncDec_16(3)='1' and RegBusA=x"0000" else
                RegBusAU when (Wide_IncDec='1' or Block_Long='1') else DI_Reg;
    RegBusA24 <= RegBusAU & RegBusA;
    RegBusB24 <= RegBusBU & RegBusB;
    RegBusC24 <= RegBusCU & RegBusC;

    Regs : T80_eZ80_Reg
        port map(
            Clk => CLK_n,
            CEN => ClkEn,
            RESET_U_n => RESET_n,
            WEU => Upper_LD_WE,
            DIU => Upper_DI,
            DOAU => RegBusAU,
            DOBU => RegBusBU,
            DOCU => RegBusCU,
            WEH => RegWEH,
            WEL => RegWEL,
            AddrA => RegAddrA,
            AddrB => RegAddrB,
            AddrC => RegAddrC,
            DIH => RegDIH,
            DIL => RegDIL,
            DOAH => RegBusA(15 downto 8),
            DOAL => RegBusA(7 downto 0),
            DOBH => RegBusB(15 downto 8),
            DOBL => RegBusB(7 downto 0),
            DOCH => RegBusC(15 downto 8),
            DOCL => RegBusC(7 downto 0));

---------------------------------------------------------------------------
--
-- Buses
--
---------------------------------------------------------------------------
    process (CLK_n)
    begin
        if CLK_n'event and CLK_n = '1' then
            if ClkEn = '1' then
            case Set_BusB_To is
            when "0111" =>
                BusB <= ACC;
            when "0000" | "0001" | "0010" | "0011" | "0100" | "0101" =>
                if Set_BusB_To(0) = '1' then
                    BusB <= RegBusB(7 downto 0);
                else
                    BusB <= RegBusB(15 downto 8);
                end if;
            when "0110" =>
                BusB <= DI_Reg;
            when "1000" =>
                BusB <= std_logic_vector(SP(7 downto 0));
                if Pair_Absolute='1' and ISet="10" and IR(5 downto 4)="11" then BusB<=std_logic_vector(SPL(7 downto 0));end if;
            when "1001" =>
                BusB <= std_logic_vector(SP(15 downto 8));
                if Pair_Absolute='1' and ISet="10" and IR(5 downto 4)="11" then BusB<=std_logic_vector(SPL(15 downto 8));end if;
            when "1010" =>
                BusB <= "00000001";
            when "1011" =>
                BusB <= F;
            when "1100" =>
                BusB <= std_logic_vector(PC(7 downto 0));
            when "1101" =>
                BusB <= std_logic_vector(PC(15 downto 8));
            when "1110" =>
                BusB <= "00000000";
                if Stack_Long='1' then
                    if ADL_State='1' then BusB<=x"03";else BusB<=x"02";end if;
                end if;
            when "1111" =>
                BusB <= std_logic_vector(PC(23 downto 16));
            when others =>
                BusB <= "--------";
            end case;

            case Set_BusA_To is
            when "0111" =>
                BusA <= ACC;
            when "0000" | "0001" | "0010" | "0011" | "0100" | "0101" =>
                if Set_BusA_To(0) = '1' then
                    BusA <= RegBusA(7 downto 0);
                else
                    BusA <= RegBusA(15 downto 8);
                end if;
            when "0110" =>
                BusA <= DI_Reg;
            when "1000" =>
                BusA <= std_logic_vector(SP(7 downto 0));
            when "1001" =>
                BusA <= std_logic_vector(SP(15 downto 8));
            when "1010" =>
                BusA <= "00000000";
            when "1111" =>
                BusB <= std_logic_vector(PC(23 downto 16));
            when others =>
                BusB <= "--------";
            end case;
            if XYbit_undoc='1' then
                BusA <= DI_Reg;
                BusB <= DI_Reg;
            end if;
            end if;
        end if;
    end process;

---------------------------------------------------------------------------
--
-- Generate external control signals
--
---------------------------------------------------------------------------
    process (RESET_n,CLK_n)
    begin
        if RESET_n = '0' then
            RFSH_n <= '1';
        elsif CLK_n'event and CLK_n = '1' then
            if CEN = '1' then
            if MCycle = "001" and ((TState = 2  and Wait_n = '1') or TState = 3) then
                RFSH_n <= '0';
            else
                RFSH_n <= '1';
            end if;
            end if;
        end if;
    end process;

    MC <= std_logic_vector(MCycle);
    TS <= std_logic_vector(TState);
    DI_Reg <= DI;
    HALT_n <= not Halt_FF;
    BUSAK_n <= not BusAck;
    IntCycle_n <= not IntCycle;
    IntE <= IntE_FF1;
    IORQ <= IORQ_i;
    Stop <= I_DJNZ;

-------------------------------------------------------------------------
--
-- Syncronise inputs
--
-------------------------------------------------------------------------
    process (RESET_n, CLK_n)
        variable OldNMI_n : std_logic;
    begin
        if RESET_n = '0' then
            BusReq_s <= '0';
            INT_s <= '0';
            NMI_s <= '0';
            OldNMI_n := '0';
        elsif CLK_n'event and CLK_n = '1' then
            if CEN = '1' then
            BusReq_s <= not BUSRQ_n;
            INT_s <= not INT_n;
            if NMICycle = '1' then
                NMI_s <= '0';
            elsif NMI_n = '0' and OldNMI_n = '1' then
                NMI_s <= '1';
            end if;
            OldNMI_n := NMI_n;
            end if;
        end if;
    end process;

-------------------------------------------------------------------------
--
-- Main state machine
--
-------------------------------------------------------------------------
    process (RESET_n, CLK_n)
    begin
        if RESET_n = '0' then
            MCycle <= "001";
            TState <= "000";
            Pre_XY_F_M <= "000";
            Halt_FF <= '0';
            BusAck <= '0';
            NMICycle <= '0';
            IntCycle <= '0';
            IntE_FF1 <= '0';
            IntE_FF2 <= '0';
            No_BTR <= '0';
            Auto_Wait_t1 <= '0';
            Auto_Wait_t2 <= '0';
            M1_n <= '1';
        elsif CLK_n'event and CLK_n = '1' then
            if CEN = '1' then
            if T_Res = '1' then
                Auto_Wait_t1 <= '0';
            else
                Auto_Wait_t1 <= Auto_Wait or IORQ_i;
            end if;
            Auto_Wait_t2 <= Auto_Wait_t1;
            No_BTR <= (I_BT and (not IR(4) or not F(Flag_P))) or
                    (I_BC and (not IR(4) or F(Flag_Z) or not F(Flag_P))) or
                    (I_BTR and (not IR(4) or F(Flag_Z)));
            if TState = 2 then
                if SetEI = '1' then
                    IntE_FF1 <= '1';
                    IntE_FF2 <= '1';
                end if;
                if I_RETN = '1' then
                    IntE_FF1 <= IntE_FF2;
                end if;
            end if;
            if TState = 3 then
                if SetDI = '1' then
                    IntE_FF1 <= '0';
                    IntE_FF2 <= '0';
                end if;
            end if;
            if IntCycle = '1' or NMICycle = '1' then
                Halt_FF <= '0';
            end if;
            if MCycle = "001" and TState = 2 and Wait_n = '1' then
                M1_n <= '1';
            end if;
            if BusReq_s = '1' and BusAck = '1' then
            else
                BusAck <= '0';
                if TState = 2 and Wait_n = '0' then
                elsif T_Res = '1' then
                    if Halt = '1' then
                        Halt_FF <= '1';
                    end if;
                    if BusReq_s = '1' then
                        BusAck <= '1';
                    else
                        TState <= "001";
                        if Stack_Long='1' and (IR=x"CD" or IR(2 downto 0)="100") and MCycle="111" and Frame_Last='0' and Frame_Enabled='1' and ADL_State='1' then
                            MCycle<="111";
                        elsif NextIs_XY_Fetch = '1' then
                            MCycle <= "110";
                            Pre_XY_F_M <= MCycle;
                            if IR = "00110110" and Mode = 0 then
                                Pre_XY_F_M <= "010";
                            end if;
                        elsif (MCycle = "111" and Long_Store_Active='0') or
                            (MCycle = "110" and Mode = 1 and ISet /= "01" and Long_Store_Active = '0') then
                            MCycle <= std_logic_vector(unsigned(Pre_XY_F_M) + 1);
                        elsif (MCycle = MCycles) or
                            No_BTR = '1' or
                            (MCycle = "010" and I_DJNZ = '1' and IncDecZ = '1') then
                            M1_n <= '0';
                            MCycle <= "001";
                            IntCycle <= '0';
                            NMICycle <= '0';
                            if NMI_s = '1' and Prefix = "00" and Long_Pending = '0' and Store_Pending = '0' and Short_Pending='0' then
                                NMICycle <= '1';
                                IntE_FF1 <= '0';
                            elsif (IntE_FF1 = '1' and INT_s = '1') and Prefix = "00" and SetEI = '0' and Long_Pending = '0' and Store_Pending = '0' and Short_Pending='0' then
                                IntCycle <= '1';
                                IntE_FF1 <= '0';
                                IntE_FF2 <= '0';
                            end if;
                        else
                            MCycle <= std_logic_vector(unsigned(MCycle) + 1);
                        end if;
                    end if;
                else
                    if (Auto_Wait = '1' and Auto_Wait_t2 = '0') nor
                        (IOWait = 1 and IORQ_i = '1' and Auto_Wait_t1 = '0') then
                        TState <= TState + 1;
                    end if;
                end if;
            end if;
            if TState = 0 then
                M1_n <= '0';
            end if;
            end if;
        end if;
    end process;

    process (IntCycle, NMICycle, MCycle)
    begin
        Auto_Wait <= '0';
        if IntCycle = '1' or NMICycle = '1' then
            if MCycle = "001" then
                Auto_Wait <= '1';
            end if;
        end if;
    end process;

end;
