# MSXnano T80/eZ80 v23

LDI／LDD／LDIR／LDDRを24bit化。HL／DEのバンク跨ぎ、BCの24bit減算・P/V判定、
40短幅指定の反復に対応した。詳細: doc/ADL_PROGRESS_v23.md。

実機用Gowinプロジェクト:
fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj

v22でユーザーが合成とスペースマンボウ起動を確認済み。
記録: doc/HARDWARE_RESULT_v22.md。v23の実機動作は未確認。
互換設定を維持。24bitの物理メモリ接続は未実装で、追加機能はシミュレーション確認。
新規実機COMは追加していない。既存hardware_testのCOM／ASMを同梱する。

検証の再実行:
- bash run_baseline.sh: 従来1667＋新規132＝1799ケースPASS。
- bash run_block_transfer.sh: 新規132ケースPASS。
- bash run_indexed_cb_suffix.sh: 幅指定解除8ケースPASS。
- bash run_size_smoke.sh: 規模測定用3構成×WAIT有無の6ケースPASS。

ログ: test_results_v23.log、test_results_block_v23.log、test_results_suffix_v23.log、test_results_size_v23.log。
測定用3プロジェクト（27 I/O）の使い方: doc/ADL_PROGRESS_v21.md。
Gowin本体がないため、ここでは合成・配置配線・使用量は未確認。
