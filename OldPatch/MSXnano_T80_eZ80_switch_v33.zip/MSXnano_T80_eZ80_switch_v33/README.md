# MSXnano T80/eZ80 V33

24bitアドレスとSDRAMをつなぐ回路を追加。
MSX互換バンク00を分離し、拡張RAM、MegaRAM/VRAM予約枠、未接続バンク、CPU WAITとVDP優先を実装した。
CPU6ソースは配布V32と同一。VRAMは既存VDPの格納方式に合わせて変換する。

実機用GOWIN：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
GPRJのメモリ用ソースを差替え／追加。Dual Purpose Pin、SystemVerilog、CST／SDCは維持。
配布時はtop_ez80.vのEZ80_EXTENDED=0でZ80互換設定。
1にすると24bit開発設定になる（Z80起動、ADLはDI限定）。
V33のGOWIN合成・配置配線・回路使用量・実機動作は未確認。
V33用bitstreamは同梱しない。過去のimplビルド生成物は配布ZIPから除外する（device.cfg設定は維持）。
V32はGOWIN合成成功、実機SOFARUNからスペースマンボウの起動・プレイ成功の報告を受領した。

詳細：doc/ADL_PROGRESS_v33.md。
現行メモリ割当：doc/MSXnano_eZ80_Memory_Allocation_v2.md。

- bash run_phase33.sh：新規メモリ検証（GHDL、Icarus Verilog、Python3）。
- bash run_baseline.sh：継承したV32のCPU回帰を再実行。
- python3 tools/verify_release33.py：V33のログ・ソース一致・GPRJ参照を検査。

新規30回のシミュレーションPASS。V32の25361回PASSの記録は継承し、再実行数に含めない。
新規実機用COMなし。sim/image33はシミュレーション用でDOS実行ファイルではない。
次のV34でDI限定ADL実機試験EZ80RAM.COMを作成する予定。
