# MSXnano T80/eZ80 v8

03hモード情報付き4バイトCALL/RETフレームを追加。
詳細: DOCM/ADL_PROGRESS_v8.md。GHDL: bash run_baseline.sh、155実行PASS。
ログ: test_results_v8.log。テストプログラム: sim/tb_call24.vhd。

ADL切替と02hによる短いモード復帰は未実装。新機能はFETCH24=trueの単体試験用。
MSX実機用FETCH24=falseを維持。拡張メモリ未接続。v8の合成・実機動作は未確認。
eZ80用プロジェクト: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
旧T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
既存実機COMは回帰用で、今回の4バイトフレームを試験するCOMではない。
ユーザー確認: v7でSofaRunからスペースマンボウ起動。
