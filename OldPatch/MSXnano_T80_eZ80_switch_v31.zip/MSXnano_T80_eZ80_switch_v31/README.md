# MSXnano T80/eZ80 v31

PUSH／POP AFのADL3バイト枠と、EX (SP),HL／IX／IYの24ビット交換を実装した。
短幅SPS／長幅SPL、パディング、全フラグ復元、境界、SP保持、WAITを検証する。
詳細と制限：doc/ADL_PROGRESS_v31.md。

旧テストのAF観測を明示短幅へ修正し、専用4380条件と元T80比較8条件を追加。
主回帰21287＋追加226＝21513実行（焦点テストを重複加算しない）。
GHDLとPython3が必要。

- bash run_baseline.sh：全回帰。
- bash run_stack31.sh：専用4380（主回帰内）。
- python3 tools/run_stack_compat31.py：新規元T80比較8。

主ケース：tools/regression_cases_v31.json。
主ログ：test_results_v31.log。結果：verification_result_v31.json。
新規ログ：test_results_stack_v31.log、test_results_stack_compat_v31.log。
GHDL_WORKERSは主回帰の並列数（既定8）。

実機用Gowin：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
GPRJ・Dual Purpose Pin・SystemVerilog・制約・標準CPU設定をv30から継承する。
v30はGOWIN合成と、実機SofaRunから夢幻戦士ヴァリス起動／プレイ成功の報告を受領。
v31のGOWIN合成・配置配線・使用量・実機確認は未実施。

A24物理メモリ接続とADL実機用COMは今後の工程。今回は新規COMなし。
追加95命令、ADL割込み／MADL／TRAP、全前置・反復境界は未完了。
次はv32のRLD／RRD、通常ADL RST、JR／DJNZ境界。
