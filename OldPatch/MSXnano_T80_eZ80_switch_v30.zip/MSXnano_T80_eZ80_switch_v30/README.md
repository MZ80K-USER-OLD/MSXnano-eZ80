# MSXnano T80/eZ80 v30

EX DE,HLの上位8ビット交換と、LD SP,HL／IX／IYのSPL24転送を追加した。
EXXは既存の主・代替切替を継承し、双方の24ビット値を検証した。
詳細と制限：doc/ADL_PROGRESS_v30.md。

新規2368条件は主回帰に含まれ、標準設定の元T80比較4条件も追加した。
主回帰16907＋追加218＝17125実行。再実行にはGHDLとPython3が必要。

- bash run_baseline.sh：全回帰。
- bash run_exchange30.sh：EX／EXX／LD SPの焦点2368（主回帰と重複）。
- python3 tools/run_exchange_compat30.py：元T80比較4。

ケース一覧：tools/regression_cases_v30.json。
主ログ：test_results_v30.log。結果：verification_result_v30.json。
新規ログ：test_results_exchange_sp_v30.log、test_results_exchange_compat_v30.log。
GHDL_WORKERSは主回帰の並列数（既定8）。

実機用Gowin：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
GPRJ・Dual Purpose Pin・SystemVerilog・制約・標準CPU設定をv29から継承する。
v29でGOWIN合成成功、実機で夢幻戦士ヴァリス実行成功の報告を受領した。
v30そのもののGOWIN合成・配置配線・使用量・実機確認は未実施。

24ビット物理メモリ接続と新規ADL実機用COMは今後の工程。今回は新規COMなし。
追加95命令、ADL割込み／MADL／TRAP、全前置・反復境界の一般化は未完了。
EX (SP)とPUSH／POP AFのADL化は次のv31で対応する。
元T80ソースは変更しない。
