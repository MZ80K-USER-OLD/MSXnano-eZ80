# MSXnano T80/eZ80 v20

CB形式のHL間接回転・シフト・BIT・RES・SETに24bitアドレスを追加。
通常命令はHLの上位バンクを使用。40h指定はbank 0。
新規テスト: sim/tb_cb_hl24.vhd（256ケース）。
仕様・制限: doc/ADL_PROGRESS_v20.md。ログ: test_results_v20.log。
実行: bash run_baseline.sh（GHDLとPython3）。

DDCB／FDCBは次段階。v20の合成・実機動作は未確認。
MSX標準設定FETCH24=false、ENABLE_MIXED=falseを維持。
A24メモリ接続前なので追加機能はシミュレーション用。
既存COM／ASMはhardware_testに同梱。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
元T80の8ファイルは基準SHA256と一致。
