#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p verification
cd verification
# Refresh the bench before each invocation to avoid stale work-library entries.
ghdl_run() {
 local entity arg
 for arg in "$@"; do
  if [[ "$arg" != -* ]]; then entity="$arg"; break; fi
 done
 ghdl -a --std=08 -fsynopsys "../sim/${entity}.vhd"
 ghdl -r "$@"
}
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A/$f.vhd
done
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A_eZ80/${f}_ez80.vhd
done
for tb in tb_baseline tb_ez80_baseline; do
 ghdl -a --std=08 -fsynopsys ../sim/$tb.vhd
 ghdl -e --std=08 -fsynopsys $tb
 for w in false true; do
  ghdl_run --std=08 -fsynopsys $tb -gINSERT_WAIT=$w --assert-level=error --vcd=${tb}_${w}.vcd
 done
done
ghdl -a --std=08 -fsynopsys ../sim/tb_upper.vhd
ghdl -e --std=08 -fsynopsys tb_upper
ghdl_run --std=08 -fsynopsys tb_upper --assert-level=error --vcd=upper.vcd

ghdl -a --std=08 -fsynopsys ../sim/tb_long_ld.vhd
ghdl -e --std=08 -fsynopsys tb_long_ld
for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_long_ld -gINSERT_WAIT=$w --assert-level=error --vcd=long_ld_${w}.vcd
done
python3 ../tools/check_long_ld.py long_ld_false.vcd long_ld_true.vcd

ghdl -a --std=08 -fsynopsys ../sim/tb_long_store.vhd
ghdl -e --std=08 -fsynopsys tb_long_store
for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_long_store -gINSERT_WAIT=$w --assert-level=error --vcd=long_store_${w}.vcd
done

ghdl -a --std=08 -fsynopsys ../sim/tb_hardware_com.vhd
ghdl -e --std=08 -fsynopsys tb_hardware_com
for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_hardware_com -gINSERT_WAIT=$w --assert-level=error
done

for tb in tb_v4_sparse tb_v4_irq; do
 ghdl -a --std=08 -fsynopsys ../sim/$tb.vhd
 ghdl -e --std=08 -fsynopsys $tb
 for w in false true; do
  ghdl_run --std=08 -fsynopsys $tb -gINSERT_WAIT=$w --assert-level=error
done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_v4_diagnostic.vhd
for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_v4_diagnostic -gINSERT_WAIT=$w --assert-level=error
done

for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_v4_irq -gINSERT_WAIT=$w -gIRQ_AT_ADDR=256 --assert-level=error
done

ghdl -a --std=08 -fsynopsys ../sim/tb_pc24.vhd
for b in 0 1 255; do
 for w in false true; do
  ghdl_run --std=08 -fsynopsys tb_pc24 -gBOOT_BANK=$b -gINSERT_WAIT=$w --assert-level=error
 done
done
for w in false true; do
 ghdl_run --std=08 -fsynopsys tb_pc24 -gWIDE_FETCH=false -gBOOT_BANK=255 -gINSERT_WAIT=$w --assert-level=error
done

# v6 target-transfer matrix: all eight conditions, taken/untaken, WAIT on/off.
ghdl -a --std=08 -fsynopsys ../sim/tb_jump24.vhd
for c in 0 1 2 3 4 5 6 7; do
 for t in false true; do
  for w in false true; do
   ghdl_run --std=08 -fsynopsys tb_jump24 -gCONDITION=$c -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_call24.vhd
for s in 196609 1 16711681; do
 for c in 0 1 2 3 4 5 6 7; do
  for t in false true; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_call24 -gSTACK_TOP=$s -gCONDITION=$c -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_mixed24.vhd
for s in 196609 1 16711681; do
 for c in 0 1 2 3 4 5 6 7; do
  for t in false true; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_mixed24 -gSTACK_TOP=$s -gCONDITION=$c -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_native24.vhd
for c in 0 1 2 3 4 5 6 7; do
 for t in false true; do
  for w in false true; do
   ghdl_run --std=08 -fsynopsys tb_native24 -gCONDITION=$c -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
  done
 done
done

# v11 native three-byte CALL/RET frame, all conditions and stack boundaries.
ghdl -a --std=08 -fsynopsys ../sim/tb_native_call24.vhd
for s in 196609 1 16711681; do
 for c in 0 1 2 3 4 5 6 7; do
  for t in false true; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_native_call24 -gSTACK_TOP=$s -gCONDITION=$c -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_pushpop24.vhd
for s in 196609 1 16711681; do
 for w in false true; do
  ghdl_run --std=08 -fsynopsys tb_pushpop24 -gSTACK_TOP=$s -gINSERT_WAIT=$w --assert-level=error
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_incdec24.vhd
for s in 196609 1 16711681; do
 for w in false true; do
  ghdl_run --std=08 -fsynopsys tb_incdec24 -gSTACK_TOP=$s -gINSERT_WAIT=$w --assert-level=error
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_spl_incdec24.vhd
for s in 65535 65536 16777215 0; do
 for t in false true; do
  for w in false true; do
   ghdl_run --std=08 -fsynopsys tb_spl_incdec24 -gSTACK_TOP=$s -gTAKEN=$t -gINSERT_WAIT=$w --assert-level=error
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_indirect24.vhd
for b in 1 127 253; do
 for a in 36864 65535; do
  for w in false true; do
   ghdl_run --std=08 -fsynopsys tb_indirect24 -gCONDITION=$b -gSTACK_TOP=$a -gINSERT_WAIT=$w --assert-level=error
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_indexed24.vhd
for b in 0 1 127 255; do
 for a in 0 65535; do
  for d in -128 -1 0 1 127; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_indexed24 -gCONDITION=$b -gSTACK_TOP=$a -gDISPLACEMENT=$d -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_absolute24.vhd
for b in 1 127 255; do
 for a in 36864 65535; do
  for w in false true; do
   ghdl_run --std=08 -fsynopsys tb_absolute24 -gCONDITION=$b -gSTACK_TOP=$a -gINSERT_WAIT=$w --assert-level=error
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_pair_absolute24.vhd
for b in 1 127 255; do
 for a in 65534 65535; do
  for r in 0 1 2; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_pair_absolute24 -gCONDITION=$b -gSTACK_TOP=$a -gREG_SELECT=$r -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_ed_absolute24.vhd
for b in 1 127 255; do
 for a in 65534 65535; do
  for r in 0 1 2 3; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_ed_absolute24 -gCONDITION=$b -gSTACK_TOP=$a -gREG_SELECT=$r -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_memory_alu24.vhd
for b in 1 255; do
 for a in 0 65535; do
  for d in -128 127; do
   for r in 0 1 2; do
    for w in false true; do
     ghdl_run --std=08 -fsynopsys tb_memory_alu24 -gCONDITION=$b -gSTACK_TOP=$a -gDISPLACEMENT=$d -gREG_SELECT=$r -gINSERT_WAIT=$w --assert-level=error
    done
   done
  done
 done
done

ghdl -a --std=08 -fsynopsys ../sim/tb_cb_hl24.vhd
for b in 1 255; do
 for c in {0..31}; do
  for s in false true; do
   for w in false true; do
    ghdl_run --std=08 -fsynopsys tb_cb_hl24 -gBANK=$b -gCONDITION=$c -gTAKEN=$s -gINSERT_WAIT=$w --assert-level=error
   done
  done
 done
done
