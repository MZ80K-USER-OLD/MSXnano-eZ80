# 実装から確認したSDRAM物理アドレス配置

調査日：2026-10-31。
対象：本配布のTang Nano 20K、SDRAM_32有効、8MiB。
top_ez80.vで実際にインスタンス化されるmemory_ctrl_ez80（mem1）と、その入力生成を調査した。
V33／V34／V34.1のメモリコントローラとアドレスブリッジは同じ配置である。
元のmemory.vにはCPU拡張RAMへの要求入力がないが、Mapper／MegaRAM／VDPの配置は同じ。
これはRTLの配線確認であり、GOWIN配置配線や実機のアドレス試験結果ではない。

## 物理バイトアドレスPの定義

CPU用コントローラの23bit byte addressをPとする。
SDRAM端子ではアドレスを行と列に分けて出力する。

| 端子上の選択 | Pのビット |
|---|---|
| バンクBA[1:0] | P[22:21] |
| 列A[7:0] | P[20:13] |
| 行A[10:0] | P[12:2] |
| 32bitワード内のバイト位置 | P[1:0] |

行2048×列256×バンク4×4バイト＝8,388,608バイト。
行アドレスと列アドレスは同じA端子を時分割で使う。
Pの連番と一般的な「bank,row,column」順の表記を混同しない。
同梱される別のmemory_controller.v／sdram.vのアドレス式ではなく、mem1の実装を根拠とする。

## 全体配置

範囲は両端を含む。KiBは1024バイト、MiBは1024KiB。

| P：物理バイトアドレス | 容量 | 実装上の用途 |
|---|---:|---|
| 000000h～3FFFFFh | 4MiB | MSX Memory Mapper。16KiB×256ページ |
| 400000h～5FFFFFh | 2MiB | MegaRAM/SCCカートリッジのRAM本体。8KiB×256バンク |
| 600000h～63FFFFh | 256KiBの格納枠 | VRAM。現VDPの128KiBと拡張予約128KiBがバイト位置ごとに分散 |
| 640000h～64FFFFh | 64KiB | 未割当の予備領域 |
| 650000h～7FFFFFh | 1,728KiB | eZ80のCPU拡張RAM。論理01h～1Bhから接続 |

容量合計：4096＋2048＋256＋64＋1728＝8192KiB。
SDRAMバンクBA=00/01がMapper、BA=10がMegaRAM、BA=11にVRAM・予備・CPU拡張RAMが入る。

## Mapperの実装

top_ez80.vは、CPUの16bitアドレスの上位2bitでmapper_reg0～3を選ぶ。

```
mapper_addr = { selected_mapper_reg[7:0], CPU_A[13:0] }
P = { 1'b0, mapper_addr[21:0] }
  = selected_mapper_reg * 4000h + (CPU_A & 3FFFh)
```

I/O FC～FFhが各16KiB窓のページ番号を設定する。
対応するスロット／サブスロットが選択され、mapper_reqが成立したときにこの領域へアクセスする。
CPUの0000h～FFFFhを常にSDRAMの000000h～00FFFFhへ直結しているわけではない。

リセット時のレジスタは3、2、1、0。

| MSXの窓 | 初期ページ | Mapperが選択されている場合のP |
|---|---:|---|
| 0000～3FFFh | 3 | 00C000～00FFFFh |
| 4000～7FFFh | 2 | 008000～00BFFFh |
| 8000～BFFFh | 1 | 004000～007FFFh |
| C000～FFFFh | 0 | 000000～003FFFh |

拡張スロットのFFFFhアクセスはセカンダリスロット選択の特例が優先され、
通常のMapper要求から除外される。上表の最後の1バイトもこの条件に従う。
eZ80の高位バンクアクセスをMSXのMREQから隔離する理由の一つである。

## MegaRAMの実装

megaram.vは、選択した8bitバンクレジスタとCPU_A[12:0]から21bitオフセットを作る。

```
megaram_addr = { selected_megaram_reg[7:0], CPU_A[12:0] }
P = 400000h + megaram_addr
```

memory_ez80.vの32bit構成では、{3'b010,megaram_addr[20:0]}をsdram_addrへ入れる。
結果は400000h～5FFFFFhとなる。
linear指定時はmegaram_addr={5'b00000,CPU_A[15:0]}なので、400000hから64KiBを参照する。
SCC波形・制御レジスタを選ぶアクセスはRAM要求から分離される。
eZ80論理40～5FhはRAM本体の直接aliasであり、SCCレジスタ操作のaliasではない。

## VRAMの実装：連続128KiBではない

VDP側vram_addrは17bit（V）で、コントローラの端子への配線は次のとおり。

```
BA = 11b
row = V[10:0]
column = {000b,V[15:11]}
byte lane = V[16]    // byte 0またはbyte 1。byte 2/3は書込みマスク
```

CPU用Pの表現へ戻すと：

```
P_VDP = 600000h + ((V & FFFFh) << 2) + ((V >> 16) & 1)
```

| VRAM内のアドレス | P |
|---|---|
| 00000h | 600000h |
| 00001h | 600004h |
| 0FFFFh | 63FFFCh |
| 10000h | 600001h |
| 10001h | 600005h |
| 1FFFFh | 63FFFDh |

32bitワードごとの用途は次のようになる。

| Pの範囲と刻み | 容量 | 用途 |
|---|---:|---|
| 600000,600004,…,63FFFCh | 64KiB | 現VDPの下位64KiB。byte 0 |
| 600001,600005,…,63FFFDh | 64KiB | 現VDPの上位64KiB。byte 1 |
| 600002,600006,…,63FFFEh | 64KiB | 拡張予約。byte 2 |
| 600003,600007,…,63FFFFh | 64KiB | 拡張予約。byte 3 |

現在のVDPからアクセスできるのは合計128KiB。
620000h～63FFFFhも現VDPのデータを含むため、連続した未使用128KiBとして再利用してはいけない。
拡張予約の128KiBはbyte 2/3であり、物理番地が散らばっている。
「VRAM256KiBの枠を予約」と「VDPが256KiB全体を表示できる」は別である。

## eZ80論理アドレスからPへの変換

| 論理アドレス | 接続・変換 |
|---|---|
| 000000～00FFFFh | MSX窓。スロットとMapper等を通す |
| 010000～1BFFFFh | P=論理アドレス+640000h |
| 1C0000～3FFFFFh | 未接続。読出しFF、書込み無視 |
| 400000～5FFFFFh | P=論理アドレス。MegaRAMと共有 |
| 600000～63FFFFh | P=600000h+((A & FFFFh)<<2)+((A>>16)&3) |
| 640000～FFFFFFh | 未接続。読出しFF、書込み無視 |

論理60/61/62/63バンクが、それぞれ物理ワード内のbyte 0/1/2/3を線形に見せる。
論理640000hは物理640000hに接続しない。
論理010000hは物理650000h、論理1BFFFFhは物理7FFFFFh。
物理VRAM格納枠の末尾63FFFFhと、CPU拡張RAMの先頭650000hは重ならない。

## SDRAMに含まれないもの

MAIN BIOS、SUB-ROM、ロゴ/FMメニューは、個別のROM配列インスタンスであり、
このSDRAMコントローラの物理領域には割り当てられていない。
SD用の転送バッファやSPIフラッシュ上のROMも、このPの空間と区別する。

## 根拠ファイル

- fpga/top_ez80.v：mem1の接続、Mapperのアドレス生成、FFFFh除外、ROMインスタンス。
- fpga/src/memory_ez80.v：Mapper/MegaRAMの配置、行／列／バンク、VDPのアドレスとDQM。
- fpga/src/ez80_memory_bridge.v：CPU拡張RAM、MegaRAM alias、VRAM byte lane変換、範囲外処理。
- fpga/src/megaram.v：8KiB単位のアドレス、linear設定、SCC波形とRAMの分離。

16bit SDRAM用のifndef分岐は、今回有効なSDRAM_32構成の根拠に使っていない。
