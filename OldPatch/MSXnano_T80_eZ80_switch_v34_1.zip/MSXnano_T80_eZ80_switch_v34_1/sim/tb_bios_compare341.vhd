library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
use std.textio.all;use ieee.std_logic_textio.all;
entity tb_bios_compare341 is
 generic(EXTENSIONS:boolean:=true;SEED:boolean:=false;CARRY_IN:boolean:=false);
end;
architecture test of tb_bios_compare341 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';
 signal phase:natural range 0 to 15:=0;signal ce,cf:std_logic;
 signal a,b:std_logic_vector(15 downto 0);signal di,doa,dob:std_logic_vector(7 downto 0);
 signal ca,cb:std_logic_vector(7 downto 0);
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 function makecode return bytes_t is variable m:bytes_t(0 to 255):=(others=>x"76");variable n:natural:=0;
 procedure seq(v:bytes_t) is begin for i in v'range loop m(n):=v(i);n:=n+1;end loop;end;
 procedure put(x:natural) is begin m(n):=std_logic_vector(to_unsigned(x,8));n:=n+1;end;
 begin
 seq((x"31",x"00",x"F0",x"3E",x"C9",x"32",x"00",x"00",x"21",x"00",x"90"));
 if SEED then seq((x"3E",x"81"));else seq((x"3E",x"00"));end if;seq((x"77",x"3E",x"A5",x"B7"));
 if CARRY_IN then put(16#37#);end if;
 seq((x"ED",x"6F",x"F5",x"C1",x"ED",x"43",x"00",x"91",x"ED",x"67",x"F5",x"C1",x"ED",x"43",x"02",x"91"));
 for v in 0 to 7 loop put(16#C7#+v*8);end loop;
 seq((x"06",x"03",x"10",x"FE",x"18",x"00",x"20",x"00",x"28",x"00",x"30",x"00",x"38",x"00",x"F5",x"C1",x"ED",x"43",x"04",x"91",x"76"));return m;end;
 constant code:bytes_t:=makecode;
 type memory_t is array(0 to 65535) of std_logic_vector(7 downto 0);
 impure function initial_memory return memory_t is
 variable m:memory_t:=(others=>x"FF"); file f:text open read_mode is "../../fpga/src/bios_msx2p.hex";
 variable l:line;variable v:std_logic_vector(7 downto 0);variable i:natural:=0;
 begin while not endfile(f) loop readline(f,l);hread(l,v);m(i):=v;i:=i+1;end loop;return m;end;
 signal mem:memory_t:=initial_memory;
 type ram_t is array(0 to 131071) of std_logic_vector(7 downto 0);signal ram:ram_t:=(others=>x"FF");
 type maps_t is array(0 to 3) of natural range 0 to 255;signal maps:maps_t:=(3,2,1,0);
 signal primary,secondary:std_logic_vector(7 downto 0):=x"00";
 signal wr_old:std_logic:='0';signal vdp_count:natural:=0;signal a24:std_logic_vector(23 downto 0);
 function slot(p:std_logic_vector(7 downto 0);address:std_logic_vector(15 downto 0)) return natural is variable page:natural;
 begin page:=to_integer(unsigned(address(15 downto 14)));return to_integer(unsigned(p(page*2+1 downto page*2)));end;
signal last_fetch:std_logic_vector(15 downto 0):=x"FFFF";
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if falling_edge(clk) and reset_n='1' and ca(0)='0' and ca(1)='0' and ca(5)='1' and a/=last_fetch and (unsigned(a)<16#450# or unsigned(a)>16#4C1#) then
 report "FETCH "&to_hstring(a)&" op="&to_hstring(di);last_fetch<=a;end if;end process;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 original:entity work.G80a port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>ca(0),MREQ_n=>ca(1),IORQ_n=>ca(2),RD_n=>ca(3),WR_n=>ca(4),RFSH_n=>ca(5),HALT_n=>ca(6),BUSAK_n=>ca(7),A=>a,update_addr=>open,DI=>di,DO=>doa,Data_Reverse=>open);
 extended:entity work.G80A_eZ80 generic map(FETCH24=>EXTENSIONS,ENABLE_MIXED=>EXTENSIONS,ENABLE_SUFFIX_V2=>EXTENSIONS,ENABLE_EZ80_ISA=>EXTENSIONS,BOOT_Z80_COMPAT=>EXTENSIONS) port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>cb(0),MREQ_n=>cb(1),IORQ_n=>cb(2),RD_n=>cb(3),WR_n=>cb(4),RFSH_n=>cb(5),HALT_n=>cb(6),BUSAK_n=>cb(7),A=>b,A24=>a24,update_addr=>open,DI=>di,DO=>dob,Data_Reverse=>open);
 process(all) variable address,page,phys,pri,ss:natural;
 begin
 di<=x"FF";
 if not is_x(a) then
 address:=to_integer(unsigned(a));page:=address/16384;pri:=slot(primary,a);ss:=slot(secondary,a);
 phys:=(maps(page) mod 8)*16384+(address mod 16384);
 if ca(2)='0' then
 case address mod 256 is
 when 16#A8#=>di<=primary;
 when 16#99#=>di<=x"80";
 when 16#FC# to 16#FF#=>di<=std_logic_vector(to_unsigned(maps(address mod 4),8));
 when others=>null;end case;
 elsif pri=0 and address<32768 then di<=mem(address);
 elsif pri=3 and address=65535 then di<=not secondary;
 elsif pri=3 and ss=0 then di<=ram(phys);
 end if;
 end if;end process;
 process(clk) variable address,page,phys,pri,ss:natural;
 begin if rising_edge(clk) then
 if reset_n='0' then wr_old<='0';primary<=x"00";secondary<=x"00";maps<=(3,2,1,0);
 else
 wr_old<=not ca(4);
 if ca(4)='0' and wr_old='0' and not is_x(a) then
 address:=to_integer(unsigned(a));page:=address/16384;pri:=slot(primary,a);ss:=slot(secondary,a);
 phys:=(maps(page) mod 8)*16384+(address mod 16384);
 if ca(2)='0' then
 case address mod 256 is
 when 16#A8#=>primary<=doa;
 when 16#FC# to 16#FF#=>maps(address mod 4)<=to_integer(unsigned(doa));
 when 16#99#=>vdp_count<=vdp_count+1;report "VDP write "&to_hstring(doa)&" PCaddr "&to_hstring(a);
 when others=>null;end case;
 elsif ca(1)='0' then
 if pri=3 and address=65535 then secondary<=doa;
 elsif pri=3 and ss=0 then ram(phys)<=doa;end if;
 end if;end if;end if;end if;end process;
 process(clk) begin if falling_edge(clk) and reset_n='1' then
 assert ca=cb report "BIOS control mismatch orig="&to_hstring(a)&" ext="&to_hstring(b) severity failure;
 assert a=b report "BIOS address mismatch orig="&to_hstring(a)&" ext="&to_hstring(b) severity failure;
 assert a24(23 downto 16)=x"00" report "BIOS escaped bank00 at "&to_hstring(a24) severity failure;
 if ca(4)='0' then assert doa=dob report "compat write data/registers/flags differ from original T80" severity failure;end if;
 end if;end process;
 process begin wait until ca(6)='0';wait for 100 ns;assert cb(6)='0' report "compat HALT" severity failure;report "PASS default RLD/RRD/RST/JR/DJNZ bus cycles/registers/flags match original T80";stop;end process;
 process begin wait for 20 ms;report "PASS BIOS comparison interval VDP writes="&natural'image(vdp_count);stop;end process;
 end;
