# V34.1の変更（先に確認）

同梱の新EZ80RAM.COMに差し替える。
V34.1はRESET直後のADL=0に加え、拡張命令の解釈もロックする。
COMがDIでE7E7hへA5/5Aを出力して解除し、終了時に00でロックしてからDOSを呼ぶ。
古いV34 COMは解除手順がないため使用しない。
黒画面対策の詳細と限界はdoc/BOOT_AND_BUS_FIX_v34_1.mdを参照。
V34.1のGOWIN合成・実機起動は未確認。

# EZ80RAM.COM V34：DI限定ADL実機試験

## 実行手順

1. ZIPを通常のフォルダへ展開する。
2. GOWINでfpga/project_eZ80/MSXNanoTang20K_eZ80.gprjを開く。
3. fpga/top_ez80.vのEZ80_EXTENDED=1を確認する。V34.1もハードウェア設定は1で、BOOT_Z80_COMPAT=1により起動時ロック。
   RESET_ADL=0でZ80モードから起動する設定を維持する。
4. 合成・配置配線を実行し、このプロジェクトが新しく生成したbitstreamを実機へ書き込む。
5. hardware_test/EZ80RAM.COMをMSX-DOSのディスクへコピーする。
6. MSX-DOSのコマンドプロンプトで`EZ80RAM`を実行する。

正常時の表示：

```
EZ80RAM v34.1: DI-only ADL RAM test
EZ80RAM: PASS
```

その後、DOSのプロンプトへ戻る。
通常のZ80起動とゲーム互換性の確認は、引き続きSOFARUN等から別途行う。
この資料作成時点でV34のGOWIN合成と実機試験は未実施。

## 表示の意味

| 表示 | 意味・次の確認 |
|---|---|
| PASS | 下記のRAM・ADL・復帰検査を通過 |
| UNSUPPORTED | 幅指定の事前プローブが不成立。拡張RAM書込み前に終了。GPRJ、EZ80_EXTENDED、書き込んだbitstreamを確認 |
| FAIL stage C | Z80モードで高位RAMへコピーしたコードの読戻し不一致 |
| FAIL stage 1 | 01～1Bの27バンクが独立していない、または値が不一致 |
| FAIL stage 2 | 02FFFF→030000のバイトアクセス不一致 |
| FAIL stage 3 | 3バイトのレジスタ転送・保存・境界不一致 |
| FAIL stage 4 | 050001からの24bitスタック、PUSH/POP不一致 |
| FAIL stage 5 | ADL CALL/RET後の結果不一致 |
| FAIL stage 6 | 命令取得境界の試験中。復帰できない誤動作は停止する場合がある |
| FAIL stage 7 | MBASE、.SIS/.LIS/.SIL/.LIL、短幅ラップの不一致 |
| FAIL stage 8 | 最終バンク・未接続バンクの読戻し不一致 |
| FAIL stage G | MSX側ガード、または同じ下位16bitの高位バンク分離を確認 |
| FAIL stage P | ADLから戻った直後のZ80用SPが保存値と不一致 |
| FAIL stage S | FFFFhのセカンダリスロット選択値が変化 |

PASSはこの試験範囲の結果であり、eZ80全命令やADL割込みの完成を示すものではない。

## 試験内容と使用RAM

- 01～1Bの各xx8000へ異なる値を書き、逆順に照合する。
- 02FFFF/030000境界でバイト転送、3バイトのペア転送を行う。
- SPL=050001からのPUSH/POPと、SPL=060100でのADL CALL/RETを行う。
- 01FFFEから始まるJPの即値が020000へまたがり、020100の中継コードから戻る。
- MBASE=02で短幅アクセスを行い、FFFF→0000で同じバンク内へ折り返すことを確認する。
- .SISの2バイト書込みが隣接第3バイトを変更しないこと、.SIL/.LISのアドレス解釈を確認する。
- 1BFFFFを読み書きし、1C0000/3FFFFF/640000/FFFFFFはFF読出し・書込み無視を確認する。
- バンク07のガードと、同じ下位16bitのMSX窓を分離する。
- Z80へ戻り、SPS、MSXガード、FFFFhの値を照合してDOSへ復帰する。

コードを010000から配置し、01FFFE～020001、020100～020103にも中継コードを置く。
試験は上記データ領域、030100～030102、スタック用04FFFE～050000／0600FD～0600FF、
およびバンク07のガードを上書きする。拡張RAMの試験領域は使い捨てとして扱う。
VRAM/MegaRAM予約枠への直接書込みは行わない。

## 割込みとDOS呼出し

MSX-DOSの通常のコマンドとして、ADL=0、MBASE=00で開始する。
開始メッセージをBDOSで出した後にDIし、コピー・ADL実行・復帰確認を行う。
ADL中はBIOS/BDOSを呼ばない。MBASE=00とZ80モードを戻し、EI後に結果を表示する。
通常のDOS呼出しを前提とし、任意のDI状態の呼出し元のIFFを保存・復元するAPIではない。
IX/IYと呼出し元のZ80スタックを戻してRETする。
NMI、ADL割込み、MADL混在フレームは今回の試験対象外。

UNSUPPORTED判定はCPUの幅指定を確認するもので、旧版の独自設定bitstreamの
メモリ配線を自動判定する機能ではない。V34の指定プロジェクトから生成したbitstreamで使う。

## ソースと再現

- EZ80RAM.COM：実機で実行するファイル。
- ez80ram_v34.asm：COMと同じバイト列のDEFBソースと、高位RAM側の注釈。
- build_ram34.py：外部アセンブラ不要の生成器。
- EZ80RAM_v34.json：ハッシュ、アドレス、コード配置。
- EZ80RAM.hex、EZ80RAM_v34.vh：シミュレーション用。

`python3 hardware_test/build_ram34.py`で再生成する。
`bash run_phase34.sh`でCOMの実行シミュレーションを行う。
