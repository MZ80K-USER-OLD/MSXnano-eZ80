#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/run_guard341.py
python3 tools/run_selected341.py
python3 tools/run_com34.py
python3 tools/collect_release341.py
python3 tools/verify_release341.py
