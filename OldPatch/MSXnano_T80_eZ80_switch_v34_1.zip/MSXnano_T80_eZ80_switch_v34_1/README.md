# MSXnano T80/eZ80 V34.1

V34の黒画面報告を受け、リセット直後は拡張命令の解釈をロックする対策を追加した。
ADL=0、MBASE=00で起動し、BIOS/DOS/ゲームは元T80の命令解釈を使う。
同梱の新しいEZ80RAM.COMがDIでロックを解除し、ADL試験後に再ロックしてDOSへ戻る。
黒画面の直接原因と実機での改善は未確認。

1. fpga/project_eZ80/MSXNanoTang20K_eZ80.gprjで再ビルドして書き込む。
2. 起動画面・SOFARUN・ゲームを確認する。
3. hardware_testの新しいEZ80RAM.COMをMSX-DOSで実行する。

正常表示はEZ80RAM: PASS。旧V34のCOMには解除手順がないので差し替える。
GOWIN合成・配置配線・使用量・実機動作は未確認。bitstreamは同梱しない。
GPRJ、Dual Purpose Pin、SystemVerilog、CST／SDCは継承。

起動対策、ADLとの区別、制御ポートとバス分離：doc/BOOT_AND_BUS_FIX_v34_1.md。
メモリの16/24bit経路分離、VDP優先、CPU WAITと物理配置はV33から継承する。

新規検証：ロック時の元T80比較16、選択回帰129、新COM5、BIOS初期比較1＝151実行。
全CPU回帰25361実行の再実行ではない。BIOS比較は画面表示まで到達していない。

- python3 hardware_test/build_ram34.py：新COMを再生成。
- bash run_phase34.sh：新COMの5条件を実行。
- python3 tools/run_guard341.py：ロック時比較とBIOS初期比較。
- python3 tools/run_selected341.py：46ベンチの129条件。
- python3 tools/verify_release341.py：配布内容の検査。

SDRAMの実装に基づく物理配置：doc/SDRAM_Physical_Map_Implementation_v34_1.md。
151条件をまとめて再実行する場合：bash run_phase341.sh。
