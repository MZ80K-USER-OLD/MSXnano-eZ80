#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
cd build
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A/$f.vhd
done
ghdl -a --std=08 -fsynopsys ../sim/tb_baseline.vhd
ghdl -e --std=08 -fsynopsys tb_baseline
ghdl -r --std=08 -fsynopsys tb_baseline --assert-level=error --vcd=baseline.vcd
ghdl -r --std=08 -fsynopsys tb_baseline -gINSERT_WAIT=true --assert-level=error --vcd=baseline_wait.vcd
