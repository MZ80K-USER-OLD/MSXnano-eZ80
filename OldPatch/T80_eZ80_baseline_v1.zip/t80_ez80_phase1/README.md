# T80 → eZ80 段階B：基準環境 v1

## 状態
ユーザー提供の実機動作済み msxNano_PS2Keyboard.zip の G80A/T80 を無変更で収録。
CPUの24bit化はまだ実装していない。元のZIPを置換しない別の検証パッケージ。

## 実行
GHDL 4.1.0で検証。bash run_baseline.sh を実行する。
VHDL-2008 / -fsynopsys を使用。GHDLがPATH上に必要。
build/baseline.vcd と baseline_wait.vcd を生成する。

## 確認範囲
LD SP/HL、PUSH/POP、EX DE,HL、16bitメモリ書込み、CALL/RET、INC HL、IN/OUT、HALT。
通常実行と周期的なWAIT挿入でメモリ結果およびOUTをassert。
WAITは限定的な停止パターン。全命令、割込み、BUSRQ、MSX BIOS起動、MSXの実際のclk_enable分周は未検証。
起動直後の未初期化レジスタに由来するnumeric_std警告あり。失敗ではないが、未知値を正常値として扱う検証にはしないこと。

## 基準規模
添付ZIPの2026-10-03合成レポート：T80 u0配下 LUT 1839 / Register 483、G80A cpu1配下 LUT 1870 / Register 500。
ALU、BSRAM、SSRAMは別項目。新規合成ではなく添付レポートの値。現在ソースとの再合成一致は未確認。

## 次の実装
CHANGE_PLAN.mdを参照。まず幅制御の契約とレジスタ上位バイトを設計し、Z80モードの回帰検証を維持する。
ADLテストは当面アセンブラを使用。z88dkのADLアセンブラ対応と24bit C環境は区別する。
