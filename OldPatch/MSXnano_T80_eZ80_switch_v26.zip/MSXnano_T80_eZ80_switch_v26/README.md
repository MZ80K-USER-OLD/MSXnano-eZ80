# MSXnano T80/eZ80 v26

ADC HL／SBC HLを24bit化。BC／DE／HL／SPL、入力C、桁上がり・桁借り、
全24bitのゼロ判定と符号付きオーバーフローに対応した。
既存8bit ALUとv25の上位バイト段を共用する。
詳細: doc/ADL_PROGRESS_v26.md。

実機用Gowinプロジェクト:
fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj

v25でユーザーが合成とスペースマンボウ起動・プレイを確認済み。
記録: doc/HARDWARE_RESULT_v25.md。v26の合成・実機動作は未確認。
互換設定を維持。24bitの物理メモリ接続は未実装で、追加機能はシミュレーション確認。
新規実機COMは追加していない。既存hardware_testのCOM／ASMを同梱する。

検証の再実行:
- bash run_baseline.sh: 従来2639＋新規1056＝3695ケースPASS。
- bash run_adc_sbc24.sh: 基本1024＋符号境界32ケースPASS。
- bash run_indexed_cb_suffix.sh: 幅指定解除8ケースPASS。
- bash run_size_smoke.sh: 規模測定用3構成×WAIT有無の6ケースPASS。

ログ: test_results_v26.log、test_results_adc_sbc_v26.log、test_results_adc_sbc_sign_v26.log、test_results_focus_v26.log、test_results_suffix_v26.log、test_results_size_v26.log。
新規1024ケースの個別ログは全回帰ログから抜粋したもの。
全回帰のケース一覧: tools/regression_cases_v26.json。GHDL_WORKERSで並列数を指定できる（標準8）。
結果一覧: verification_result_v26.json。
測定用3プロジェクト（27 I/O）の使い方: doc/ADL_PROGRESS_v21.md。
Gowin本体がないため、ここでは合成・配置配線・使用量は未確認。
