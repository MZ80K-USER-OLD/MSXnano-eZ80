# MSXnano T80/eZ80 v22

DDCB／FDCBメモリ形式のIX／IY＋符号付き変位を24bitアドレスへ拡張。
回転・シフト・BIT・RES・SETの32形式、40短幅、WAIT、バンク境界を検証する。
詳細と制限: doc/ADL_PROGRESS_v22.md。

実機用Gowinプロジェクト:
fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj

互換設定を維持。新しい24bit機能の物理メモリ接続は未実装で、シミュレーション確認の段階。
新規実機COMは追加していない。既存hardware_testのCOM／ASMを同梱する。
v20でスペースマンボウの起動・動作がユーザー実機で確認されている。

検証:
- bash run_baseline.sh: 従来899＋新規768ケース。
- sim/tb_indexed_cb_suffix24.vhd: 次命令へ短幅が漏れないことを8ケースPASS。
- bash run_size_smoke.sh: CPU規模測定用3構成×WAIT有無の6ケースPASS。
ログ: test_results_v22.log、test_results_suffix_v22.log、test_results_size_v22.log。

v21のCPU規模測定用3プロジェクト（27 I/O）も同梱。
測定手順: doc/ADL_PROGRESS_v21.md。
測定用ビットストリームはボードへ書き込まないこと。
Gowinでの合成・配置配線および使用量はこの環境では未確認。
