library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_indexed_cb_suffix24 is
 generic(INSERT_WAIT:boolean:=false; CONDITION:natural range 0 to 31:=0; BANK:natural:=1; TAKEN:boolean:=true; STACK_TOP:natural:=65535; REG_SELECT:natural range 0 to 2:=0; DISPLACEMENT:integer range -128 to 127:=1);
end;
architecture test of tb_indexed_cb_suffix24 is
 signal clk:std_logic:='0';
 signal reset_n:std_logic:='0';
 signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;
 signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);
 signal a24:std_logic_vector(23 downto 0);
 signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal ram,stack_a,stack_f:std_logic_vector(7 downto 0):=x"A5";
 signal writes,mem_writes:natural:=0;signal prev_wr:std_logic:='1';
 function mode_prefix return std_logic_vector is begin if TAKEN then return x"40";else return x"00";end if;end;
 function mem_address return natural is begin if TAKEN then return (STACK_TOP+DISPLACEMENT) mod 65536;else return (BANK*65536+STACK_TOP+DISPLACEMENT) mod 16777216;end if;end;
 constant target:natural:=mem_address;
 function index_prefix return std_logic_vector is begin if REG_SELECT=0 then return x"DD";else return x"FD";end if;end;
 constant disp:std_logic_vector(7 downto 0):=std_logic_vector(to_signed(DISPLACEMENT,8));
 function op return std_logic_vector is
 begin return std_logic_vector(to_unsigned((CONDITION/8)*64+(CONDITION mod 8)*8+6,8));end;
 function initial_value return std_logic_vector is
 begin if CONDITION<16 then return x"81";elsif CONDITION<24 then return x"FF";else return x"00";end if;end;
 type bytes_t is array(0 to 7) of std_logic_vector(7 downto 0);
 constant rotate_results:bytes_t:=(x"03",x"C0",x"03",x"C0",x"02",x"C0",x"03",x"40");
 constant rotate_flags:bytes_t:=(x"05",x"85",x"05",x"85",x"01",x"85",x"05",x"01");
 function result_value return std_logic_vector is
 begin if CONDITION<8 then return rotate_results(CONDITION);
 elsif CONDITION<16 then return x"81";
 elsif CONDITION<24 then return std_logic_vector(to_unsigned(255-2**(CONDITION mod 8),8));
 else return std_logic_vector(to_unsigned(2**(CONDITION mod 8),8));end if;end;
 function flag_value return std_logic_vector is
 begin if CONDITION<8 then return rotate_flags(CONDITION);
 elsif CONDITION=8 then return x"11";
 elsif CONDITION=15 then return x"91";
 elsif CONDITION<16 then return x"55";
 else return x"85";end if;end;
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:code_t:=(index_prefix,x"21",std_logic_vector(to_unsigned(STACK_TOP mod 256,8)),std_logic_vector(to_unsigned(STACK_TOP/256,8)),std_logic_vector(to_unsigned(BANK,8)),
 mode_prefix,index_prefix,x"36",disp,initial_value,x"3E",x"99",x"B7",x"37",mode_prefix,index_prefix,x"CB",disp,op,
 x"21",x"56",x"34",x"12",x"F5",x"40",x"C1",x"79",x"E6",x"D7",x"FE",flag_value,x"C2",x"FF",x"0F",x"20",
 mode_prefix,index_prefix,x"7E",disp,x"FE",result_value,x"C2",x"FF",x"0F",x"20",x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;begin
 di<=x"00";
 if not is_x(a24) then
 n:=to_integer(unsigned(a24));
 if n=target then di<=ram;elsif n=16#FFFE# then di<=stack_a;elsif n=16#FFFD# then di<=stack_f;end if;
 if n>=16#200000# and n<16#200000#+code'length then di<=code(n-16#200000#);end if;
 if n=16#200FFF# then di<=x"76";end if;
 end if;end process;
 process(clk) variable n:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a24(15 downto 0)=a report "low address mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank mismatch" severity failure;end if;
 if mreq='0' and rd='0' then assert a24/=x"200FFF" report "CB result/flags mismatch" severity failure;end if;
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 n:=to_integer(unsigned(a24));writes<=writes+1;
 if n=target then
 if mem_writes=0 then assert dout=initial_value report "initial memory value" severity failure;
 else assert not (CONDITION>=8 and CONDITION<16) report "BIT wrote memory" severity failure;assert mem_writes=1 and dout=result_value report "CB memory write result/count" severity failure;end if;
 mem_writes<=mem_writes+1;ram<=dout;
 elsif n=16#FFFE# then assert dout=x"99" report "CB changed A" severity failure;stack_a<=dout;
 elsif n=16#FFFD# then assert (dout and x"D7")=flag_value report "CB flags mismatch" severity failure;stack_f<=dout;
 else assert false report "wrong CB write address " & integer'image(n) severity failure;end if;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;
 if CONDITION>=8 and CONDITION<16 then assert writes=3 and mem_writes=1 report "BIT write count" severity failure;
 else assert writes=4 and mem_writes=2 report "CB write count" severity failure;end if;
 report "PASS indexed CB IX IY rotate shift BIT RES SET, flags, bank and short mode, WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "CB timeout" severity failure;end process;
 end;
