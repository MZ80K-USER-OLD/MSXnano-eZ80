library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_memory_alu24 is
 generic(INSERT_WAIT:boolean:=false; CONDITION:natural:=1; TAKEN:boolean:=true; STACK_TOP:natural:=65535; REG_SELECT:natural range 0 to 2:=0; DISPLACEMENT:integer range -128 to 127:=1);
end;
architecture test of tb_memory_alu24 is
 signal clk:std_logic:='0';
 signal reset_n:std_logic:='0';
 signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;
 signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);
 signal a24:std_logic_vector(23 downto 0);
 signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 type ram_t is array(0 to 3) of std_logic_vector(7 downto 0);
 signal ram:ram_t:=(others=>x"A5");
 signal prev_wr:std_logic:='1';signal writes:natural:=0;
 constant base:natural:=CONDITION*65536+STACK_TOP;
 function offset return integer is begin if REG_SELECT=0 then return 0;else return DISPLACEMENT;end if;end;
 constant wide_address:natural:=(base+offset+16777216) mod 16777216;
 constant short_address:natural:=(STACK_TOP+offset+65536) mod 65536;
 function byte0(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned(n mod 256,8));end;
 function byte1(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/256) mod 256,8));end;
 function byte2(n:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned(n/65536,8));end;
 function prefix return std_logic_vector is begin if REG_SELECT=1 then return x"DD";elsif REG_SELECT=2 then return x"FD";else return x"00";end if;end;
 constant init_prefix:std_logic_vector(7 downto 0):=prefix;
 function mem(op,i:natural) return std_logic_vector is
 begin if REG_SELECT=0 then if i=2 then return std_logic_vector(to_unsigned(op,8));else return x"00";end if;
 else case i is when 0=>return prefix;when 1=>return std_logic_vector(to_unsigned(op,8));when others=>return std_logic_vector(to_signed(DISPLACEMENT,8));end case;end if;end;
 function short_mem(op,i:natural) return std_logic_vector is
 begin if REG_SELECT=0 then case i is when 2=>return x"40";when 3=>return std_logic_vector(to_unsigned(op,8));when others=>return x"00";end case;
 else if i=0 then return x"40";else return mem(op,i-1);end if;end if;end;
 type addr_t is array(0 to 30) of natural;
 constant addresses:addr_t:=(wide_address,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,16#FFFE#,16#FFFD#,wide_address,wide_address,16#FFFE#,16#FFFD#,wide_address,16#FFFE#,16#FFFD#,short_address,short_address,16#FFFE#,16#FFFD#,short_address,16#FFFE#,16#FFFD#);
 type expected_t is array(0 to 30) of std_logic_vector(7 downto 0);
 constant expected:expected_t:=(x"01",x"80",x"94",x"80",x"94",x"7F",x"16",x"7E",x"16",x"00",x"54",x"00",x"44",x"81",x"84",x"01",x"42",x"7F",x"80",x"99",x"95",x"7F",x"99",x"17",x"3F",x"40",x"99",x"11",x"3F",x"99",x"13");
 constant masks:expected_t:=(x"FF",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"D7",x"FF",x"FF",x"FF",x"D7",x"FF",x"FF",x"D7",x"FF",x"FF",x"FF",x"D7",x"FF",x"FF",x"D7");
 type code_t is array(natural range <>) of std_logic_vector(7 downto 0);
 constant code:code_t:=(init_prefix,x"21",byte0(base),byte1(base),byte2(base),mem(16#36#,0),mem(16#36#,1),mem(16#36#,2),x"01",x"3E",x"7F",x"B7",mem(16#86#,0),mem(16#86#,1),mem(16#86#,2),x"F5",x"40",x"C1",x"78",x"FE",x"80",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"94",x"C2",x"FF",x"0F",x"20",x"3E",x"7E",x"B7",x"37",mem(16#8E#,0),mem(16#8E#,1),mem(16#8E#,2),x"F5",x"40",x"C1",x"78",x"FE",x"80",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"94",x"C2",x"FF",x"0F",x"20",x"3E",x"80",x"B7",mem(16#96#,0),mem(16#96#,1),mem(16#96#,2),x"F5",x"40",x"C1",x"78",x"FE",x"7F",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"16",x"C2",x"FF",x"0F",x"20",x"3E",x"80",x"B7",x"37",mem(16#9E#,0),mem(16#9E#,1),mem(16#9E#,2),x"F5",x"40",x"C1",x"78",x"FE",x"7E",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"16",x"C2",x"FF",x"0F",x"20",x"3E",x"80",x"B7",mem(16#A6#,0),mem(16#A6#,1),mem(16#A6#,2),x"F5",x"40",x"C1",x"78",x"FE",x"00",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"54",x"C2",x"FF",x"0F",x"20",x"3E",x"01",x"B7",mem(16#AE#,0),mem(16#AE#,1),mem(16#AE#,2),x"F5",x"40",x"C1",x"78",x"FE",x"00",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"44",x"C2",x"FF",x"0F",x"20",x"3E",x"80",x"B7",mem(16#B6#,0),mem(16#B6#,1),mem(16#B6#,2),x"F5",x"40",x"C1",x"78",x"FE",x"81",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"84",x"C2",x"FF",x"0F",x"20",x"3E",x"01",x"B7",mem(16#BE#,0),mem(16#BE#,1),mem(16#BE#,2),x"F5",x"40",x"C1",x"78",x"FE",x"01",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"42",x"C2",x"FF",x"0F",x"20",mem(16#36#,0),mem(16#36#,1),mem(16#36#,2),x"7F",x"3E",x"99",x"37",mem(16#34#,0),mem(16#34#,1),mem(16#34#,2),x"F5",x"40",x"C1",x"78",x"FE",x"99",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"95",x"C2",x"FF",x"0F",x"20",x"3E",x"99",x"37",mem(16#35#,0),mem(16#35#,1),mem(16#35#,2),x"F5",x"40",x"C1",x"78",x"FE",x"99",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"17",x"C2",x"FF",x"0F",x"20",short_mem(16#36#,0),short_mem(16#36#,1),short_mem(16#36#,2),short_mem(16#36#,3),x"3F",x"3E",x"99",x"37",short_mem(16#34#,0),short_mem(16#34#,1),short_mem(16#34#,2),short_mem(16#34#,3),x"F5",x"40",x"C1",x"78",x"FE",x"99",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"11",x"C2",x"FF",x"0F",x"20",x"3E",x"99",x"37",short_mem(16#35#,0),short_mem(16#35#,1),short_mem(16#35#,2),short_mem(16#35#,3),x"F5",x"40",x"C1",x"78",x"FE",x"99",x"C2",x"FF",x"0F",x"20",x"79",x"E6",x"D7",x"FE",x"13",x"C2",x"FF",x"0F",x"20",x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n,offset:natural;begin
 di<=x"00";
 if not is_x(a24) then
 n:=to_integer(unsigned(a24));
 if n=wide_address then di<=ram(0);end if;
 if n=short_address then di<=ram(1);end if;
 -- Flags saved by PUSH AF are returned to short POP BC.
 if n=16#FFFE# then di<=ram(2);end if;
 if n=16#FFFD# then di<=ram(3);end if;
 if n>=16#200000# and n<16#200000#+code'length then di<=code(n-16#200000#);end if;
 if n=16#200FFF# then di<=x"76";end if;
 end if;end process;
 process(clk) variable n:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a24(15 downto 0)=a report "low address mismatch" severity failure;
 if rfsh='0' or iorq='0' then assert a24(23 downto 16)=x"00" report "refresh/IO bank" severity failure;end if;
 if mreq='0' and rd='0' then assert a24/=x"200FFF" report "indexed read value mismatch" severity failure;end if;
 prev_wr<=wr;
 if wr='0' and prev_wr='1' then
 n:=to_integer(unsigned(a24));assert writes<31 report "extra memory write" severity failure;
 assert n=addresses(writes) report "wrong indexed bank/address " & integer'image(n) & " expected " & integer'image(addresses(writes)) severity failure;
 assert (dout and masks(writes))=expected(writes) report "wrong indexed write value" severity failure;
 if n=16#FFFE# then ram(2)<=dout;end if;if n=16#FFFD# then ram(3)<=dout;end if;if n=wide_address then ram(0)<=dout;end if;if n=short_address then ram(1)<=dout;end if;writes<=writes+1;
 end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;assert writes=31 report "missing writes" severity failure;report "PASS memory ALU eight ops and flags, INC DEC carry preserve, HL IX IY banks, short WAIT";stop;end process;
 process begin wait for 1 ms;assert false report "indexed timeout" severity failure;end process;
 end;
