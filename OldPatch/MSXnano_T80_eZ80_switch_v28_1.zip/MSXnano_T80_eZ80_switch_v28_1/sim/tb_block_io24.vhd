library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.env.all;
entity tb_block_io24 is
 generic(INSERT_WAIT:boolean:=false; OUTPUTTING:boolean:=false; REPEATING:boolean:=false; DECREMENTING:boolean:=false; SHORT_MODE:boolean:=false; ADDRESS_CASE:natural range 0 to 2:=0; INITIAL_B:natural range 0 to 255:=3; FLAG_SEED:natural range 0 to 1:=0);
end;
architecture test of tb_block_io24 is
 signal clk:std_logic:='0';signal reset_n:std_logic:='0';signal wait_n:std_logic:='1';
 signal ce,cf:std_logic;signal phase:natural range 0 to 15:=0;
 signal a:std_logic_vector(15 downto 0);signal a24:std_logic_vector(23 downto 0);signal di,dout:std_logic_vector(7 downto 0);
 signal m1,mreq,iorq,rd,wr,rfsh,halt,busak:std_logic;
 signal prev_wr,prev_read,prev_io:std_logic:='1';signal reads,transfers,snapshots,stack_writes:natural:=0;
 function byte(n:natural;i:natural) return std_logic_vector is begin return std_logic_vector(to_unsigned((n/(256**i)) mod 256,8));end;
 function direction return integer is begin if DECREMENTING then return -1;else return 1;end if;end;
 constant step:integer:=direction;
 function source_base return natural is begin
  if ADDRESS_CASE=0 then if DECREMENTING then return 16#010000#;else return 16#01FFFF#;end if;
  elsif ADDRESS_CASE=1 then if DECREMENTING then return 0;else return 16#FFFFFF#;end if;
  else return 16#7F8000#;end if;end;
 function amount return natural is begin if not REPEATING then return 1;elsif INITIAL_B=0 then return 256;else return INITIAL_B;end if;end;
 constant src:natural:=source_base;constant nbytes:natural:=amount;
 constant count:natural:=16#65005A#+INITIAL_B*256;
 constant dst:natural:=16#7E1234#;
 function pointer_address(i:natural) return natural is begin
  if SHORT_MODE then return (src mod 65536+step*i) mod 65536;
  else return (src+step*i) mod 16777216;end if;end;
 function final_pointer return natural is begin
  if SHORT_MODE then return (src/65536)*65536+pointer_address(nbytes);else return pointer_address(nbytes);end if;end;
 function operand(i:natural) return natural is begin return (16#31#+i*79) mod 256;end;
 function seed return natural is begin if FLAG_SEED=0 then return 0;else return 16#D7#;end if;end;
 function expected_flags return std_logic_vector is variable f:natural;begin
  f:=seed mod 64; -- retain only S,H,PV,C below
  f:=to_integer(unsigned(byte(seed,0) and x"95"));
  if (INITIAL_B-nbytes) mod 256=0 then f:=f+64;end if;
  if operand(nbytes-1)>=128 then f:=f+2;end if;return byte(f,0);end;
 function opcode return std_logic_vector is variable n:natural:=16#A2#;begin
  if OUTPUTTING then n:=n+1;end if;if DECREMENTING then n:=n+8;end if;if REPEATING then n:=n+16;end if;return byte(n,0);end;
 function prefix return std_logic_vector is begin if SHORT_MODE then return x"40";else return x"00";end if;end;
 type bytes_t is array(natural range <>) of std_logic_vector(7 downto 0);
 -- Seed AF via SP16 POP; native pair stores immediately after operation check suffix retirement.
 constant code:bytes_t:=(x"40",x"31",x"00",x"A0",x"F1",
 x"01",byte(count,0),byte(count,1),byte(count,2),
 x"11",byte(dst,0),byte(dst,1),byte(dst,2),x"21",byte(src,0),byte(src,1),byte(src,2),
 prefix,x"ED",opcode,x"F5",
 x"ED",x"43",x"00",x"90",x"30",x"ED",x"53",x"03",x"90",x"30",x"ED",x"63",x"06",x"90",x"30",x"76");
 begin
 clk<=not clk after 5 ns;reset_n<='1' after 100 ns;
 process(clk) begin if rising_edge(clk) then if reset_n='0' then phase<=0;else phase<=(phase+1) mod 16;end if;end if;end process;
 ce<='1' when phase=0 else '0';cf<='1' when phase=8 else '0';
 dut:entity work.G80A_eZ80 generic map(FETCH24=>true,ENABLE_MIXED=>true,RESET_ADL=>true,RESET_PC=>x"200000")
 port map(RESET_n=>reset_n,CLK_n=>clk,clk_enable=>ce,clk_falling=>cf,WAIT_n=>wait_n,INT_n=>'1',NMI_n=>'1',BUSRQ_n=>'1',M1_n=>m1,MREQ_n=>mreq,IORQ_n=>iorq,RD_n=>rd,WR_n=>wr,RFSH_n=>rfsh,HALT_n=>halt,BUSAK_n=>busak,A=>a,A24=>a24,update_addr=>open,DI=>di,DO=>dout,Data_Reverse=>open);
 process(all) variable n:natural;variable idx:integer;begin
 di<=x"00";if not is_x(a24) then n:=to_integer(unsigned(a24));
 if OUTPUTTING then
 if SHORT_MODE then idx:=((n-src mod 65536)*step) mod 65536;else idx:=((n-src)*step) mod 16777216;end if;
 if idx<nbytes and n=pointer_address(idx) then di<=byte(operand(idx),0);end if;
 end if;
 if n=16#A000# then di<=byte(seed,0);elsif n=16#A001# then di<=x"A5";end if;
 if n>=16#200000# and n<16#200000#+code'length then di<=code(n-16#200000#);end if;
 if iorq='0' then di<=byte(operand(transfers),0);end if;
 end if;end process;
 process(clk) variable n,j,expected,port_b:natural;begin
 if rising_edge(clk) and reset_n='1' and not is_x(a24) then
 assert a=a24(15 downto 0) report "low address mismatch" severity failure;
 if rfsh='0' then assert a24(23 downto 16)=x"00" report "refresh bank" severity failure;end if;
 prev_io<=iorq;
 -- sample completed I/O at release; DI must remain fixed throughout WAIT.
 if iorq='1' and prev_io='0' then transfers<=transfers+1;end if;
 if iorq='0' and (rd='0' or wr='0') then
  assert transfers<nbytes report "too many I/O transfers" severity failure;
  port_b:=(INITIAL_B-transfers) mod 256;if OUTPUTTING then port_b:=(port_b-1) mod 256;end if;
  assert a=std_logic_vector(to_unsigned(port_b*256+16#5A#,16)) report "I/O port B/C" severity failure;
  assert a24(23 downto 16)=x"00" report "I/O bank must remain zero in this implementation" severity failure;
  if OUTPUTTING then assert wr='0' and rd='1' and dout=byte(operand(transfers),0) report "I/O output data/control" severity failure;
  else assert rd='0' and wr='1' report "I/O input control" severity failure;end if;
 end if;
 prev_read<=mreq or rd;
 if mreq='0' and rd='0' and prev_read='1' and rfsh='1' and m1='1' then
  n:=to_integer(unsigned(a24));
  if n/=16#A000# and n/=16#A001# and (n<16#200000# or n>=16#200000#+code'length) then
   assert OUTPUTTING and reads<nbytes report "unexpected data read" severity failure;
   assert n=pointer_address(reads) report "output memory address" severity failure;reads<=reads+1;
  end if;
 end if;
 prev_wr<=wr;if mreq='0' and wr='0' and prev_wr='1' then n:=to_integer(unsigned(a24));
 if n=16#A001# then assert dout=x"A5" report "changed A" severity failure;stack_writes<=stack_writes+1;
 elsif n=16#A000# then assert (dout and x"D7")=expected_flags report "I/O flags got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(expected_flags))) severity failure;stack_writes<=stack_writes+1;
 elsif n>=16#309000# and n<16#309009# then
  assert n=16#309000#+snapshots report "snapshot address" severity failure;j:=snapshots/3;
  if j=0 then expected:=16#65005A#+((INITIAL_B-nbytes) mod 256)*256;elsif j=1 then expected:=dst;else expected:=final_pointer;end if;
  assert dout=byte(expected,snapshots mod 3) report "register snapshot byte " & integer'image(snapshots) & " got " & integer'image(to_integer(unsigned(dout))) & " expected " & integer'image(to_integer(unsigned(byte(expected,snapshots mod 3)))) severity failure;
  snapshots<=snapshots+1;
 else
  assert not OUTPUTTING and reads<nbytes report "unexpected memory write" severity failure;
  assert n=pointer_address(reads) and dout=byte(operand(reads),0) report "input memory address/data addr=" & integer'image(n) & " expected=" & integer'image(pointer_address(reads)) & " data=" & integer'image(to_integer(unsigned(dout))) & " expected=" & integer'image(operand(reads)) severity failure;reads<=reads+1;
 end if;end if;end if;end process;
 process begin if INSERT_WAIT then wait until reset_n='1';loop wait for 700 ns;wait_n<='0';wait for 350 ns;wait_n<='1';end loop;end if;wait;end process;
 process begin wait until halt='0';wait for 100 ns;
 assert reads=nbytes and transfers=nbytes and snapshots=9 and stack_writes=2 report "I/O transaction counts" severity failure;
 report "PASS block IO24 addresses, data, B counter, flags, preserved registers, suffix, WAIT";stop;end process;
 process begin wait for 10 ms;assert false report "block IO timeout" severity failure;end process;
 end;
