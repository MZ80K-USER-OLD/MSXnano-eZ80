# MSXnano T80/eZ80 v28.1

ENABLE_SUFFIX_V2の適用先をJP／CALL／RETと絶対アドレスLDへ広げた。
CALLのSPS/SPL混在フレーム、RET.Lのモード復帰、条件不成立、アドレス境界とWAITを検証する。
JP即値の49/52やRET.Sは合法な4幅の一部とは扱わない。
詳細・制限・テストはdoc/ADL_PROGRESS_v28_1.md。

実機用Gowinプロジェクト：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
ボード設定は継承し、ENABLE_SUFFIX_V2の既定値falseを維持する。
v28.1のGowin合成・実機動作・使用量は未確認。24bit物理メモリ接続と新規実機COMは未実装。

再実行：
- bash run_baseline.sh：主回帰7235、元T80比較32、無指定絶対LD168。
- bash run_suffix281.sh：新規の明示絶対LD672＋制御転送1620（主回帰内）。
- python3 tools/run_native_absolute281.py：無指定絶対LD168。
- bash run_indexed_cb_suffix.sh：従来幅指定解除8。
- bash run_size_smoke.sh：規模測定ラッパー6。

GHDLとPython3が必要。GHDL_WORKERSは主回帰の並列数（既定8）。
主回帰ケース一覧：tools/regression_cases_v281.json。
主ログ：test_results_v281.log。結果：verification_result_v281.json。
新規の内訳：test_results_absolute_v2_v281.log、test_results_control_v2_v281.log、
test_results_nested_v2_v281.log、test_results_native_absolute_v281.log。
全体の未実装監査・工程表はdocのv27監査資料を参照する。

検証結果：7235＋168＋32＋8＋6＝7449実行PASS。v28から追加2556条件。
