#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p verification
cd verification
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A/$f.vhd
done
for f in t80_pack t80_reg t80_alu t80_mcode t80 g80a; do
 ghdl -a --std=08 -fsynopsys ../fpga/G80A_eZ80/${f}_ez80.vhd
done
for tb in tb_baseline tb_ez80_baseline; do
 ghdl -a --std=08 -fsynopsys ../sim/$tb.vhd
 ghdl -e --std=08 -fsynopsys $tb
 for w in false true; do
  ghdl -r --std=08 -fsynopsys $tb -gINSERT_WAIT=$w --assert-level=error --vcd=${tb}_${w}.vcd
 done
done
ghdl -a --std=08 -fsynopsys ../sim/tb_upper.vhd
ghdl -e --std=08 -fsynopsys tb_upper
ghdl -r --std=08 -fsynopsys tb_upper --assert-level=error --vcd=upper.vcd
