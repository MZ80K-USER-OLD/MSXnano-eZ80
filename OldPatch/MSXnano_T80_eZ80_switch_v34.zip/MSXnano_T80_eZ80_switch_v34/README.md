# MSXnano T80/eZ80 V34

実機用のDI限定ADL試験、hardware_test/EZ80RAM.COMを追加した。
高位RAMへのコードコピー・照合、27バンクの独立性、16/24bit境界、スタック、CALL/RET、
命令取得の境界越え、幅指定とMBASE、Z80/DOSへの復帰を検査する。

実機用GOWIN：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
V34はtop_ez80.vのEZ80_EXTENDED=1が既定値。RESET_ADL=0でZ80起動する。
GPRJ、Dual Purpose Pin、SystemVerilog、CST／SDCはV33から変更していない。
V34のGOWIN合成・配置配線・使用量・実機動作は未確認。bitstreamは同梱しない。

1. ZIPを展開して指定GPRJで再ビルドし、生成したbitstreamを実機へ書き込む。
2. hardware_test/EZ80RAM.COMをMSX-DOSのディスクへコピーする。
3. DOSプロンプトでEZ80RAMを実行する。

正常時は「EZ80RAM: PASS」を表示してDOSへ戻る。
実行手順、FAIL段階、使用RAM：hardware_test/EZ80RAM_README_ja.md。
詳細・制限・検証：doc/ADL_PROGRESS_v34.md。
メモリ割当：doc/MSXnano_eZ80_Memory_Allocation_v2.md（V34は拡張設定を有効化）。

- python3 hardware_test/build_ram34.py：COM・DEFBソースを再生成。
- bash run_phase34.sh：実COMのCPU＋SDRAM実行シミュレーション。
- python3 tools/verify_release34.py：ログ・ソース・COM一致・GPRJ参照を検査。
- bash run_baseline.sh：継承したV32のCPU回帰を再実行。

新規5シナリオ：正常2、故障注入によるFAIL復帰2、拡張無効のUNSUPPORTED復帰1。
V33の30実行とV32のCPU25361実行は履歴として継承し、新規件数へ加算しない。
CPU6ソースとV33のメモリ接続回路は同一。残件としてADL割込み、MADL、未実装命令等がある。
拡張無効時の旧5B経路と高速化した探索条件の不一致はdocに記録した。
最後の実機成功報告はV32のGOWIN合成・SOFARUNからスペースマンボウ起動／プレイ。
