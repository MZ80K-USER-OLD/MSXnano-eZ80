# MSXnano T80/eZ80 v29

MBASE、LD MB,A／LD A,MBを実装し、eZ80追加命令領域と旧T80命令の衝突を分離した。
詳細と制限はdoc/ADL_PROGRESS_v29.md、命令領域の現状はdoc/ISA_SLOT_STATUS_v29.csv。

新設定ENABLE_EZ80_ISAの既定値はfalse。使用にはMode=0、FETCH24、ENABLE_MIXED、ENABLE_SUFFIX_V2が必要。
標準実機トップは従来設定を維持する。CPU単体のADL規模測定ラッパーは新設定を有効にした。
未実装の追加95命令は実行できない。24ビット物理メモリ接続とADL実機用COMは今後の工程。

実機用Gowin：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
GPRJ・Dual Purpose Pin・SystemVerilog・制約を継承する。
v28.1についてGowin合成と実機スペースマンボウ起動／プレイ成功の報告を受領した。
v29のGowin合成・配置配線・使用量・実機確認は未実施。

再実行（GHDLとPython3）：

- bash run_baseline.sh：主回帰14539＋追加214＝14753実行。
- bash run_mbase29.sh：新規焦点7272（主回帰内）＋短幅割込み32。
- bash run_size_smoke.sh：3構成×WAIT2（全体に含む）。

主回帰一覧：tools/regression_cases_v29.json。
主ログ：test_results_v29.log。結果：verification_result_v29.json。
GHDL_WORKERSは主回帰の並列数（既定8）。元T80ソースは変更しない。

次工程：v30のEX DE,HL／EXXとLD SP,HL／IX／IY。
全体の未実装監査と工程表はdocのv27監査資料を参照。
