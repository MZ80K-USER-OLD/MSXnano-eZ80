# MSXnano T80/eZ80 V34.2

EZ80RAMのstage C報告を受け、拡張RAMの書込みWAITを修正した。
MREQの段階からWAITを下げ、WRと同じエッジでWAITの取込みに遅れないようにする。
RAM完了まで書込みを待つ。CPUコアとSDRAMコントローラはV34.1から変更しない。
GOWIN合成・実機改善は未確認。

同じfpga/project_eZ80/MSXNanoTang20K_eZ80.gprjで再ビルドして書き込む。
hardware_test/EZ80RAM.COMを1200バイトのV34.2へ差し替え、MSX-DOSで実行する。
コピー失敗時はSRC/DST/EXP/READ/RETRY/ABS/LEFTを表示する。
正常表示はEZ80RAM: PASS。
新しいCOMだけをV34.1の既存bitstreamで動かして診断することもできる。
WAIT修正にはV34.2のFPGA再ビルドが必要。

詳細：doc/COPY_STAGE_C_AND_WAIT_v34_2.md。
メモリ配置：doc/SDRAM_Physical_Map_Implementation_v34_1.md（配置変更なし）。

新規23実行PASS：書込みWAIT16、ブリッジ1、SDRAMモデル1、実COM5。
旧版でRAM完了前に書込みT3へ進む2条件を再現し、期待失敗として別記録した。
過去の全CPU回帰を再実行した件数ではない。

- bash run_phase342.sh：今回の検証を再実行。
- python3 hardware_test/build_ram34.py：COMを再生成。
- python3 tools/verify_release342.py：配布内容を検査。

起動時の拡張ロック、COMからの解除、終了前のロックはV34.1を継承する。
制約、GPRJ、Dual Purpose Pin、SystemVerilog設定、元T80は変更しない。
