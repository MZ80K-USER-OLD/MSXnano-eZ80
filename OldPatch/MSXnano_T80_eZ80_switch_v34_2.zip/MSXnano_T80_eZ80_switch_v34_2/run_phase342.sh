#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/run_wait342.py
python3 tools/run_com34.py
python3 tools/collect_release342.py
python3 tools/verify_release342.py
