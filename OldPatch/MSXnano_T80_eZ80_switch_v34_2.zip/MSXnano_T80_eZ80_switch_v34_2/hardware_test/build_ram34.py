"""Build EZ80RAM.COM and a byte-exact, annotated DEFB assembly listing.

The high-memory code is embedded in the COM and copied/verified at runtime.
No external assembler or Z80 emulator is used to create the executable.
"""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
symbols={}
class Image:
 def __init__(self,base):self.base=base;self.data=bytearray();self.rows=[];self.fix=[]
 def label(self,name):
  assert name not in symbols,name
  symbols[name]=self.base+len(self.data);self.rows.append((len(self.data),0,name,''))
 def emit(self,values,comment=''):
  p=len(self.data);self.data.extend(values);self.rows.append((p,len(values),'',comment))
 def ref(self,op,name,width=2,add=0,comment=''):
  pos=len(self.data)+len(op);self.emit(list(op)+[0]*width,comment);self.fix.append((pos,name,width,add))
 def resolve(self):
  for pos,name,width,add in self.fix:self.data[pos:pos+width]=(symbols[name]+add).to_bytes(width,'little')

h=Image(0x010000)
def stage(c):
 h.emit([0x3e,ord(c)],'LD A,stage '+c);h.ref([0x32],'FAIL_STAGE',3,comment='LD (00:FAIL_STAGE),A; no DOS call')
def check(value):
 h.emit([0xfe,value],f'CP {value:02X}h');h.ref([0xc2],'H_FAIL',3,comment='JP NZ,H_FAIL')
def high_a(address):h.emit([0x3a]+list(address.to_bytes(3,'little')),f'LD A,({address:06X}h)')
def high_hl(address):h.emit([0x21]+list(address.to_bytes(3,'little')),f'LD HL,{address:06X}h')
def put(address,value):
 high_hl(address);h.emit([0x3e,value,0x77],f'LD A,{value:02X}h / LD (HL),A')
def ret_z80(status):
 h.emit([0xaf,0xed,0x6d], 'XOR A / LD MB,A; restore MBASE=00 while still ADL')
 h.emit([0x3e,status]);h.ref([0x32],'STATUS',3,comment='LD (00:STATUS),A')
 h.ref([0x40,0xc3],'RETURNED',2,comment='JP.SIS RETURNED; ADL=0, use preserved SPS')

h.label('H_ENTRY');h.emit([0x31,0x00,0x01,0x06],'LD SP,060100h (SPL)')
stage('1')
high_hl(0x018000);h.emit([0x01,0x00,0x00,0x01,0x16,27,0x1e,0x31],'BC=010000h, D=27, E=31h')
h.label('H_BANK_WRITE');h.emit([0x7b,0x77,0x09,0x1c,0x15],'LD A,E / LD (HL),A / ADD HL,BC / INC E / DEC D')
h.ref([0xc2],'H_BANK_WRITE',3,comment='JP NZ,H_BANK_WRITE')
high_hl(0x1b8000);h.emit([0x01,0x00,0x00,0xff,0x16,27,0x1e,0x4b],'BC=FF0000h, D=27, E=4Bh')
h.label('H_BANK_READ');h.emit([0x7e,0xbb],'LD A,(HL) / CP E');h.ref([0xc2],'H_FAIL',3)
h.emit([0x09,0x1d,0x15],'ADD HL,BC / DEC E / DEC D');h.ref([0xc2],'H_BANK_READ',3)
stage('2');put(0x02ffff,0xa5);h.emit([0x23,0x3e,0x5a,0x77,0x2b,0x7e],'INC HL across bank / write / DEC HL / read')
check(0xa5);h.emit([0x23,0x7e]);check(0x5a)
stage('3');high_hl(0x123456)
h.emit([0x22,0xff,0xff,0x02,0xed,0x4b,0xff,0xff,0x02],'LD (02FFFFh),HL / LD BC,(02FFFFh): 3-byte boundary')
h.emit([0xc5,0xd1,0xeb,0x22,0x00,0x01,0x03],'PUSH BC / POP DE / EX DE,HL / LD (030100h),HL')
for address,value in ((0x030100,0x56),(0x030101,0x34),(0x030102,0x12)):high_a(address);check(value)
stage('4');h.emit([0x31,0x01,0x00,0x05],'LD SP,050001h: descending stack crosses into bank04')
high_hl(0x987654);h.emit([0xe5],'PUSH HL: 050000=98,04FFFF=76,04FFFE=54')
for address,value in ((0x04fffe,0x54),(0x04ffff,0x76),(0x050000,0x98)):high_a(address);check(value)
h.emit([0xd1,0xeb,0x22,0x00,0x01,0x03],'POP DE / EX DE,HL / LD (030100h),HL')
for address,value in ((0x030100,0x54),(0x030101,0x76),(0x030102,0x98)):high_a(address);check(value)
h.emit([0x31,0x00,0x01,0x06],'Restore private SPL=060100h')
stage('5');h.emit([0x3e,0x14]);h.ref([0xcd],'H_SUB',3,comment='Native ADL CALL, three-byte return frame');check(0x15)
stage('6');h.emit([0xc3,0xfe,0xff,0x01],'JP 01FFFEh; next JP instruction crosses 64KiB fetch boundary')
h.label('H_AFTER_FETCH')
stage('7');h.emit([0x3e,0x02,0xed,0x6d],'LD A,02h / LD MB,A')
put(0x020001,0x7e);high_hl(0x5612ab)
h.emit([0x40,0x22,0xff,0xff],'LD.SIS (FFFFh),HL: 2 bytes at 02FFFF/020000')
for address,value in ((0x02ffff,0xab),(0x020000,0x12),(0x020001,0x7e)):high_a(address);check(value)
h.emit([0x40,0x21,0xff,0xff,0x3e,0x3c,0x40,0x77],'LD.SIS HL,FFFFh / A=3Ch / LD.SIS (HL),A')
h.emit([0x40,0x23,0x3e,0xa7,0x40,0x77],'INC.SIS HL wraps to 0000h / write at 020000h')
high_a(0x02ffff);check(0x3c);high_a(0x020000);check(0xa7)
h.emit([0x52,0x3a,0xff,0xff,0x7f],'LD.SIL A,(7FFFFFh): short address uses MBASE02/FFFFh');check(0x3c)
h.ref([0x49,0x3a],'MSX_GUARD',2,comment='LD.LIS A,(MSX_GUARD): zero-extended absolute address');check(0xa6)
h.emit([0xaf,0xed,0x6d],'Restore MBASE00')
stage('8');put(0x1bffff,0x55);high_a(0x1bffff);check(0x55)
for address in (0x1c0000,0x3fffff,0x640000,0xffffff):
 put(address,0x96);high_a(address);check(0xff)
high_a(0x1bffff);check(0x55)
stage('G');h.ref([0x21],'MSX_GUARD',3,0x070000,comment='Bank07 address sharing MSX guard low16; outside payload/stack')
h.emit([0x3e,0x43,0x77],'Write only high-bank guard alias')
ret_z80(1)
h.label('H_FAIL');ret_z80(2)
h.label('H_SUB');h.emit([0x3c,0xc9],'INC A / native ADL RET')

cross=Image(0x01fffe);cross.emit([0xc3,0x00,0x01,0x02],'JP 020100h, four bytes crossing bank boundary')
landing=Image(0x020100);landing.ref([0xc3],'H_AFTER_FETCH',3,comment='JP back into main ADL code')

b=Image(0x0100)
b.label('START');b.emit([0xdd,0xe5,0xfd,0xe5],'Save caller IX/IY with extensions locked')
b.ref([0xed,0x73],'SAVED_SP',comment='LD (SAVED_SP),SP')
b.ref([0x11],'BANNER',comment='LD DE,BANNER');b.emit([0x0e,9,0xcd,5,0],'BDOS function 9 before DI')
b.emit([0xf3,0xaf],'DI / XOR A')
b.ref([0x32],'STATUS');b.ref([0x32],'COPY_DIAG_VALID');b.emit([0x3e,0xa6]);b.ref([0x32],'MSX_GUARD')
b.emit([0x3a,0xff,0xff],'Read current secondary-slot register, never write it');b.ref([0x32],'SLOT_BEFORE')
b.emit([0x01,0xe7,0xe7,0xed,0x78,0xe6,0xfe,0xfe,0xe0],'Probe local E7E7h boot-guard status E0/E1')
b.ref([0xc2],'UNSUPPORTED',comment='Old bitstream has no boot-guard control port')
b.emit([0x3e,0xa5,0xed,0x79,0x3e,0x5a,0xed,0x79,0xed,0x78,0xfe,0xe1],'A5 then 5A to E7E7h; require enabled E1')
b.ref([0xc2],'UNSUPPORTED')
b.emit([0xaf,0x52,0x21,0x34,0x12,0x3c,0xb7],'Safe .SIL width probe: enabled consumes 3Ch; disabled executes INC A')
b.ref([0xc2],'UNSUPPORTED',comment='No extended-memory writes when width support is absent')
b.emit([0x3e,ord('C')]);b.ref([0x32],'FAIL_STAGE')
segments=[('PAYLOAD',0x010000,h),('CROSS',0x01fffe,cross),('LANDING',0x020100,landing)]
for name,destination,image in segments:
 b.ref([0x21],name,comment='LD HL,embedded '+name)
 b.emit([0x5b,0x11]+list(destination.to_bytes(3,'little')),f'LD.LIL DE,{destination:06X}h')
 b.emit([0x01]+list(len(image.data).to_bytes(2,'little')),'LD BC,segment length')
 b.ref([0xcd],'COPY',comment='Copy and read-verify every byte while ADL=0, DI')
b.emit([0x5b,0xc3,0x00,0x00,0x01],'JP.LIL 010000h: enter ADL from Z80')
b.label('COPY');b.emit([0x7e,0x5b,0x12,0x5b,0x1a,0xbe],'LD A,(HL); LD.LIL (DE),A; LD.LIL A,(DE); CP (HL)')
b.ref([0xc2],'COPY_FAIL');b.emit([0x5b,0x13,0x23,0x0b,0x78,0xb1],'INC.LIL DE / INC HL / DEC BC / LD A,B / OR C')
b.ref([0xc2],'COPY');b.emit([0xc9],'RET, still Z80')
b.label('COPY_FAIL');b.ref([0x32],'COPY_ACTUAL',comment='Save the first mismatching read before changing A')
b.emit([0x7e]);b.ref([0x32],'COPY_EXPECTED',comment='Expected source byte')
b.ref([0x22],'COPY_SOURCE',comment='16-bit MSX source pointer')
b.ref([0x49,0xed,0x53],'COPY_DEST',comment='LD.LIS (COPY_DEST),DE: capture all 24 destination bits')
b.ref([0xed,0x43],'COPY_LEFT',comment='16-bit remaining byte count')
b.ref([0x49,0xed,0x53],'READ_ABS_OPERAND',comment='Patch only the local diagnostic absolute-read operand')
b.emit([0x06,32],'Delay before an independent retry')
b.label('COPY_DELAY');b.emit([0x10,0xfe],'DJNZ COPY_DELAY')
b.emit([0x5b,0x1a]);b.ref([0x32],'COPY_RETRY',comment='Retry the same indirect high address')
b.ref([0xcd],'READ_ABSOLUTE');b.ref([0x32],'COPY_ABSOLUTE',comment='Read the same destination using an absolute address')
b.emit([0x3e,1]);b.ref([0x32],'COPY_DIAG_VALID')
b.emit([0x3e,2]);b.ref([0x32],'STATUS');b.ref([0xc3],'RETURNED')
b.label('READ_ABSOLUTE');b.emit([0x5b,0x3a],'LD.LIL A,(patched destination)')
b.label('READ_ABS_OPERAND');b.emit([0,0,0]);b.emit([0xc9],'RET, still ADL=0')
b.label('RETURNED');b.ref([0xed,0x73],'AFTER_SP',comment='Capture SPS before restoration')
b.ref([0xed,0x7b],'SAVED_SP',comment='Restore Z80 SPS regardless of success/failure')
b.ref([0x3a],'STATUS');b.emit([0xfe,1]);b.ref([0xc2],'REPORT_FAIL')
for offset in (0,1):
 b.ref([0x3a],'AFTER_SP',add=offset);b.ref([0x21],'SAVED_SP',add=offset);b.emit([0xbe]);b.ref([0xc2],'BAD_SP')
b.ref([0x3a],'MSX_GUARD');b.emit([0xfe,0xa6]);b.ref([0xc2],'BAD_GUARD')
b.emit([0x3a,0xff,0xff]);b.ref([0x21],'SLOT_BEFORE');b.emit([0xbe]);b.ref([0xc2],'BAD_SLOT')
b.ref([0x11],'PASS_MESSAGE');b.ref([0xc3],'PRINT_EXIT')
for name,c in (('BAD_SP','P'),('BAD_GUARD','G'),('BAD_SLOT','S')):
 b.label(name);b.emit([0x3e,ord(c)]);b.ref([0x32],'FAIL_STAGE');b.ref([0xc3],'REPORT_FAIL')
b.label('REPORT_FAIL');b.ref([0x11],'FAIL_MESSAGE');b.ref([0xc3],'PRINT_EXIT')
b.label('UNSUPPORTED');b.emit([0x3e,3]);b.ref([0x32],'STATUS');b.ref([0x11],'UNSUPPORTED_MESSAGE')
b.label('PRINT_EXIT');b.ref([0xcd],'LOCK_EXTENSIONS',comment='Restore legacy Z80 decode before DOS/BIOS or EI')
b.ref([0xcd],'FORMAT_COPY_DIAG',comment='Format diagnostic only after legacy decode is restored')
b.emit([0xfb,0x00,0x0e,9,0xcd,5,0],'EI / NOP / BDOS function 9 with extensions locked')
b.ref([0x3a],'COPY_DIAG_VALID');b.emit([0xb7]);b.ref([0xca],'EXIT_DOS')
b.ref([0x11],'COPY_DETAILS');b.emit([0x0e,9,0xcd,5,0],'Extra BDOS print only for copy mismatch')
b.label('EXIT_DOS')
b.ref([0xed,0x7b],'SAVED_SP');b.emit([0xfd,0xe1,0xdd,0xe1,0xc9],'Restore caller IY/IX, RET to DOS')
b.label('LOCK_EXTENSIONS');b.emit([0x01,0xe7,0xe7,0xaf,0xed,0x79,0xc9],'BC=E7E7h / XOR A / OUT (C),A / RET')
b.label('FORMAT_COPY_DIAG');b.ref([0x3a],'COPY_DIAG_VALID');b.emit([0xb7,0xc8],'RET Z if no copy mismatch')
fields=[('SRC','COPY_SOURCE',2),('DST','COPY_DEST',3),('EXP','COPY_EXPECTED',1),('READ','COPY_ACTUAL',1),('RETRY','COPY_RETRY',1),('ABS','COPY_ABSOLUTE',1),('LEFT','COPY_LEFT',2)]
for name,source,count in fields:
 for position,byte_index in enumerate(range(count-1,-1,-1)):
  b.ref([0x3a],source,add=byte_index);b.ref([0x21],'TEXT_'+name,add=position*2);b.ref([0xcd],'HEX_BYTE')
b.emit([0xc9])
b.label('HEX_BYTE');b.emit([0xf5,0x0f,0x0f,0x0f,0x0f]);b.ref([0xcd],'HEX_NIBBLE');b.emit([0xf1])
b.label('HEX_NIBBLE');b.emit([0xe6,15,0xc6,0x30,0xfe,0x3a]);b.ref([0xda],'HEX_WRITE');b.emit([0xc6,7])
b.label('HEX_WRITE');b.emit([0x77,0x23,0xc9])
for name,data in [('SAVED_SP',[0,0]),('AFTER_SP',[0,0]),('STATUS',[0]),('MSX_GUARD',[0xa6]),('SLOT_BEFORE',[0])]:
 b.label(name);b.emit(data,'Writable COM-local state')
for name,count in [('COPY_DIAG_VALID',1),('COPY_SOURCE',2),('COPY_DEST',3),('COPY_EXPECTED',1),('COPY_ACTUAL',1),('COPY_RETRY',1),('COPY_ABSOLUTE',1),('COPY_LEFT',2)]:
 b.label(name);b.emit([0]*count,'Raw copy-failure evidence')
for name,message in [('BANNER','EZ80RAM v34.2: DI-only ADL RAM test\r\n$'),('PASS_MESSAGE','EZ80RAM: PASS\r\n$'),
                     ('UNSUPPORTED_MESSAGE','EZ80RAM: UNSUPPORTED (use guarded bitstream)\r\n$')]:
 b.label(name);b.emit(message.encode('ascii'),'BDOS string')
b.label('FAIL_MESSAGE');b.emit(b'EZ80RAM: FAIL stage ','BDOS failure string')
b.label('FAIL_STAGE');b.emit(b'?\r\n$','Current phase character')
b.label('COPY_DETAILS')
for name,source,count in fields:
 b.emit((name+'=').encode());b.label('TEXT_'+name);b.emit(b'?'*(count*2));b.emit(b' ')
b.emit(b'\r\n$')
for name,destination,image in segments:
 b.label(name);b.emit([0]*len(image.data),f'Embedded code, runtime destination {destination:06X}h')
for image in (h,cross,landing,b):image.resolve()
for name,_,image in segments:
 i=symbols[name]-0x100;b.data[i:i+len(image.data)]=image.data
assert len(b.data)<0x3000 and len(h.data)<0x1000
listing='; EZ80RAM.COM V34: byte-exact source, no eZ80-aware assembler required.\n'
listing+='; Entry: MSX-DOS Z80 mode, MBASE=00, normal DOS interrupt-enabled caller.\n'
listing+='; All ADL work is DI-only; DOS/BIOS calls occur only in Z80 mode.\n    ORG 0100H\n'
for pos,size,name,comment in b.rows:
 if name:listing+=name+':\n'
 else:
  for i in range(0,size,16):listing+='    DEFB '+','.join(f'0{x:02X}H' for x in b.data[pos+i:pos+min(i+16,size)])+' ; '+comment+'\n'
listing+='\n; Runtime ADL payload (the DEFB block above contains these resolved bytes):\n'
for image in (h,cross,landing):
 for pos,size,name,comment in image.rows:
  if name:listing+=f'; {image.base+pos:06X} {name}:\n'
  else:listing+=f'; {image.base+pos:06X} '+image.data[pos:pos+size].hex(' ')+'  '+comment+'\n'
(root/'EZ80RAM.COM').write_bytes(b.data)
(root/'ez80ram_v34.asm').write_text(listing)
(root/'EZ80RAM.hex').write_text(''.join(f'{v:02x}\n' for v in b.data))
manifest=dict(version='34.2',origin=0x100,bytes=len(b.data),sha256=hashlib.sha256(b.data).hexdigest(),
 labels=symbols,segments=[dict(source=symbols[name],destination=dest,bytes=len(img.data)) for name,dest,img in segments],
 expected_pass='EZ80RAM: PASS',interrupt_policy='DI, unlock E7E7h for test, lock before DOS output/EI/return',
 memory_use='private RAM 01-1B only, plus ignored writes to unmapped banks; no MegaRAM/VRAM writes')
(root/'EZ80RAM_v34.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'EZ80RAM_v34.vh').write_text(''.join(f'`define V34_{name} 24\'h{value:06x}\n' for name,value in symbols.items())+f'`define V34_COM_END 16\'h{0x100+len(b.data)-1:04x}\n')
print('Built EZ80RAM.COM',len(b.data),'bytes, payload',len(h.data),'bytes',manifest['sha256'])
