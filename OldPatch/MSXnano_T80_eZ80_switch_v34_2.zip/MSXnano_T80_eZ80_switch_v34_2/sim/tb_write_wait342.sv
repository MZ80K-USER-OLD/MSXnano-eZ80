`timescale 1ns/1ps
module tb_write_wait342;
    parameter PHASE=0, ACK_DELAY=16, CHECK_EARLY=1;
    reg c108=0,c54=0,c27=0,reset_n=0;
    always #5 c108=~c108;
    always #10 c54=~c54;
    always #20 c27=~c27;
    reg [1:0] dot=0;
    reg dh=0,dl=0;
    always @(posedge c27) begin
        if(!reset_n) begin dot<=0;dh<=0;dl<=0;end
        else begin
            dot<={dot[0],!dot[1]};
            case(dot)
                0: begin dh<=0;dl<=1;end
                1: begin dh<=1;dl<=0;end
                3: begin dh<=0;dl<=0;end
                2: begin dh<=1;dl<=1;end
            endcase
        end
    end
    reg [3:0] divider=0;
    always @(posedge c54) if(!reset_n) divider<=PHASE;else divider<=divider+1;
    wire [23:0] a;
    wire mr,io,rf,rd,wr,m1,halt_n;
    wire [7:0] dout;
    reg [7:0] din;
    wire mm,ext,wait_n,req,rw,done;
    wire [15:0] ma;
    wire [22:0] ra;
    wire [7:0] ext_di,wd,ramdata;
    G80A_eZ80 cpu(.RESET_n(reset_n),.CLK_n(c54),.clk_enable(divider==0),.clk_falling(divider==8),
        .WAIT_n(wait_n),.INT_n(1'b1),.NMI_n(1'b1),.BUSRQ_n(1'b1),.DI(din),
        .A24(a),.MREQ_n(mr),.IORQ_n(io),.RFSH_n(rf),.RD_n(rd),.WR_n(wr),.DO(dout),.M1_n(m1),.HALT_n(halt_n));
    reg [31:0] ack_pipe=0;
    always @(posedge c54) if(!reset_n) ack_pipe<=0;else ack_pipe<={ack_pipe[30:0],done};
    wire bridge_done=ACK_DELAY==0 ? done : ack_pipe[ACK_DELAY-1];
    wire mapped_high=(a[23:16]>=1 && a[23:16]<=8'h1b)||(a[23:16]>=8'h40 && a[23:16]<=8'h63);
    integer early_wait_samples=0;
    ez80_memory_bridge bridge(c54,reset_n,a,mr,io,rf,rd,wr,dout,
        mm,ma,ext,wait_n,ext_di,req,rw,ra,wd,bridge_done,ramdata);
    wire [15:0] vo;
    wire cs,ras,cas,we,sc,cke;
    wire [31:0] dq;
    wire [10:0] sa;
    wire [1:0] ba;
    wire [3:0] dm;
    memory_ctrl_ez80 mem(
        .clk_27m(c54),.clk_108m(c108),.bus_reset_n(reset_n),.video_dhclk(dh),.video_dlclk(dl),
        .mapper_din(8'h00),.mapper_req(1'b0),.mapper_write(1'b0),.mapper_addr(22'h0),
        .megaram_req(1'b0),.megaram_write(1'b0),.megaram_addr(21'h0),
        .vram_addr(17'hffff),.vram_write(1'b0),.vram_din(8'h0),.bus_rfsh_n(rf),.vram_dout(vo),
        .ext_req(req),.ext_write(rw),.ext_addr(ra),.ext_din(wd),.ext_done(done),.ext_dout(ramdata),
        .O_sdram_clk(sc),.O_sdram_cke(cke),.O_sdram_cs_n(cs),.O_sdram_ras_n(ras),
        .O_sdram_cas_n(cas),.O_sdram_wen_n(we),.IO_sdram_dq(dq),
        .O_sdram_addr(sa),.O_sdram_ba(ba),.O_sdram_dqm(dm));
    sdram_model33 ram(sc,{cs,ras,cas,we},sa,ba,dm,dq);
    reg [7:0] rom[0:255],high_code[0:1023];
    integer i,p,waits=0,high_fetches=0,video_waits=0;
    always @(posedge c54) begin
        din<=ext?ext_di:(!mm && ma<256?rom[ma]:8'hff);
        if(reset_n && !wait_n) waits=waits+1;
        if(reset_n && mapped_high && !mr && io && rf && rd && wr) begin
            early_wait_samples=early_wait_samples+1;
            if(CHECK_EARLY && wait_n!==0) $fatal(1,"WAIT must assert from MREQ before WR; A=%h TS=%d",a,cpu.u0.tstate);
        end
        if(reset_n && mapped_high && ext && !wr && cpu.u0.tstate==3 && bridge.state!=2)
            $fatal(1,"CPU entered write T3 before RAM completion");
        if(reset_n && !m1 && !mr && rf && a[23:16]!=0) high_fetches=high_fetches+1;
        if(reset_n && !wait_n && dl) video_waits=video_waits+1;
        if(reset_n && !mm && !wr && ma==16'h9000) begin
            if(dout!==8'hb7) $fatal(1,"CPU reported failure signature=%h PC=%h",dout,a);
            if(ram.words[23'h650300>>2][23:0]!==24'h123456) $fatal(1,"24-bit stack/exchange result");
            if(vo!==16'he239) $fatal(1,"VDP did not see CPU VRAM bytes: %h",vo);
            if(waits==0 || high_fetches==0 || video_waits==0) $fatal(1,"no high fetch/WAIT/contention");
            if(early_wait_samples==0) $fatal(1,"write pre-strobe window not exercised");
            $display("PASS write_wait342 phase=%0d high_fetch_ticks=%0d WAIT_ticks=%0d VDP_WAIT_ticks=%0d writes=%0d",PHASE,high_fetches,waits,video_waits,ram.writes);
            $finish;
        end
        if(reset_n && ext && !mm) $fatal(1,"high CPU cycle reached MSX memory decode");
    end
    initial begin
        $readmemh("sim/image33/boot.hex",rom);$readmemh("sim/image33/high.hex",high_code);
        for(i=0;i<1024;i=i+4) ram.words[(23'h650000+i)>>2]={high_code[i+3],high_code[i+2],high_code[i+1],high_code[i]};
        repeat(12) @(negedge c54);reset_n=1;
        @(negedge c108);mem.RstSeq=24;
    end
    initial begin #10000000;$fatal(1,"CPU timeout a=%h mreq=%b rd=%b wr=%b wait=%b",a,mr,rd,wr,wait_n);end
endmodule
