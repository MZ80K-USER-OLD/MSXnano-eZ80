# MSXnano T80/eZ80 v19

メモリオペランドの8bit ALUとメモリINC／DECに24bitアドレスを追加。
HL／IX／IY、40h短幅bank 0を検証。演算データは8bit。
全643実行PASS。新規テスト: sim/tb_memory_alu24.vhd（48ケース）。
仕様・制限: doc/ADL_PROGRESS_v19.md。ログ: test_results_v19.log。
実行: bash run_baseline.sh（GHDLとPython3）。

v18でユーザーがスペースマンボウの実機プレイを確認。
v19の合成・実機動作は未確認。MSX標準設定を維持。
A24メモリ接続前なので追加機能はシミュレーション用。
既存COM／ASMはhardware_testに同梱。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
元T80の8ファイルは基準SHA256と一致。
