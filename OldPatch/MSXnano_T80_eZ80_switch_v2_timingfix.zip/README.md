# MSXnano T80/eZ80切替版 v2

## Gowinで開くプロジェクト
- 元T80: fpga/project_T80/MSXNanoTang20K_T80.gprj
- 拡張開発版: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
別フォルダで標準のimpl出力を分離。出力先を上書きするときも別々にする。
トップはtop。T80はtop.v、拡張版はtop_ez80.vを使用。2つを同時登録しない。
両topの違いは先頭のMSXNANO_USE_EZ80定義だけ。共通変更は両方に反映する。
プリプロセッサの条件分岐で合成前にCPUを選択。cpu1はトップ直下に保持。両CPUを同時搭載しない。

## 元版保持
fpga/G80Aは元ZIPとバイト単位で一致。SHA256一覧を添付。
G80A_eZ80はentity/component/package名を独立化した開発用コピー。
originalに元top、元プロジェクト、復帰用MSXnanoTANG20K.fsを保持。
このFSは元のハード構成で使用する。fpga/implの旧成果物は今回の合成結果ではない。

## 状態と検証
拡張版は現時点ではZ80機能のみ。ADL命令・24bitアドレス・PC/SPS/SPL/MBASEは未実装。上位8bitレジスタ保存経路を追加。
GHDL 4.1.0でrun_baseline.shを実行。両CPUの通常/WAIT挿入、計4テストPASS。
LD、PUSH/POP、EX、CALL/RET、INC HL、IN/OUT、HALTを検査。
両CPUの外部信号VCD変化が通常/WAIT双方で一致。
全命令、割込み、BIOS起動、実MSXクロック分周は未検証。
Gowin環境がないためトップの混在言語合成、配置配線、実機起動は未確認。

次は独立した拡張版に上位バイト、SPS/SPL、MBASEを追加。元T80は変更しない。

## v2 上位バイト経路
BC/DE/HL/IX/BC代替/DE代替/HL代替/IYの8スロットにRegsUを追加。
独立したWEU/DIU、3つの読出しポートDOAU/DOBU/DOCUを追加。
上位のみをリセットし、既存H/Lの初期化動作を維持。
CPU内部にRegBusA24/B24/C24の結合経路を追加。
命令デコードは未接続でWEUは0固定。現時点では命令から上位を書けない。
合成時には未使用の上位記憶・経路が削除され得るため、今回の追加だけで24bit CPUや規模増加を評価できない。
EXXは共通アドレス選択に追従する構成。EX DE,HLの上位交換、INC/DEC桁上がり、短い転送のeZ80命令別規則は今後実装する。
単体テストtb_upperで全8スロット、3読出しポート、CEN停止、上位/下位書込み分離、リセットを確認。
Z80基準4テストと上位単体テストの計5テストがPASS。
今回の上位0初期化は開発段階の決定的初期値であり、全eZ80レジスタの実機リセット値を保証するものではない。
次はPC・SPS/SPL・MBASEおよびADL/幅制御を追加し、24bit転送命令につなぐ。

## CPU階層のSDC修正
TA2003のCPU対象エラー対策としてgenerateのgen_t80/gen_ez80階層を廃止。
トップ直下のcpu1を維持して、従来のSDCのcpu1/u0/Regs等の指定を保持。
T80用top.vはMSXNANO_USE_EZ80をundef、拡張用top_ez80.vはundef後にdefine。
切替は選択したGowinプロジェクトで行う。USE_EZ80 parameterによる切替は廃止。
独立したCPU entity/package、上位レジスタ追加、元T80無変更を維持。
env_resetの不要なcreate_clock削除も含む。
Gowin合成後の階層は未確認。最適化で他の個別対象が消える場合は、そのネットリストで再確認が必要。
