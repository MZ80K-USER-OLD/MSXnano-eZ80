# MSXnano T80/eZ80 v10

ADL状態の通常LD/JPと40h短幅指定を追加。全命令ADL対応ではない。
仕様・制限: DOCM/ADL_PROGRESS_v10.md。
GHDL: bash run_baseline.sh（GHDLとPython3）。283実行PASS。
新規テスト: sim/tb_native24.vhd。ログ: test_results_v10.log。
MSX標準設定を維持。v10の合成・実機動作は未確認。新機能はシミュレーション用。
eZ80用: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
元T80用: fpga/project_T80/MSXNanoTang20K_T80.gprj。
旧拡張機能の実機COMとASMも引き続き同梱。
