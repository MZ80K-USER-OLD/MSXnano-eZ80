# MSXnano T80/eZ80切替版 v3

## プロジェクト
従来T80: fpga/project_T80/MSXNanoTang20K_T80.gprj
拡張版: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
各プロジェクトは別のtopソースを選択し、プリプロセッサでCPUをトップ直下のcpu1に配置。
T80/eZ80プロジェクトを切り替えることで元CPUに戻れる。元G80A/T80ソースは無変更。
original/MSXnanoTANG20K.fsはアップロード時の復帰用成果物。現在の版の生成物ではない。

## 開発状態
ADL_PROGRESS_v3.mdを参照。最初の5Bh付き24bit即値LDを実装した限定版。
ADLモード、24bit PC/アドレス、スタックはまだ未実装。
Gowinの合成・実機動作はこのv3では未確認。

## 検証
GHDLとPython3を用意してbash run_baseline.sh。
通常/WAITの基準テスト、上位単体、長い即値LDテスト、上位VCD照合を実施する。
全命令の互換性を保証するテストではない。
