# MSXnano T80/eZ80切替版 v1

## Gowinで開くプロジェクト
- 元T80: fpga/project_T80/MSXNanoTang20K_T80.gprj
- 拡張開発版: fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj
別フォルダで標準のimpl出力を分離。出力先を上書きするときも別々にする。
トップはtop。T80はtop.v、拡張版はtop_ez80.vを使用。2つを同時登録しない。
両topの違いはUSE_EZ80既定値だけ。共通変更は両方に反映する。
generateで合成時に選択するため両CPUを同時搭載しない。

## 元版保持
fpga/G80Aは元ZIPとバイト単位で一致。SHA256一覧を添付。
G80A_eZ80はentity/component/package名を独立化した開発用コピー。
originalに元top、元プロジェクト、復帰用MSXnanoTANG20K.fsを保持。
このFSは元のハード構成で使用する。fpga/implの旧成果物は今回の合成結果ではない。

## 状態と検証
拡張版は現時点ではZ80機能のみ。ADL/24bitは未実装。
GHDL 4.1.0でrun_baseline.shを実行。両CPUの通常/WAIT挿入、計4テストPASS。
LD、PUSH/POP、EX、CALL/RET、INC HL、IN/OUT、HALTを検査。
両CPUの外部信号VCD変化が通常/WAIT双方で一致。
全命令、割込み、BIOS起動、実MSXクロック分周は未検証。
Gowin環境がないためトップの混在言語合成、配置配線、実機起動は未確認。

次は独立した拡張版に上位バイト、SPS/SPL、MBASEを追加。元T80は変更しない。
