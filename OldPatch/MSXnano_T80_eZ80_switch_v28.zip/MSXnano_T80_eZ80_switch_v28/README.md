# MSXnano T80/eZ80 v28 — 幅デコーダ基盤／即値LD

40/49/52/5Bのデータ幅と即値幅を分離し、LD BC/DE/HL/IX/IY/SP,即値へ適用した。
ENABLE_SUFFIX_V2=trueは検証用の新設定。既定falseではv27の処理を継承する。
全命令の幅指定を完成した版ではない。適用範囲・残件はdoc/ADL_PROGRESS_v28.mdを参照。
工程v28の未完分はv28.1で継続し、その後v29へ進む。

実機用Gowinプロジェクト：fpga/project_eZ80/MSXNanoTang20K_eZ80.gprj。
ボード設定は変更していない。v28のGowin合成・配置配線・実機動作は未確認。
24bit物理メモリ接続は未実装。新規実機COMはなく、既存hardware_testを同梱する。

eZ80_ADL規模測定用ラッパーのみ、新しいENABLE_SUFFIX_V2を有効化した。
CPU規模測定の3構成は27 I/O。実際の使用量はGowinで測定する。手順はdoc/ADL_PROGRESS_v21.md。

再実行にはGHDLとPython3が必要：
- bash run_baseline.sh：既存4271＋新規576＝4847ケース、および元T80との比較32ケース。
- bash run_suffix_width28.sh：新規576ケースのみ（全回帰に含まれる）。
- bash run_indexed_cb_suffix.sh：従来幅指定解除8ケース。
- bash run_size_smoke.sh：規模測定ラッパー6ケース。

ログ：test_results_v28.log、test_results_suffix_width_v28.log、test_results_compat_v28.log、
test_results_suffix_v28.log、test_results_size_v28.log。
全回帰計画：tools/regression_cases_v28.json。GHDL_WORKERSで並列数を変更可能（既定8）。
結果一覧：verification_result_v28.json。
未実装監査と全体工程：doc/EZ80_v27_AUDIT_AND_COMPLETION_PLAN.mdとCSV台帳。

検証結果：主回帰4847＋元T80比較32＋従来幅指定解除8＋規模測定6＝4893実行PASS。
